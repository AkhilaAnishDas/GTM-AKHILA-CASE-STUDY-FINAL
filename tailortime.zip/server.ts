import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import dotenv from 'dotenv';
import authRoutes from './backend/routes/auth.js';
import appointmentRoutes from './backend/routes/appointments.js';
import orderRoutes from './backend/routes/orders.js';
import capacityRoutes from './backend/routes/capacity.js';
import notificationRoutes from './backend/routes/notifications.js';
import customerRoutes from './backend/routes/customers.js';
import measurementRoutes from './backend/routes/measurements.js';
import shopRoutes from './backend/routes/shop.js';
import analyticsRoutes from './backend/routes/analytics.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  // Body parsing middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Request logging in development
  app.use((req, _res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[${new Date().toISOString().slice(11, 19)}] ${req.method} ${req.path}`);
    }
    next();
  });

  // REST API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/appointments', appointmentRoutes);
  app.use('/api/orders', orderRoutes);
  app.use('/api/shop/capacity', capacityRoutes);
  app.use('/api/shop', shopRoutes);
  app.use('/api/notifications', notificationRoutes);
  app.use('/api/customers', customerRoutes);
  app.use('/api/measurements', measurementRoutes);
  app.use('/api/analytics', analyticsRoutes);

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'healthy',
      app: 'TailorTime',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
    });
  });

  // Vite or Static Serving
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.resolve(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🧵 TailorTime server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start TailorTime server:', err);
  process.exit(1);
});
