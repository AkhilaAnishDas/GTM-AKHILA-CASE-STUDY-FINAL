import {
  User,
  Appointment,
  Order,
  Notification,
  MeasurementRecord,
  ShopSettings,
  CapacityResponse,
  AnalyticsResponse,
} from '../types';

const TOKEN_KEY = 'tailortime_auth_token';

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem(TOKEN_KEY);
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  }

  getToken(): string | null {
    return this.token || localStorage.getItem(TOKEN_KEY);
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.message || `Request failed with status ${response.status}`);
    }

    return data as T;
  }

  // Auth
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    this.setToken(res.token);
    return res;
  }

  async register(userData: {
    name: string;
    email: string;
    phone: string;
    password: string;
    role?: 'customer' | 'admin';
    address?: string;
  }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    this.setToken(res.token);
    return res;
  }

  async getMe(): Promise<{ user: User }> {
    return this.request<{ user: User }>('/api/auth/me');
  }

  async updateProfile(updates: Partial<User>): Promise<{ user: User; message: string }> {
    return this.request<{ user: User; message: string }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async demoLogin(role: 'customer' | 'admin'): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/demo-login', {
      method: 'POST',
      body: JSON.stringify({ role }),
    });
    this.setToken(res.token);
    return res;
  }

  async resetDemo(): Promise<{ message: string }> {
    return this.request<{ message: string }>('/api/auth/reset-demo', {
      method: 'POST',
    });
  }

  // Public Order Tracking
  async trackOrderPublic(jobId: string): Promise<{ order: Order }> {
    return this.request<{ order: Order }>(`/api/orders/track/${encodeURIComponent(jobId)}`);
  }

  // Appointments
  async getAppointments(filters?: { date?: string; status?: string; search?: string }): Promise<{ appointments: Appointment[] }> {
    const query = new URLSearchParams();
    if (filters?.date) query.set('date', filters.date);
    if (filters?.status && filters.status !== 'all') query.set('status', filters.status);
    if (filters?.search) query.set('search', filters.search);

    const qs = query.toString();
    return this.request<{ appointments: Appointment[] }>(`/api/appointments${qs ? `?${qs}` : ''}`);
  }

  async bookAppointment(data: {
    service: string;
    date: string;
    timeSlot: string;
    notes?: string;
    customerName?: string;
    phone?: string;
    customerId?: string;
  }): Promise<{ appointment: Appointment; message: string }> {
    return this.request<{ appointment: Appointment; message: string }>('/api/appointments', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateAppointment(
    id: string,
    updates: {
      status?: string;
      date?: string;
      timeSlot?: string;
      notes?: string;
    }
  ): Promise<{ appointment: Appointment; message: string }> {
    return this.request<{ appointment: Appointment; message: string }>(`/api/appointments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async cancelAppointment(id: string): Promise<{ appointment: Appointment; message: string }> {
    return this.request<{ appointment: Appointment; message: string }>(`/api/appointments/${id}`, {
      method: 'DELETE',
    });
  }

  // Orders
  async getOrders(filters?: { stage?: string; search?: string; customerId?: string }): Promise<{ orders: Order[] }> {
    const query = new URLSearchParams();
    if (filters?.stage && filters.stage !== 'all') query.set('stage', filters.stage);
    if (filters?.search) query.set('search', filters.search);
    if (filters?.customerId) query.set('customerId', filters.customerId);

    const qs = query.toString();
    return this.request<{ orders: Order[] }>(`/api/orders${qs ? `?${qs}` : ''}`);
  }

  async getOrder(id: string): Promise<{ order: Order }> {
    return this.request<{ order: Order }>(`/api/orders/${id}`);
  }

  async createOrder(data: {
    customerId?: string;
    customerName: string;
    phone: string;
    service: string;
    garmentType: string;
    measurements?: Record<string, string>;
    notes?: string;
    assignedTailor?: string;
    estimatedCompletion?: string;
    price?: number;
    advancePaid?: number;
    appointmentId?: string;
  }): Promise<{ order: Order; message: string }> {
    return this.request<{ order: Order; message: string }>('/api/orders', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateOrder(
    id: string,
    updates: {
      currentStage?: string;
      stageNote?: string;
      estimatedCompletion?: string;
      assignedTailor?: string;
      measurements?: Record<string, string>;
      notes?: string;
      price?: number;
      advancePaid?: number;
    }
  ): Promise<{ order: Order; message: string }> {
    return this.request<{ order: Order; message: string }>(`/api/orders/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  // Capacity
  async getCapacity(date?: string): Promise<CapacityResponse> {
    const qs = date ? `?date=${encodeURIComponent(date)}` : '';
    return this.request<CapacityResponse>(`/api/shop/capacity${qs}`);
  }

  // Notifications
  async getNotifications(): Promise<{ notifications: Notification[]; unreadCount: number }> {
    return this.request<{ notifications: Notification[]; unreadCount: number }>('/api/notifications');
  }

  async markNotificationRead(id: string): Promise<{ notification: Notification }> {
    return this.request<{ notification: Notification }>(`/api/notifications/${id}/read`, {
      method: 'PUT',
    });
  }

  async markAllNotificationsRead(): Promise<{ message: string }> {
    return this.request<{ message: string }>('/api/notifications/mark-all-read', {
      method: 'PUT',
    });
  }

  async simulateNotification(title: string, message: string, channel: 'whatsapp_simulated' | 'sms_simulated' | 'in_app' = 'whatsapp_simulated'): Promise<{ notification: Notification }> {
    return this.request<{ notification: Notification }>('/api/notifications/simulate', {
      method: 'POST',
      body: JSON.stringify({ title, message, channel }),
    });
  }

  // Customers (Admin)
  async getCustomers(search?: string): Promise<{
    customers: (User & {
      totalOrders: number;
      activeJobsCount: number;
      totalAppointments: number;
      hasMeasurements: boolean;
    })[];
  }> {
    const qs = search ? `?search=${encodeURIComponent(search)}` : '';
    return this.request<{ customers: any[] }>(`/api/customers${qs}`);
  }

  async getCustomerDetails(id: string): Promise<{
    customer: User;
    appointments: Appointment[];
    orders: Order[];
    measurements: MeasurementRecord | null;
  }> {
    return this.request<any>(`/api/customers/${id}`);
  }

  // Measurements
  async getMeasurements(customerId: string): Promise<{ measurements: MeasurementRecord | null }> {
    return this.request<{ measurements: MeasurementRecord | null }>(`/api/measurements/${customerId}`);
  }

  async saveMeasurements(data: Partial<MeasurementRecord>): Promise<{ measurements: MeasurementRecord; message: string }> {
    return this.request<{ measurements: MeasurementRecord; message: string }>('/api/measurements', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Shop Settings
  async getShopSettings(): Promise<{ shop: ShopSettings }> {
    return this.request<{ shop: ShopSettings }>('/api/shop');
  }

  async updateShopSettings(updates: Partial<ShopSettings>): Promise<{ shop: ShopSettings; message: string }> {
    return this.request<{ shop: ShopSettings; message: string }>('/api/shop', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  // Analytics (Admin)
  async getAnalytics(): Promise<AnalyticsResponse> {
    return this.request<AnalyticsResponse>('/api/analytics');
  }
}

export const api = new ApiService();
