export type UserRole = 'customer' | 'admin';

export interface User {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  address?: string;
  preferredMeasurements?: Record<string, string>;
  createdAt: string;
}

export type AppointmentService = 
  | 'New Outfit'
  | 'Alteration'
  | 'Measurement'
  | 'Fitting'
  | 'Pickup / Collection';

export type AppointmentStatus =
  | 'pending'
  | 'confirmed'
  | 'completed'
  | 'cancelled'
  | 'no-show';

export interface Appointment {
  _id: string;
  appointmentId: string;
  customerId: string;
  customerName: string;
  phone: string;
  service: AppointmentService;
  date: string;
  timeSlot: string;
  notes?: string;
  status: AppointmentStatus;
  createdAt: string;
  attendedAt?: string;
}

export type OrderStage =
  | 'appointment'
  | 'measurement'
  | 'cutting'
  | 'stitching'
  | 'fitting'
  | 'alteration'
  | 'quality_check'
  | 'ready'
  | 'collected';

export interface OrderStageHistory {
  stage: OrderStage;
  timestamp: string;
  note?: string;
  completedBy?: string;
}

export interface Order {
  _id: string;
  jobId: string;
  appointmentId?: string;
  customerId: string;
  customerName: string;
  phone: string;
  service: AppointmentService;
  garmentType: string;
  measurements: Record<string, string>;
  notes?: string;
  currentStage: OrderStage;
  stagesHistory: OrderStageHistory[];
  assignedTailor: string;
  estimatedCompletion: string;
  readyDate?: string;
  collectedDate?: string;
  price: number;
  advancePaid: number;
  createdAt: string;
}

export type NotificationType =
  | 'appointment'
  | 'job_status'
  | 'ready'
  | 'collection_reminder';

export interface Notification {
  _id: string;
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  channel: 'in_app' | 'whatsapp_simulated' | 'sms_simulated';
  isRead: boolean;
  createdAt: string;
  orderId?: string;
  appointmentId?: string;
}

export interface MeasurementRecord {
  _id: string;
  customerId: string;
  customerName: string;
  phone: string;
  chest?: string;
  waist?: string;
  shoulder?: string;
  sleeve?: string;
  length?: string;
  hip?: string;
  inseam?: string;
  neck?: string;
  notes?: string;
  updatedAt: string;
}

export interface ShopSettings {
  _id: string;
  shopName: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  openingHours: string;
  closingHours: string;
  slotDurationMinutes: number;
  maxCapacityPerSlot: number;
  workingDays: string[];
  announcement?: string;
}

export interface SlotCapacity {
  timeSlot: string;
  capacity: number;
  booked: number;
  available: number;
  isFull: boolean;
  appointments: {
    appointmentId: string;
    customerName: string;
    service: string;
    status: AppointmentStatus;
  }[];
}

export interface CapacityResponse {
  date: string;
  maxCapacityPerSlot: number;
  totalCapacity: number;
  totalBooked: number;
  totalAvailable: number;
  occupancyPercentage: number;
  slots: SlotCapacity[];
}

export interface AnalyticsResponse {
  summary: {
    todayAppointmentsCount: number;
    totalAppointmentsCount: number;
    pendingJobs: number;
    inProduction: number;
    readyOrders: number;
    completedOrders: number;
    noShows: number;
    averageWaitMinutes: number;
    onTimeRate: number;
    totalRevenue: number;
    advanceCollected: number;
    pendingBalance: number;
  };
  stageCounts: Record<string, number>;
  alerts: {
    type: 'info' | 'success' | 'warning';
    title: string;
    message: string;
  }[];
  todayAppointments: Appointment[];
  recentOrders: Order[];
}
