/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider, useNotifications } from './context/NotificationContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { WhatsAppModal } from './components/common/WhatsAppModal';
import { AuthModal } from './components/auth/AuthModal';
import { LandingPage } from './components/landing/LandingPage';
import { BookAppointmentWizard } from './components/customer/BookAppointmentWizard';
import { CustomerHome } from './components/customer/CustomerHome';
import { MyAppointments } from './components/customer/MyAppointments';
import { OrderTrackingView } from './components/customer/OrderTrackingView';
import { CustomerProfile } from './components/customer/CustomerProfile';
import { NotificationsView } from './components/customer/NotificationsView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminAppointments } from './components/admin/AdminAppointments';
import { AdminOrders } from './components/admin/AdminOrders';
import { AdminCapacity } from './components/admin/AdminCapacity';
import { AdminCustomers } from './components/admin/AdminCustomers';
import { AdminSettings } from './components/admin/AdminSettings';
import { CreateJobModal } from './components/admin/CreateJobModal';
import { Appointment } from './types';

function MainApp() {
  const { user, isLoading } = useAuth();

  // Current active tab
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [targetTrackingJobId, setTargetTrackingJobId] = useState<string>('');

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [jobFromApt, setJobFromApt] = useState<Appointment | null>(null);

  // Sync tab with user login state
  useEffect(() => {
    if (!isLoading) {
      if (user) {
        if (user.role === 'admin' && (currentTab === 'landing' || currentTab === 'customer-home')) {
          setCurrentTab('admin-dashboard');
        } else if (user.role === 'customer' && (currentTab === 'landing' || currentTab === 'admin-dashboard')) {
          setCurrentTab('customer-home');
        }
      } else {
        if (currentTab !== 'track-public' && currentTab !== 'landing') {
          setCurrentTab('landing');
        }
      }
    }
  }, [user, isLoading]);

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  const handleDirectTrack = (jobId: string) => {
    setTargetTrackingJobId(jobId);
    setCurrentTab(user ? 'track-order' : 'track-public');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F5FA] text-[#1F2340]">
      {/* Toast Notification Stack */}
      <ToastContainer />

      {/* Realistic Simulated WhatsApp Notification Screen */}
      <WhatsAppModal />

      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenAuth={handleOpenAuth}
        onOpenBooking={() => setIsBookingOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* PUBLIC VIEWS */}
        {currentTab === 'landing' && (
          <LandingPage
            onOpenBooking={() => (user ? setIsBookingOpen(true) : handleOpenAuth('register'))}
            onOpenAuth={handleOpenAuth}
            onTrackOrder={handleDirectTrack}
          />
        )}

        {currentTab === 'track-public' && (
          <div className="pt-4">
            <OrderTrackingView
              initialJobId={targetTrackingJobId}
              onOpenBooking={() => (user ? setIsBookingOpen(true) : handleOpenAuth('register'))}
            />
          </div>
        )}

        {/* CUSTOMER VIEWS */}
        {currentTab === 'customer-home' && (
          <CustomerHome
            onOpenBooking={() => setIsBookingOpen(true)}
            onNavigateTab={setCurrentTab}
          />
        )}

        {currentTab === 'my-appointments' && (
          <MyAppointments onOpenBooking={() => setIsBookingOpen(true)} />
        )}

        {currentTab === 'track-order' && (
          <OrderTrackingView
            initialJobId={targetTrackingJobId}
            onOpenBooking={() => setIsBookingOpen(true)}
          />
        )}

        {currentTab === 'measurements' && <CustomerProfile />}
        {currentTab === 'profile' && <CustomerProfile />}

        {(currentTab === 'notifications' || currentTab === 'admin-notifications') && (
          <NotificationsView onNavigateTab={setCurrentTab} />
        )}

        {/* ADMIN VIEWS */}
        {currentTab === 'admin-dashboard' && (
          <AdminDashboard
            onNavigateTab={setCurrentTab}
            onOpenCreateJobFromApt={(apt) => setJobFromApt(apt)}
          />
        )}

        {currentTab === 'admin-appointments' && (
          <AdminAppointments onOpenCreateJob={(apt) => setJobFromApt(apt)} />
        )}

        {currentTab === 'admin-orders' && <AdminOrders />}

        {currentTab === 'admin-capacity' && <AdminCapacity />}

        {currentTab === 'admin-customers' && <AdminCustomers />}

        {currentTab === 'admin-settings' && <AdminSettings />}
      </main>

      {/* Footer */}
      <Footer
        onNavigateTab={setCurrentTab}
        onOpenBooking={() => (user ? setIsBookingOpen(true) : handleOpenAuth('register'))}
      />

      {/* Auth Modal (Login / Register / Forgot Password / 1-Click Demo) */}
      <AuthModal
        isOpen={isAuthOpen}
        initialMode={authMode}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={() => {
          // Tab update handled by useEffect
        }}
      />

      {/* Book Appointment Wizard (5-Step with capacity check 10/hour) */}
      <BookAppointmentWizard
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        onOpenAppointments={() => setCurrentTab('my-appointments')}
      />

      {/* Convert Appointment to Job Modal */}
      {jobFromApt && (
        <CreateJobModal
          isOpen={!!jobFromApt}
          fromAppointment={jobFromApt}
          onClose={() => setJobFromApt(null)}
          onJobCreated={() => {
            setJobFromApt(null);
            setCurrentTab('admin-orders');
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <MainApp />
      </NotificationProvider>
    </AuthProvider>
  );
}
