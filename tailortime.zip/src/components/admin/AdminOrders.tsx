import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Order, OrderStage } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Package,
  Search,
  Plus,
  Scissors,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Filter,
  Check,
} from 'lucide-react';
import { UpdateStageModal } from './UpdateStageModal';
import { CreateJobModal } from './CreateJobModal';

export const AdminOrders: React.FC = () => {
  const { showToast } = useNotifications();

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState('all');

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [stageUpdateOrder, setStageUpdateOrder] = useState<Order | null>(null);

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      const res = await api.getOrders({
        search: search || undefined,
        stage: stageFilter,
      });
      setOrders(res.orders);
    } catch (err) {
      console.warn('Failed to load orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [stageFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchOrders();
  };

  const handleQuickMarkReady = async (order: Order) => {
    try {
      await api.updateOrder(order._id, {
        currentStage: 'ready',
        stageNote: 'Garment passed inspection and packed in dust bag. Customer notified.',
      });
      showToast({
        type: 'success',
        title: 'Marked as Ready! 🎉',
        message: `${order.jobId} marked ready. WhatsApp collection alert sent to ${order.customerName}.`,
      });
      fetchOrders();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  const handleQuickMarkCollected = async (order: Order) => {
    try {
      await api.updateOrder(order._id, {
        currentStage: 'collected',
        stageNote: 'Customer collected outfit in boutique. Trial fit verified.',
      });
      showToast({
        type: 'success',
        title: 'Order Completed & Collected 🛍️',
        message: `${order.jobId} marked as collected.`,
      });
      fetchOrders();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
            Craftsmanship Production Pipeline
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Production Jobs
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track garments through cutting, stitching, fitting trials, and customer pickups.
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="self-start sm:self-auto px-5 py-2.5 bg-[#EC4186] hover:bg-[#D82F73] text-white font-bold text-xs rounded-xl shadow-md shadow-[#EC4186]/20 transition flex items-center gap-1.5 active:scale-98"
        >
          <Plus className="w-4 h-4" /> New Job Card
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Job ID, customer, garment type, or phone..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
          />
        </form>

        <div className="flex items-center gap-2">
          <select
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-200 rounded-xl font-medium text-slate-700 bg-white"
          >
            <option value="all">All Stages</option>
            <option value="appointment">Appointment</option>
            <option value="measurement">Measurement</option>
            <option value="cutting">Cutting</option>
            <option value="stitching">Stitching</option>
            <option value="fitting">Fitting</option>
            <option value="alteration">Alteration</option>
            <option value="quality_check">Quality Check</option>
            <option value="ready">Ready for Pickup</option>
            <option value="collected">Collected</option>
          </select>
        </div>
      </div>

      {/* Jobs Grid / List */}
      {isLoading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
          Loading tailoring production jobs...
        </div>
      ) : orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-2">
          <p className="text-sm font-bold text-slate-700">No jobs found</p>
          <p className="text-xs text-slate-400">Try adjusting your search or stage filters.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {orders.map((ord) => {
            const isReady = ord.currentStage === 'ready';
            const isCollected = ord.currentStage === 'collected';

            return (
              <div
                key={ord._id}
                className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs hover:border-[#38124A]/20 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <span className="font-mono font-bold text-xs text-[#38124A]">
                        {ord.jobId}
                      </span>
                      <h3 className="text-sm font-bold text-[#1F2340] line-clamp-1 mt-0.5">
                        {ord.garmentType}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        {ord.customerName} • {ord.phone}
                      </p>
                    </div>

                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider shrink-0 ${
                        isReady
                          ? 'bg-emerald-100 text-emerald-800'
                          : isCollected
                          ? 'bg-slate-200 text-slate-700'
                          : 'bg-pink-100 text-[#EC4186]'
                      }`}
                    >
                      {ord.currentStage.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 py-3 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Target Date</span>
                      <span className="font-semibold text-slate-800">{ord.estimatedCompletion}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Craftsman</span>
                      <span className="font-semibold text-slate-800 truncate block">
                        {ord.assignedTailor}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Price</span>
                      <span className="font-bold text-[#38124A]">₹{ord.price}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Balance</span>
                      <span className="font-bold text-[#EC4186]">
                        ₹{Math.max(0, (ord.price || 0) - (ord.advancePaid || 0))}
                      </span>
                    </div>
                  </div>

                  {ord.notes && (
                    <div className="p-2 bg-[#F8F5FA] rounded-xl text-[11px] text-slate-600 line-clamp-2 mb-2">
                      <span className="font-semibold">Notes: </span>
                      {ord.notes}
                    </div>
                  )}

                  {ord.measurements && Object.keys(ord.measurements).length > 0 && (
                    <div className="flex flex-wrap gap-1 text-[10px] text-slate-500 mb-3">
                      {Object.entries(ord.measurements).map(([k, v]) => (
                        <span key={k} className="bg-slate-100 px-1.5 py-0.5 rounded capitalize">
                          {k}: {v}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-1.5">
                  <button
                    onClick={() => setStageUpdateOrder(ord)}
                    className="px-3 py-1.5 bg-[#38124A] hover:bg-[#270A34] text-white rounded-xl text-xs font-semibold transition flex items-center gap-1"
                  >
                    Update Stage <ArrowRight className="w-3 h-3" />
                  </button>

                  <div className="flex items-center gap-1">
                    {!isReady && !isCollected && (
                      <button
                        onClick={() => handleQuickMarkReady(ord)}
                        className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold transition"
                        title="Mark Ready and notify customer"
                      >
                        Ready 🎉
                      </button>
                    )}

                    {isReady && !isCollected && (
                      <button
                        onClick={() => handleQuickMarkCollected(ord)}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-black text-white rounded-xl text-xs font-semibold transition"
                        title="Mark as collected"
                      >
                        Collected 🛍️
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modals */}
      <CreateJobModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onJobCreated={fetchOrders}
      />

      <UpdateStageModal
        order={stageUpdateOrder}
        isOpen={!!stageUpdateOrder}
        onClose={() => setStageUpdateOrder(null)}
        onUpdated={fetchOrders}
      />
    </div>
  );
};
