import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { AnalyticsResponse, Appointment } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Package,
  CheckCircle2,
  Clock,
  AlertTriangle,
  TrendingUp,
  Users,
  Scissors,
  ArrowRight,
  Sparkles,
  Check,
  X,
  Plus,
} from 'lucide-react';

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
  onOpenCreateJobFromApt?: (apt: Appointment) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateTab,
  onOpenCreateJobFromApt,
}) => {
  const { showToast } = useNotifications();
  const [analytics, setAnalytics] = useState<AnalyticsResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAnalytics = async () => {
    try {
      const data = await api.getAnalytics();
      setAnalytics(data);
    } catch (err) {
      console.warn('Failed to load analytics:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const handleMarkAttended = async (id: string) => {
    try {
      await api.updateAppointment(id, { status: 'completed' });
      showToast({
        type: 'success',
        title: 'Customer Attended',
        message: 'Appointment marked as completed.',
      });
      fetchAnalytics();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  const handleMarkNoShow = async (id: string) => {
    try {
      await api.updateAppointment(id, { status: 'no-show' });
      showToast({
        type: 'warning',
        title: 'Marked as No-Show',
        message: 'Slot marked as no-show.',
      });
      fetchAnalytics();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  if (isLoading || !analytics) {
    return (
      <div className="py-24 text-center text-xs text-slate-400">
        <div className="animate-spin w-8 h-8 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-3" />
        Loading shop dashboard analytics...
      </div>
    );
  }

  const { summary, alerts, stageCounts, todayAppointments, recentOrders } = analytics;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
              Shop Management System
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Master Tailor Dashboard
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time shop capacity, fitting appointments schedule, and production bottlenecks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('admin-orders')}
            className="px-4 py-2 bg-[#EC4186] hover:bg-[#D82F73] text-white text-xs font-bold rounded-xl shadow-sm transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> New Tailoring Job
          </button>
          <button
            onClick={() => onNavigateTab('admin-capacity')}
            className="px-4 py-2 bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 text-xs font-bold rounded-xl transition shadow-2xs flex items-center gap-1.5"
          >
            <Clock className="w-4 h-4 text-[#38124A]" /> Slot Capacity
          </button>
        </div>
      </div>

      {/* Actionable Alerts Ribbon */}
      {alerts && alerts.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {alerts.map((al, idx) => {
            const styles = {
              info: 'bg-blue-50 border-blue-200 text-blue-900',
              success: 'bg-emerald-50 border-emerald-200 text-emerald-900',
              warning: 'bg-amber-50 border-amber-200 text-amber-900',
            };
            return (
              <div
                key={idx}
                className={`p-4 rounded-2xl border text-xs flex items-start gap-3 shadow-2xs ${styles[al.type]}`}
              >
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold">{al.title}</h4>
                  <p className="opacity-90 mt-0.5 leading-relaxed">{al.message}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Today's Appointments
          </span>
          <p className="text-2xl font-extrabold text-[#38124A] mt-1">
            {summary.todayAppointmentsCount}
          </p>
          <span className="text-[10px] text-slate-500 mt-1 block">Scheduled fittings</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            In Production
          </span>
          <p className="text-2xl font-extrabold text-[#EC4186] mt-1">{summary.inProduction}</p>
          <span className="text-[10px] text-slate-500 mt-1 block">Cutting/Stitching</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Ready for Pickup
          </span>
          <p className="text-2xl font-extrabold text-emerald-600 mt-1">{summary.readyOrders}</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">Awaiting customer</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Completed Orders
          </span>
          <p className="text-2xl font-extrabold text-slate-800 mt-1">{summary.completedOrders}</p>
          <span className="text-[10px] text-slate-500 mt-1 block">Delivered & collected</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            On-Time Delivery
          </span>
          <p className="text-2xl font-extrabold text-[#38124A] mt-1">{summary.onTimeRate}%</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">High reliability</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Avg. In-Store Wait
          </span>
          <p className="text-2xl font-extrabold text-emerald-600 mt-1">{summary.averageWaitMinutes}m</p>
          <span className="text-[10px] text-slate-500 mt-1 block">Down from 45m</span>
        </div>
      </div>

      {/* Production Pipeline Distribution */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-[#1F2340]">Production Pipeline Overview</h3>
            <p className="text-xs text-slate-500">Live distribution of active jobs across craftsmanship stages</p>
          </div>
          <button
            onClick={() => onNavigateTab('admin-orders')}
            className="text-xs font-bold text-[#EC4186] hover:underline"
          >
            Manage All Jobs →
          </button>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-2 text-center">
          {[
            { key: 'appointment', label: 'Consult', icon: '📅' },
            { key: 'measurement', label: 'Measure', icon: '📐' },
            { key: 'cutting', label: 'Cutting', icon: '✂️' },
            { key: 'stitching', label: 'Stitching', icon: '🧵' },
            { key: 'fitting', label: 'Fitting', icon: '🪞' },
            { key: 'alteration', label: 'Alteration', icon: '🪡' },
            { key: 'quality_check', label: 'QC Test', icon: '🔍' },
            { key: 'ready', label: 'Ready', icon: '🎉' },
            { key: 'collected', label: 'Collected', icon: '🛍️' },
          ].map((st) => {
            const count = stageCounts[st.key] || 0;
            const isHighlight = st.key === 'ready' && count > 0;

            return (
              <div
                key={st.key}
                onClick={() => onNavigateTab('admin-orders')}
                className={`p-3 rounded-2xl border transition cursor-pointer ${
                  isHighlight
                    ? 'border-emerald-300 bg-emerald-50/60 shadow-2xs'
                    : 'border-slate-100 bg-[#F8F5FA] hover:border-slate-200'
                }`}
              >
                <span className="text-base">{st.icon}</span>
                <span className="block text-xl font-extrabold text-[#38124A] mt-1">{count}</span>
                <span className="block text-[10px] font-semibold text-slate-500 truncate mt-0.5">
                  {st.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Today's Appointments & Recent Orders */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Today's Appointments Schedule */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-[#1F2340]">Today's Fitting Schedule</h3>
              <p className="text-xs text-slate-500">Appointments reserved for today (10/hour max)</p>
            </div>
            <button
              onClick={() => onNavigateTab('admin-appointments')}
              className="text-xs font-bold text-[#EC4186] hover:underline"
            >
              View All →
            </button>
          </div>

          {todayAppointments.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No appointments scheduled for today yet.
            </div>
          ) : (
            <div className="space-y-3">
              {todayAppointments.map((apt) => (
                <div
                  key={apt._id}
                  className="p-3.5 rounded-2xl bg-[#F8F5FA] border border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#1F2340]">{apt.customerName}</span>
                      <span className="text-[10px] font-mono text-slate-400">({apt.appointmentId})</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      <strong>{apt.service}</strong> • {apt.timeSlot} • {apt.phone}
                    </p>
                    {apt.notes && (
                      <p className="text-[11px] text-slate-400 italic line-clamp-1 mt-0.5">
                        "{apt.notes}"
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {apt.status === 'confirmed' || apt.status === 'pending' ? (
                      <>
                        <button
                          onClick={() => handleMarkAttended(apt._id)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition"
                          title="Mark attended"
                        >
                          Attended ✓
                        </button>
                        <button
                          onClick={() => onOpenCreateJobFromApt?.(apt)}
                          className="px-2.5 py-1 bg-[#38124A] hover:bg-[#270A34] text-white rounded-lg text-xs font-semibold transition"
                          title="Start tailoring job card"
                        >
                          + Job
                        </button>
                        <button
                          onClick={() => handleMarkNoShow(apt._id)}
                          className="px-2 py-1 text-slate-400 hover:text-rose-600 rounded-lg text-xs transition"
                          title="Mark no-show"
                        >
                          ✕
                        </button>
                      </>
                    ) : (
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 uppercase">
                        {apt.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Jobs In Production */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-[#1F2340]">Recent Production Jobs</h3>
              <p className="text-xs text-slate-500">Active garment crafts and target delivery dates</p>
            </div>
            <button
              onClick={() => onNavigateTab('admin-orders')}
              className="text-xs font-bold text-[#EC4186] hover:underline"
            >
              View Pipeline →
            </button>
          </div>

          <div className="space-y-3">
            {recentOrders.map((ord) => (
              <div
                key={ord._id}
                className="p-3.5 rounded-2xl bg-[#F8F5FA] border border-slate-100 flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[#38124A]">{ord.jobId}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                        ord.currentStage === 'ready'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ord.currentStage === 'collected'
                          ? 'bg-slate-200 text-slate-700'
                          : 'bg-pink-100 text-[#EC4186]'
                      }`}
                    >
                      {ord.currentStage.replace('_', ' ')}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-[#1F2340] mt-1">{ord.garmentType}</h4>
                  <p className="text-[11px] text-slate-500">
                    Customer: {ord.customerName} • Target: {ord.estimatedCompletion}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-[#38124A] block">₹{ord.price}</span>
                  <span className="text-[10px] text-slate-400 block">{ord.assignedTailor}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
