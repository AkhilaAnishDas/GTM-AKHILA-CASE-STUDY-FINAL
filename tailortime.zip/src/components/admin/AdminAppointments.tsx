import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Appointment, AppointmentStatus } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Clock,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Plus,
  Scissors,
  Check,
  X,
  Filter,
} from 'lucide-react';

interface AdminAppointmentsProps {
  onOpenCreateJob: (apt: Appointment) => void;
}

export const AdminAppointments: React.FC<AdminAppointmentsProps> = ({ onOpenCreateJob }) => {
  const { showToast } = useNotifications();

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('');

  const fetchAppointments = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAppointments({
        search: search || undefined,
        status: statusFilter,
        date: dateFilter || undefined,
      });
      setAppointments(res.appointments);
    } catch (err) {
      console.warn('Failed to load appointments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [statusFilter, dateFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAppointments();
  };

  const handleUpdateStatus = async (id: string, status: AppointmentStatus) => {
    try {
      await api.updateAppointment(id, { status });
      showToast({
        type: 'success',
        title: 'Status Updated',
        message: `Appointment updated to ${status}.`,
      });
      fetchAppointments();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Update Failed', message: err.message });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
            Booking Schedule Management
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Appointments
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Review customer bookings, manage capacity, and convert appointments to active job cards.
          </p>
        </div>

        <button
          onClick={() => {
            setDateFilter('');
            setStatusFilter('all');
            setSearch('');
          }}
          className="self-start sm:self-auto px-3.5 py-1.5 bg-white border border-slate-200 text-xs font-semibold text-slate-600 rounded-xl hover:bg-slate-50 transition"
        >
          Reset Filters
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <form onSubmit={handleSearchSubmit} className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by customer name, phone, or appointment ID..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
          />
        </form>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Date:</span>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-2 py-1 text-xs border border-slate-200 rounded-lg"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-200 rounded-xl font-medium text-slate-700 bg-white"
          >
            <option value="all">All Statuses</option>
            <option value="confirmed">Confirmed</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
            <option value="no-show">No-show</option>
          </select>
        </div>
      </div>

      {/* Appointments Table */}
      {isLoading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
          Loading appointments...
        </div>
      ) : appointments.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-2">
          <p className="text-sm font-bold text-slate-700">No appointments found</p>
          <p className="text-xs text-slate-400">Try adjusting your date or status filters.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F8F5FA] border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">ID & Customer</th>
                  <th className="p-4">Service</th>
                  <th className="p-4">Date & Slot</th>
                  <th className="p-4">Notes</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.map((apt) => (
                  <tr key={apt._id} className="hover:bg-slate-50/50 transition">
                    <td className="p-4">
                      <span className="font-mono font-bold text-slate-400 block text-[11px]">
                        {apt.appointmentId}
                      </span>
                      <span className="font-bold text-slate-900 text-xs">{apt.customerName}</span>
                      <span className="text-slate-400 block text-[10px]">{apt.phone}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold text-slate-800">{apt.service}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-medium text-slate-700 block">{apt.date}</span>
                      <span className="text-[#EC4186] font-semibold text-[11px]">{apt.timeSlot}</span>
                    </td>
                    <td className="p-4 max-w-xs">
                      <span className="text-slate-500 text-[11px] line-clamp-2">
                        {apt.notes || '—'}
                      </span>
                    </td>
                    <td className="p-4">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                          apt.status === 'confirmed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : apt.status === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : apt.status === 'completed'
                            ? 'bg-purple-100 text-[#38124A]'
                            : apt.status === 'cancelled'
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {apt.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {apt.status === 'pending' && (
                          <button
                            onClick={() => handleUpdateStatus(apt._id, 'confirmed')}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-[11px] transition"
                            title="Confirm appointment"
                          >
                            Approve
                          </button>
                        )}

                        {apt.status === 'confirmed' && (
                          <>
                            <button
                              onClick={() => handleUpdateStatus(apt._id, 'completed')}
                              className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-semibold rounded-lg text-[11px] transition"
                              title="Mark attended / completed"
                            >
                              Attended ✓
                            </button>
                            <button
                              onClick={() => onOpenCreateJob(apt)}
                              className="px-2.5 py-1 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold rounded-lg text-[11px] transition flex items-center gap-1 shadow-2xs"
                              title="Convert to production job card"
                            >
                              <Scissors className="w-3 h-3" /> Job Card
                            </button>
                            <button
                              onClick={() => handleUpdateStatus(apt._id, 'no-show')}
                              className="px-2 py-1 text-slate-400 hover:text-rose-600 rounded-lg text-[11px] transition"
                              title="Mark as no-show"
                            >
                              No-show
                            </button>
                          </>
                        )}

                        {apt.status !== 'cancelled' && apt.status !== 'completed' && (
                          <button
                            onClick={() => handleUpdateStatus(apt._id, 'cancelled')}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition"
                            title="Cancel appointment"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
