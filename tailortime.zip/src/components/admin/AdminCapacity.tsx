import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { CapacityResponse, SlotCapacity } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Clock,
  Calendar,
  Users,
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Percent,
} from 'lucide-react';

export const AdminCapacity: React.FC = () => {
  const { showToast } = useNotifications();
  const todayStr = new Date().toISOString().split('T')[0];

  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [capacityData, setCapacityData] = useState<CapacityResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSlotDetails, setSelectedSlotDetails] = useState<SlotCapacity | null>(null);

  const fetchCapacity = async (date: string) => {
    setIsLoading(true);
    try {
      const data = await api.getCapacity(date);
      setCapacityData(data);
      if (selectedSlotDetails) {
        const updated = data.slots.find((s) => s.timeSlot === selectedSlotDetails.timeSlot);
        if (updated) setSelectedSlotDetails(updated);
      }
    } catch (err) {
      console.warn('Failed to load capacity matrix:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCapacity(selectedDate);
  }, [selectedDate]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
            Smart Queue Prevention
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Fitting Capacity Management
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Enforcing strict max 10 appointments per hour to eliminate waiting queues and ensure personal fitting service.
          </p>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-2 bg-white px-3.5 py-2 rounded-2xl border border-slate-200 shadow-2xs">
          <Calendar className="w-4 h-4 text-[#38124A]" />
          <span className="text-xs font-semibold text-slate-700">Date:</span>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="text-xs font-bold text-[#38124A] focus:outline-none cursor-pointer"
          />
        </div>
      </div>

      {/* Capacity Highlights */}
      {capacityData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Max Slot Capacity
            </span>
            <p className="text-3xl font-extrabold text-[#38124A] mt-1">
              {capacityData.maxCapacityPerSlot}
            </p>
            <span className="text-xs text-slate-500">Appointments per hour</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Day Bookings
            </span>
            <p className="text-3xl font-extrabold text-[#EC4186] mt-1">
              {capacityData.totalBooked}
            </p>
            <span className="text-xs text-slate-500">Reserved fitting slots</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Remaining Openings
            </span>
            <p className="text-3xl font-extrabold text-emerald-600 mt-1">
              {capacityData.totalAvailable}
            </p>
            <span className="text-xs text-slate-500">Unbooked fitting spots</span>
          </div>

          <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Shop Occupancy
            </span>
            <p className="text-3xl font-extrabold text-[#38124A] mt-1">
              {capacityData.occupancyPercentage}%
            </p>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-[#EC4186] h-1.5 rounded-full transition-all"
                style={{ width: `${Math.min(100, capacityData.occupancyPercentage)}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Table: Time Slot | Capacity | Booked | Available */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1F2340]">Slot Capacity Matrix</h3>
            <p className="text-xs text-slate-500">
              Live capacity breakdown for {selectedDate}. Slots automatically lock when booked reaches {capacityData?.maxCapacityPerSlot || 10}.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Available
            </span>
            <span className="flex items-center gap-1.5 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Busy (7-9)
            </span>
            <span className="flex items-center gap-1.5 text-slate-600">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Full (10/10)
            </span>
          </div>
        </div>

        {isLoading ? (
          <div className="py-20 text-center text-xs text-slate-400">
            <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
            Loading capacity matrix...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F8F5FA] border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">Time Slot</th>
                  <th className="p-4">Max Capacity</th>
                  <th className="p-4">Booked</th>
                  <th className="p-4">Available</th>
                  <th className="p-4">Occupancy Bar</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Inspect Bookings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {capacityData?.slots.map((slot) => {
                  const percent = Math.round((slot.booked / slot.capacity) * 100);
                  const isFull = slot.isFull;
                  const isBusy = slot.booked >= 7 && !isFull;

                  return (
                    <tr
                      key={slot.timeSlot}
                      className="hover:bg-slate-50/60 transition cursor-pointer"
                      onClick={() => setSelectedSlotDetails(slot)}
                    >
                      <td className="p-4 font-bold text-slate-800 flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-[#38124A]" />
                        <span>{slot.timeSlot}</span>
                      </td>
                      <td className="p-4 font-mono font-semibold text-slate-600">
                        {slot.capacity}
                      </td>
                      <td className="p-4 font-mono font-bold text-slate-900">
                        {slot.booked}
                      </td>
                      <td className="p-4 font-mono font-bold text-emerald-600">
                        {slot.available}
                      </td>
                      <td className="p-4 w-44">
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-2 rounded-full transition-all ${
                              isFull ? 'bg-rose-500' : isBusy ? 'bg-amber-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, percent)}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">{percent}% filled</span>
                      </td>
                      <td className="p-4">
                        {isFull ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 uppercase">
                            Full (10/10)
                          </span>
                        ) : isBusy ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 uppercase">
                            Near Capacity
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                            Open
                          </span>
                        )}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedSlotDetails(slot);
                          }}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 transition"
                        >
                          View ({slot.appointments.length})
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Slot Bookings Modal / Drawer */}
      {selectedSlotDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
                  Bookings Roster
                </span>
                <h3 className="text-base font-bold text-[#38124A]">
                  {selectedSlotDetails.timeSlot} • {selectedDate}
                </h3>
                <p className="text-xs text-slate-500">
                  {selectedSlotDetails.booked} of {selectedSlotDetails.capacity} capacity booked
                </p>
              </div>
              <button
                onClick={() => setSelectedSlotDetails(null)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {selectedSlotDetails.appointments.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">
                  No appointments booked in this slot yet.
                </p>
              ) : (
                selectedSlotDetails.appointments.map((apt) => (
                  <div
                    key={apt.appointmentId}
                    className="p-3 bg-[#F8F5FA] rounded-xl border border-slate-100 flex items-center justify-between"
                  >
                    <div>
                      <span className="font-mono font-bold text-[10px] text-slate-400 block">
                        {apt.appointmentId}
                      </span>
                      <p className="text-xs font-bold text-slate-800">{apt.customerName}</p>
                      <p className="text-[11px] text-slate-500">{apt.service}</p>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                      {apt.status}
                    </span>
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 text-right">
              <button
                onClick={() => setSelectedSlotDetails(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
