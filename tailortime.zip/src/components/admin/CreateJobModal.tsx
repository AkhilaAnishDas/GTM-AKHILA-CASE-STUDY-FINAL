import React, { useState } from 'react';
import { api } from '../../services/api';
import { Appointment } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import { X, Scissors, Ruler, Check, AlertCircle } from 'lucide-react';

interface CreateJobModalProps {
  isOpen: boolean;
  onClose: () => void;
  fromAppointment?: Appointment | null;
  onJobCreated?: () => void;
}

export const CreateJobModal: React.FC<CreateJobModalProps> = ({
  isOpen,
  onClose,
  fromAppointment,
  onJobCreated,
}) => {
  const { showToast } = useNotifications();

  const [customerName, setCustomerName] = useState(fromAppointment?.customerName || '');
  const [phone, setPhone] = useState(fromAppointment?.phone || '');
  const [service, setService] = useState(fromAppointment?.service || 'New Outfit');
  const [garmentType, setGarmentType] = useState('');
  const [assignedTailor, setAssignedTailor] = useState('Master Tailor Rameshwar');

  const defaultEst = new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0];
  const [estimatedCompletion, setEstimatedCompletion] = useState(defaultEst);
  const [price, setPrice] = useState('2500');
  const [advancePaid, setAdvancePaid] = useState('1000');
  const [notes, setNotes] = useState(fromAppointment?.notes || '');

  // Measurements
  const [chest, setChest] = useState('');
  const [waist, setWaist] = useState('');
  const [shoulder, setShoulder] = useState('');
  const [sleeve, setSleeve] = useState('');
  const [length, setLength] = useState('');
  const [hip, setHip] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // If fromAppointment changed, update state
  React.useEffect(() => {
    if (fromAppointment) {
      setCustomerName(fromAppointment.customerName);
      setPhone(fromAppointment.phone);
      setService(fromAppointment.service);
      setNotes(fromAppointment.notes || '');
    }
  }, [fromAppointment]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim() || !garmentType.trim()) {
      setError('Customer name, phone, and garment type are required');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const measurements: Record<string, string> = {};
    if (chest) measurements.chest = chest.trim();
    if (waist) measurements.waist = waist.trim();
    if (shoulder) measurements.shoulder = shoulder.trim();
    if (sleeve) measurements.sleeve = sleeve.trim();
    if (length) measurements.length = length.trim();
    if (hip) measurements.hip = hip.trim();

    try {
      const res = await api.createOrder({
        customerId: fromAppointment?.customerId,
        customerName: customerName.trim(),
        phone: phone.trim(),
        service,
        garmentType: garmentType.trim(),
        measurements,
        notes: notes.trim(),
        assignedTailor,
        estimatedCompletion,
        price: Number(price) || 0,
        advancePaid: Number(advancePaid) || 0,
        appointmentId: fromAppointment?.appointmentId,
      });

      showToast({
        type: 'success',
        title: 'Job Card Created 🧵',
        message: `Order ${res.order.jobId} created for ${customerName}. WhatsApp alert sent.`,
      });

      onJobCreated?.();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create job card');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#38124A] to-[#EC4186] p-5 text-white flex items-center justify-between shrink-0">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-pink-200">
              {fromAppointment ? `From Appointment ${fromAppointment.appointmentId}` : 'New Job Card'}
            </span>
            <h3 className="text-lg font-serif font-bold">Create Tailoring Production Job</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-white/80 hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Customer Name *</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Riya Mehta"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number *</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Garment Description / Outfit Type *
              </label>
              <input
                type="text"
                required
                value={garmentType}
                onChange={(e) => setGarmentType(e.target.value)}
                placeholder="e.g. Pure Silk Anarkali Suit with Zari Border"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Service Type</label>
              <select
                value={service}
                onChange={(e) => setService(e.target.value as any)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              >
                <option value="New Outfit">New Outfit</option>
                <option value="Alteration">Alteration</option>
                <option value="Measurement">Measurement</option>
                <option value="Fitting">Fitting</option>
                <option value="Pickup / Collection">Pickup / Collection</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Craftsman</label>
              <select
                value={assignedTailor}
                onChange={(e) => setAssignedTailor(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              >
                <option value="Master Tailor Rameshwar">Master Tailor Rameshwar</option>
                <option value="Mohan (Senior Craftsman)">Mohan (Senior Craftsman)</option>
                <option value="Suresh (Alteration Specialist)">Suresh (Alteration Specialist)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Expected Completion Date
              </label>
              <input
                type="date"
                required
                value={estimatedCompletion}
                onChange={(e) => setEstimatedCompletion(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Total Price (₹)</label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Advance (₹)</label>
                <input
                  type="number"
                  value={advancePaid}
                  onChange={(e) => setAdvancePaid(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
              </div>
            </div>
          </div>

          {/* Measurements for this Job Card */}
          <div className="pt-2 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-800 block mb-2">Job Measurements (Inches)</span>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 block">Chest</label>
                <input
                  type="text"
                  placeholder="34 in"
                  value={chest}
                  onChange={(e) => setChest(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block">Waist</label>
                <input
                  type="text"
                  placeholder="28 in"
                  value={waist}
                  onChange={(e) => setWaist(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block">Shoulder</label>
                <input
                  type="text"
                  placeholder="14.5 in"
                  value={shoulder}
                  onChange={(e) => setShoulder(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block">Sleeve</label>
                <input
                  type="text"
                  placeholder="21 in"
                  value={sleeve}
                  onChange={(e) => setSleeve(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block">Length</label>
                <input
                  type="text"
                  placeholder="48 in"
                  value={length}
                  onChange={(e) => setLength(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block">Hip</label>
                <input
                  type="text"
                  placeholder="38 in"
                  value={hip}
                  onChange={(e) => setHip(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Tailor Notes & Finishing Instructions</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Antique gold piping on neck, keep 1.5 in inner margin."
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-[#38124A] hover:bg-[#270A34] text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50"
            >
              {isSubmitting ? 'Creating Job...' : 'Create & Notify Customer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
