import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { User, Appointment, Order, MeasurementRecord } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Users,
  Search,
  Phone,
  Mail,
  MapPin,
  Ruler,
  Calendar,
  Package,
  X,
  Edit2,
  Check,
  ChevronRight,
} from 'lucide-react';

export const AdminCustomers: React.FC = () => {
  const { showToast } = useNotifications();

  const [customers, setCustomers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Selected Customer Details Modal
  const [selectedCustomer, setSelectedCustomer] = useState<any | null>(null);
  const [customerDetails, setCustomerDetails] = useState<{
    customer: User;
    appointments: Appointment[];
    orders: Order[];
    measurements: MeasurementRecord | null;
  } | null>(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);

  // Edit measurements mode inside modal
  const [isEditingMeasurements, setIsEditingMeasurements] = useState(false);
  const [editChest, setEditChest] = useState('');
  const [editWaist, setEditWaist] = useState('');
  const [editShoulder, setEditShoulder] = useState('');
  const [editSleeve, setEditSleeve] = useState('');
  const [editLength, setEditLength] = useState('');
  const [editHip, setEditHip] = useState('');

  const fetchCustomers = async () => {
    setIsLoading(true);
    try {
      const res = await api.getCustomers(search || undefined);
      setCustomers(res.customers);
    } catch (err) {
      console.warn('Failed to load customers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchCustomers();
  };

  const handleSelectCustomer = async (cust: any) => {
    setSelectedCustomer(cust);
    setIsLoadingDetails(true);
    setIsEditingMeasurements(false);

    try {
      const data = await api.getCustomerDetails(cust._id);
      setCustomerDetails(data);
      if (data.measurements) {
        setEditChest(data.measurements.chest || '');
        setEditWaist(data.measurements.waist || '');
        setEditShoulder(data.measurements.shoulder || '');
        setEditSleeve(data.measurements.sleeve || '');
        setEditLength(data.measurements.length || '');
        setEditHip(data.measurements.hip || '');
      } else {
        setEditChest('');
        setEditWaist('');
        setEditShoulder('');
        setEditSleeve('');
        setEditLength('');
        setEditHip('');
      }
    } catch (err) {
      console.warn('Failed to load customer details:', err);
    } finally {
      setIsLoadingDetails(false);
    }
  };

  const handleSaveCustomerMeasurements = async () => {
    if (!selectedCustomer) return;
    try {
      const res = await api.saveMeasurements({
        customerId: selectedCustomer._id,
        customerName: selectedCustomer.name,
        phone: selectedCustomer.phone,
        chest: editChest,
        waist: editWaist,
        shoulder: editShoulder,
        sleeve: editSleeve,
        length: editLength,
        hip: editHip,
      });

      showToast({
        type: 'success',
        title: 'Measurements Updated',
        message: `Saved measurements for ${selectedCustomer.name}.`,
      });

      setIsEditingMeasurements(false);
      // Refresh details
      const refreshed = await api.getCustomerDetails(selectedCustomer._id);
      setCustomerDetails(refreshed);
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
            Client Directory & Records
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Customers
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Browse registered clients, inspect body measurement cards, and review fitting histories.
          </p>
        </div>

        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, or phone..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
          />
        </form>
      </div>

      {/* Customer Cards Grid */}
      {isLoading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
          Loading customers...
        </div>
      ) : customers.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-2">
          <p className="text-sm font-bold text-slate-700">No customers found</p>
          <p className="text-xs text-slate-400">Try adjusting your search query.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {customers.map((cust) => (
            <div
              key={cust._id}
              onClick={() => handleSelectCustomer(cust)}
              className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs hover:border-[#38124A]/25 transition cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#38124A] to-[#EC4186] text-white font-bold text-sm flex items-center justify-center">
                      {cust.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-[#1F2340] group-hover:text-[#EC4186] transition">
                        {cust.name}
                      </h3>
                      <span className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" /> {cust.phone}
                      </span>
                    </div>
                  </div>
                  {cust.hasMeasurements && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-[#38124A]">
                      📐 Measured
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2 py-3 text-center text-xs">
                  <div className="bg-[#F8F5FA] p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Orders</span>
                    <span className="font-extrabold text-[#38124A]">{cust.totalOrders}</span>
                  </div>
                  <div className="bg-[#F8F5FA] p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Active</span>
                    <span className="font-extrabold text-[#EC4186]">{cust.activeJobsCount}</span>
                  </div>
                  <div className="bg-[#F8F5FA] p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 block uppercase">Visits</span>
                    <span className="font-extrabold text-emerald-600">
                      {cust.totalAppointments}
                    </span>
                  </div>
                </div>

                {cust.address && (
                  <p className="text-[11px] text-slate-400 truncate flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    {cust.address}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#EC4186] font-semibold">
                <span>View Full Profile</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Customer Detail Drawer / Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full shadow-2xl border border-slate-100 space-y-6 max-h-[92vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#38124A] to-[#EC4186] text-white font-bold text-base flex items-center justify-center">
                  {selectedCustomer.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-lg font-serif font-bold text-[#38124A]">
                    {selectedCustomer.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedCustomer.phone} • {selectedCustomer.email}
                  </p>
                  {selectedCustomer.address && (
                    <p className="text-[11px] text-slate-400 mt-0.5">{selectedCustomer.address}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isLoadingDetails || !customerDetails ? (
              <div className="py-12 text-center text-xs text-slate-400">
                Loading customer records...
              </div>
            ) : (
              <div className="space-y-6">
                {/* Body Measurements Card */}
                <div className="bg-[#F8F5FA] rounded-2xl p-4 border border-slate-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Ruler className="w-4 h-4 text-[#38124A]" />
                      <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Body Measurements Sheet
                      </h4>
                    </div>
                    {!isEditingMeasurements ? (
                      <button
                        onClick={() => setIsEditingMeasurements(true)}
                        className="text-xs font-bold text-[#EC4186] hover:underline flex items-center gap-1"
                      >
                        <Edit2 className="w-3 h-3" /> Edit Measurements
                      </button>
                    ) : (
                      <button
                        onClick={handleSaveCustomerMeasurements}
                        className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" /> Save Changes
                      </button>
                    )}
                  </div>

                  {!isEditingMeasurements ? (
                    customerDetails.measurements ? (
                      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Chest</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.chest || '—'}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Waist</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.waist || '—'}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Shoulder</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.shoulder || '—'}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Sleeve</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.sleeve || '—'}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Length</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.length || '—'}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-xl">
                          <span className="text-[10px] text-slate-400 block uppercase">Hip</span>
                          <span className="text-xs font-bold text-[#1F2340]">
                            {customerDetails.measurements.hip || '—'}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 py-2">
                        No measurements logged yet for this customer.
                      </p>
                    )
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-400 block">Chest</label>
                        <input
                          type="text"
                          value={editChest}
                          onChange={(e) => setEditChest(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">Waist</label>
                        <input
                          type="text"
                          value={editWaist}
                          onChange={(e) => setEditWaist(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">Shoulder</label>
                        <input
                          type="text"
                          value={editShoulder}
                          onChange={(e) => setEditShoulder(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">Sleeve</label>
                        <input
                          type="text"
                          value={editSleeve}
                          onChange={(e) => setEditSleeve(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">Length</label>
                        <input
                          type="text"
                          value={editLength}
                          onChange={(e) => setEditLength(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block">Hip</label>
                        <input
                          type="text"
                          value={editHip}
                          onChange={(e) => setEditHip(e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-slate-200 rounded-lg text-center"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Active & Past Orders */}
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-[#EC4186]" /> Order History (
                    {customerDetails.orders.length})
                  </h4>
                  {customerDetails.orders.length === 0 ? (
                    <p className="text-xs text-slate-400">No orders logged.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {customerDetails.orders.map((ord) => (
                        <div
                          key={ord._id}
                          className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-[#38124A]">{ord.jobId}</span>
                              <span className="text-[10px] font-bold px-2 py-0.2 rounded-full uppercase bg-pink-100 text-[#EC4186]">
                                {ord.currentStage}
                              </span>
                            </div>
                            <p className="text-slate-800 font-medium mt-0.5">{ord.garmentType}</p>
                          </div>
                          <span className="font-bold text-slate-900">₹{ord.price}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Appointment History */}
                <div>
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#38124A]" /> Appointment History (
                    {customerDetails.appointments.length})
                  </h4>
                  {customerDetails.appointments.length === 0 ? (
                    <p className="text-xs text-slate-400">No appointments recorded.</p>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {customerDetails.appointments.map((apt) => (
                        <div
                          key={apt._id}
                          className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                        >
                          <div>
                            <span className="font-mono text-[10px] text-slate-400">
                              {apt.appointmentId}
                            </span>
                            <p className="font-medium text-slate-800">{apt.service}</p>
                            <p className="text-[11px] text-slate-500">
                              {apt.date} at {apt.timeSlot}
                            </p>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-slate-100 text-slate-700">
                            {apt.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
