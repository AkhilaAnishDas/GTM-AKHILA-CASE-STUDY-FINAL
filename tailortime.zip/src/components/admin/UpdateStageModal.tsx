import React, { useState } from 'react';
import { api } from '../../services/api';
import { Order, OrderStage } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import { X, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

interface UpdateStageModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated?: () => void;
}

const STAGES: { key: OrderStage; label: string; desc: string }[] = [
  { key: 'appointment', label: '1. Appointment', desc: 'Initial fitting & styling consultation' },
  { key: 'measurement', label: '2. Measurement', desc: 'Body measurements logged' },
  { key: 'cutting', label: '3. Cutting', desc: 'Paper patterns drafted & cloth cut' },
  { key: 'stitching', label: '4. Stitching', desc: 'Garment basted & stitched' },
  { key: 'fitting', label: '5. Trial Fitting', desc: 'Client trial fitting in store' },
  { key: 'alteration', label: '6. Alteration', desc: 'Post-fitting tweaks & adjustments' },
  { key: 'quality_check', label: '7. Quality Check', desc: 'Thread trimmed, steam pressed' },
  { key: 'ready', label: '8. Ready for Collection', desc: 'Packed and waiting at desk' },
  { key: 'collected', label: '9. Collected', desc: 'Handed to customer' },
];

export const UpdateStageModal: React.FC<UpdateStageModalProps> = ({
  order,
  isOpen,
  onClose,
  onUpdated,
}) => {
  const { showToast } = useNotifications();

  const [currentStage, setCurrentStage] = useState<OrderStage>(
    order?.currentStage || 'measurement'
  );
  const [stageNote, setStageNote] = useState('');
  const [estimatedCompletion, setEstimatedCompletion] = useState(
    order?.estimatedCompletion || ''
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (order) {
      setCurrentStage(order.currentStage);
      setEstimatedCompletion(order.estimatedCompletion);
      setStageNote('');
    }
  }, [order]);

  if (!isOpen || !order) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      await api.updateOrder(order._id, {
        currentStage,
        stageNote: stageNote.trim() || undefined,
        estimatedCompletion,
      });

      showToast({
        type: 'success',
        title: 'Stage Updated! ✂️',
        message: `${order.jobId} moved to ${currentStage.replace('_', ' ').toUpperCase()}. Customer notified.`,
      });

      onUpdated?.();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update order stage');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <span className="font-mono font-bold text-xs text-[#EC4186]">{order.jobId}</span>
            <h3 className="text-lg font-serif font-bold text-[#38124A]">Update Production Stage</h3>
            <p className="text-xs text-slate-500">{order.garmentType} • {order.customerName}</p>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Select New Stage</label>
            <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto p-1">
              {STAGES.map((st) => {
                const isSelected = currentStage === st.key;
                return (
                  <div
                    key={st.key}
                    onClick={() => setCurrentStage(st.key)}
                    className={`p-2.5 rounded-xl border-2 cursor-pointer transition flex items-center justify-between ${
                      isSelected
                        ? 'border-[#EC4186] bg-pink-50/50 shadow-2xs'
                        : 'border-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <div>
                      <span className={`text-xs font-bold block ${isSelected ? 'text-[#EC4186]' : 'text-slate-800'}`}>
                        {st.label}
                      </span>
                      <span className="text-[11px] text-slate-400">{st.desc}</span>
                    </div>
                    {isSelected && <span className="w-2.5 h-2.5 rounded-full bg-[#EC4186]" />}
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Stage Note / Craft Update (Sent to Customer)
            </label>
            <input
              type="text"
              value={stageNote}
              onChange={(e) => setStageNote(e.target.value)}
              placeholder="e.g. Fabric cut and interlining fused. Ready for trial basting."
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Target Completion Date</label>
            <input
              type="date"
              value={estimatedCompletion}
              onChange={(e) => setEstimatedCompletion(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 bg-[#38124A] hover:bg-[#270A34] text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50 flex items-center gap-1.5"
            >
              {isSubmitting ? 'Updating...' : 'Update & Notify'}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
