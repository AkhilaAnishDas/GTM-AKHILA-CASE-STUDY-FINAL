import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { ShopSettings } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Settings,
  Store,
  Clock,
  Phone,
  Mail,
  MapPin,
  Save,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { showToast } = useNotifications();

  const [shopName, setShopName] = useState('');
  const [tagline, setTagline] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [openingHours, setOpeningHours] = useState('09:00 AM');
  const [closingHours, setClosingHours] = useState('07:00 PM');
  const [slotDurationMinutes, setSlotDurationMinutes] = useState(60);
  const [maxCapacityPerSlot, setMaxCapacityPerSlot] = useState(10);
  const [announcement, setAnnouncement] = useState('');
  const [workingDays, setWorkingDays] = useState<string[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const fetchSettings = async () => {
    setIsLoading(true);
    try {
      const res = await api.getShopSettings();
      const s = res.shop;
      setShopName(s.shopName);
      setTagline(s.tagline);
      setAddress(s.address);
      setPhone(s.phone);
      setEmail(s.email);
      setOpeningHours(s.openingHours);
      setClosingHours(s.closingHours);
      setSlotDurationMinutes(s.slotDurationMinutes);
      setMaxCapacityPerSlot(s.maxCapacityPerSlot || 10);
      setAnnouncement(s.announcement || '');
      setWorkingDays(s.workingDays || []);
    } catch (err) {
      console.warn('Failed to load shop settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleToggleDay = (day: string) => {
    if (workingDays.includes(day)) {
      setWorkingDays(workingDays.filter((d) => d !== day));
    } else {
      setWorkingDays([...workingDays, day]);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await api.updateShopSettings({
        shopName,
        tagline,
        address,
        phone,
        email,
        openingHours,
        closingHours,
        slotDurationMinutes,
        maxCapacityPerSlot,
        workingDays,
        announcement,
      });

      showToast({
        type: 'success',
        title: 'Settings Saved',
        message: 'TailorTime shop parameters and fitting capacity updated.',
      });
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDefaults = async () => {
    try {
      await api.resetDemo();
      showToast({
        type: 'info',
        title: 'Demo Data Reset',
        message: 'Seed data restored successfully.',
      });
      fetchSettings();
    } catch (err: any) {
      showToast({ type: 'error', title: 'Error', message: err.message });
    }
  };

  if (isLoading) {
    return (
      <div className="py-20 text-center text-xs text-slate-400">
        <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
        Loading shop configuration...
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">
            Boutique Configuration
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Shop Settings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Configure boutique profile, operating schedule, and fitting room capacity limits.
          </p>
        </div>

        <button
          type="button"
          onClick={handleResetDefaults}
          className="self-start sm:self-auto px-3.5 py-1.5 bg-white border border-slate-200 text-xs font-semibold text-slate-600 rounded-xl hover:bg-slate-50 transition flex items-center gap-1.5 shadow-2xs"
          title="Reset database to initial demo state"
        >
          <RotateCcw className="w-3.5 h-3.5 text-purple-600" /> Reset Demo Data
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Boutique Profile */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Store className="w-5 h-5 text-[#38124A]" />
            <h3 className="text-base font-bold text-[#1F2340]">Boutique Information</h3>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Shop Name</label>
              <input
                type="text"
                required
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Shop Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Customer Care Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Shop Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Customer Announcement Banner (Shown on Dashboard)
              </label>
              <input
                type="text"
                value={announcement}
                onChange={(e) => setAnnouncement(e.target.value)}
                placeholder="e.g. Diwali Rush: Please book your trial fitting slots 48 hours in advance."
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>
          </div>
        </div>

        {/* Capacity & Operating Hours */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Clock className="w-5 h-5 text-[#EC4186]" />
            <h3 className="text-base font-bold text-[#1F2340]">
              Operating Hours & Fitting Capacity Limits
            </h3>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Max Fitting Appointments Per Hour
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={maxCapacityPerSlot}
                  onChange={(e) => setMaxCapacityPerSlot(Number(e.target.value))}
                  className="w-32 px-3 py-2 text-sm font-bold border border-slate-200 rounded-xl text-center focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
                <span className="text-xs text-slate-500">
                  Default: <strong>10 per hour</strong> (Prevents queue overcrowding)
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Default Slot Duration
              </label>
              <select
                value={slotDurationMinutes}
                onChange={(e) => setSlotDurationMinutes(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              >
                <option value={30}>30 Minutes</option>
                <option value={45}>45 Minutes</option>
                <option value={60}>60 Minutes (Standard)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Opening Time</label>
              <input
                type="text"
                value={openingHours}
                onChange={(e) => setOpeningHours(e.target.value)}
                placeholder="09:00 AM"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Closing Time</label>
              <input
                type="text"
                value={closingHours}
                onChange={(e) => setClosingHours(e.target.value)}
                placeholder="07:00 PM"
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">Working Days</label>
            <div className="flex flex-wrap gap-2">
              {DAYS.map((day) => {
                const isActive = workingDays.includes(day);
                return (
                  <button
                    key={day}
                    type="button"
                    onClick={() => handleToggleDay(day)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                      isActive
                        ? 'bg-[#38124A] text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-8 py-3 bg-[#38124A] hover:bg-[#270A34] text-white font-bold text-sm rounded-2xl shadow-lg shadow-[#38124A]/25 transition active:scale-98 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Saving Changes...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </div>
  );
};
