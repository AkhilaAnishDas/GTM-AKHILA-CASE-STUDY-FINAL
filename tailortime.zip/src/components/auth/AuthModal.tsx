import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { X, Sparkles, Scissors, Lock, Mail, User as UserIcon, Phone, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  onSuccess?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onSuccess,
}) => {
  const { login, register, switchDemoRole } = useAuth();
  const { showToast } = useNotifications();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [role, setRole] = useState<'customer' | 'admin'>('customer');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      if (mode === 'login') {
        await login(email, password);
        showToast({
          type: 'success',
          title: 'Welcome Back!',
          message: 'You have signed in to TailorTime.',
        });
        onSuccess?.();
        onClose();
      } else if (mode === 'register') {
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          setIsSubmitting(false);
          return;
        }
        if (password.length < 6) {
          setError('Password must be at least 6 characters');
          setIsSubmitting(false);
          return;
        }
        await register({
          name,
          email,
          phone,
          password,
          role,
          address,
        });
        showToast({
          type: 'success',
          title: 'Account Created 🎉',
          message: 'Welcome to TailorTime! You can now book appointments.',
        });
        onSuccess?.();
        onClose();
      } else if (mode === 'forgot') {
        setForgotSent(true);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDemo = async (targetRole: 'customer' | 'admin') => {
    setIsSubmitting(true);
    setError(null);
    try {
      await switchDemoRole(targetRole);
      showToast({
        type: 'success',
        title: `Logged in as ${targetRole === 'admin' ? 'Master Tailor' : 'Customer'}`,
        message: 'Loaded demo profile with sample appointments and orders.',
      });
      onSuccess?.();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#38124A] via-[#521E6B] to-[#EC4186] p-6 text-white text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="w-12 h-12 rounded-2xl bg-white/15 backdrop-blur-md mx-auto flex items-center justify-center mb-3">
            <Scissors className="w-6 h-6 transform -rotate-45" />
          </div>
          <h3 className="text-xl font-serif font-bold">
            {mode === 'login' ? 'Welcome Back' : mode === 'register' ? 'Join TailorTime' : 'Reset Password'}
          </h3>
          <p className="text-xs text-white/80 mt-1">
            {mode === 'login'
              ? 'Access your appointments and live tailoring jobs'
              : mode === 'register'
              ? 'Less queue. More certainty. Premium fittings.'
              : 'Enter your email to receive recovery instructions'}
          </p>
        </div>

        {/* 1-Click Fast Demo Logins (Highlight for testing & college demos!) */}
        {mode !== 'forgot' && (
          <div className="bg-gradient-to-b from-purple-50/50 to-white px-6 pt-5 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#38124A] mb-2.5 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#EC4186]" /> Instant Demo Access
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleDemo('customer')}
                disabled={isSubmitting}
                className="flex items-center justify-center gap-2 p-2.5 rounded-xl border border-pink-200 bg-white hover:bg-pink-50/50 text-[#EC4186] font-semibold text-xs shadow-2xs hover:shadow-xs transition active:scale-98"
              >
                <span>👗</span> Customer (Riya)
              </button>
              <button
                type="button"
                onClick={() => handleDemo('admin')}
                disabled={isSubmitting}
                className="flex items-center justify-center gap-2 p-2.5 rounded-xl border border-purple-200 bg-white hover:bg-purple-50/50 text-[#38124A] font-semibold text-xs shadow-2xs hover:shadow-xs transition active:scale-98"
              >
                <span>✂️</span> Tailor (Admin)
              </button>
            </div>
          </div>
        )}

        {/* Auth Mode Toggle */}
        {mode !== 'forgot' && (
          <div className="flex border-b border-slate-100 px-6 pt-3">
            <button
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`flex-1 pb-3 text-sm font-semibold text-center border-b-2 transition ${
                mode === 'login'
                  ? 'border-[#EC4186] text-[#EC4186]'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`flex-1 pb-3 text-sm font-semibold text-center border-b-2 transition ${
                mode === 'register'
                  ? 'border-[#EC4186] text-[#EC4186]'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              New Customer
            </button>
          </div>
        )}

        {/* Error notification */}
        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          {mode === 'forgot' ? (
            forgotSent ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-xl font-bold">
                  ✓
                </div>
                <h4 className="text-sm font-bold text-slate-800">Password Reset Email Sent!</h4>
                <p className="text-xs text-slate-600">
                  We have sent instructions to <strong>{email}</strong>. For this demo prototype, you can also log in directly using the 1-click buttons above.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setForgotSent(false);
                  }}
                  className="text-xs font-semibold text-[#EC4186] hover:underline"
                >
                  Back to Sign In
                </button>
              </div>
            ) : (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. riya@example.com"
                      className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold text-sm rounded-xl transition shadow-md"
                >
                  Send Reset Link
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="text-xs text-slate-500 hover:text-slate-800"
                  >
                    Back to Sign In
                  </button>
                </div>
              </>
            )
          ) : (
            <>
              {mode === 'register' && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Riya Mehta"
                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (For WhatsApp Alerts)</label>
                    <div className="relative">
                      <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="riya@example.com"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700">Password</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setMode('forgot')}
                      className="text-[11px] text-[#EC4186] font-medium hover:underline"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                  />
                </div>
              </div>

              {mode === 'register' && (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm Password</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                      <input
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery / Home Address (Optional)</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Flat 304, Koramangala, Bengaluru"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                    />
                  </div>
                </>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold text-sm rounded-xl transition shadow-md shadow-[#38124A]/20 active:scale-98"
              >
                {isSubmitting
                  ? 'Please wait...'
                  : mode === 'login'
                  ? 'Sign In to Account'
                  : 'Create TailorTime Account'}
              </button>

              <div className="text-center pt-2">
                <p className="text-xs text-slate-500">
                  {mode === 'login' ? "Don't have an account? " : 'Already registered? '}
                  <button
                    type="button"
                    onClick={() => {
                      setMode(mode === 'login' ? 'register' : 'login');
                      setError(null);
                    }}
                    className="font-bold text-[#EC4186] hover:underline"
                  >
                    {mode === 'login' ? 'Sign Up' : 'Log In'}
                  </button>
                </p>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
};
