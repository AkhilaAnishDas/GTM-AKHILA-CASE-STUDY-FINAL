import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Appointment, SlotCapacity } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Calendar,
  Clock,
  Scissors,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Search,
  Check,
  X,
  AlertCircle,
} from 'lucide-react';

interface MyAppointmentsProps {
  onOpenBooking: () => void;
}

export const MyAppointments: React.FC<MyAppointmentsProps> = ({ onOpenBooking }) => {
  const { showToast } = useNotifications();

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Reschedule Modal State
  const [rescheduleTarget, setRescheduleTarget] = useState<Appointment | null>(null);
  const [newDate, setNewDate] = useState<string>('');
  const [availableSlots, setAvailableSlots] = useState<SlotCapacity[]>([]);
  const [newSlot, setNewSlot] = useState<string>('');
  const [isLoadingSlots, setIsLoadingSlots] = useState(false);
  const [rescheduleError, setRescheduleError] = useState<string | null>(null);
  const [isRescheduling, setIsRescheduling] = useState(false);

  // Cancel Confirmation State
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);

  const fetchAppointments = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAppointments();
      setAppointments(res.appointments);
    } catch (err) {
      console.warn('Failed to load appointments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  // When opening reschedule modal, fetch slots
  useEffect(() => {
    if (!rescheduleTarget || !newDate) return;

    setIsLoadingSlots(true);
    setRescheduleError(null);
    setNewSlot('');

    api
      .getCapacity(newDate)
      .then((res) => {
        setAvailableSlots(res.slots);
      })
      .catch((err) => {
        setRescheduleError(err.message || 'Failed to load slot capacity');
      })
      .finally(() => {
        setIsLoadingSlots(false);
      });
  }, [rescheduleTarget, newDate]);

  const handleOpenReschedule = (apt: Appointment) => {
    setRescheduleTarget(apt);
    setNewDate(apt.date);
    setNewSlot(apt.timeSlot);
    setRescheduleError(null);
  };

  const handleConfirmReschedule = async () => {
    if (!rescheduleTarget || !newDate || !newSlot) return;

    setIsRescheduling(true);
    setRescheduleError(null);

    try {
      await api.updateAppointment(rescheduleTarget._id, {
        date: newDate,
        timeSlot: newSlot,
      });

      showToast({
        type: 'success',
        title: 'Appointment Rescheduled 📅',
        message: `Your booking ${rescheduleTarget.appointmentId} has been moved to ${newDate} at ${newSlot}.`,
      });

      setRescheduleTarget(null);
      fetchAppointments();
    } catch (err: any) {
      setRescheduleError(err.message || 'Failed to reschedule. Selected slot may be full.');
    } finally {
      setIsRescheduling(false);
    }
  };

  const handleConfirmCancel = async () => {
    if (!cancelTarget) return;

    setIsCancelling(true);
    try {
      await api.cancelAppointment(cancelTarget._id);
      showToast({
        type: 'info',
        title: 'Appointment Cancelled',
        message: `Appointment ${cancelTarget.appointmentId} has been cancelled.`,
      });
      setCancelTarget(null);
      fetchAppointments();
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Error',
        message: err.message || 'Failed to cancel appointment',
      });
    } finally {
      setIsCancelling(false);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredAppointments = appointments.filter((apt) => {
    // Filter by tab
    if (activeTab === 'upcoming') {
      if (apt.status === 'cancelled') return false;
      if (apt.status === 'completed' || apt.status === 'no-show') return false;
      // It is confirmed or pending
    } else if (activeTab === 'past') {
      if (apt.status === 'cancelled') return false;
      if (apt.status !== 'completed' && apt.status !== 'no-show' && apt.date >= todayStr) return false;
    } else if (activeTab === 'cancelled') {
      if (apt.status !== 'cancelled') return false;
    }

    // Search filter
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchId = apt.appointmentId.toLowerCase().includes(q);
      const matchService = apt.service.toLowerCase().includes(q);
      const matchDate = apt.date.includes(q);
      if (!matchId && !matchService && !matchDate) return false;
    }

    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase tracking-wide">
            Confirmed
          </span>
        );
      case 'pending':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 uppercase tracking-wide">
            Pending
          </span>
        );
      case 'completed':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-purple-100 text-[#38124A] uppercase tracking-wide">
            Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 uppercase tracking-wide">
            Cancelled
          </span>
        );
      case 'no-show':
        return (
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 uppercase tracking-wide">
            No-show
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A]">
            My Appointments
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage your fitting, measurement, and trial appointments with TailorTime.
          </p>
        </div>
        <button
          onClick={onOpenBooking}
          className="self-start sm:self-auto px-5 py-2.5 bg-[#EC4186] hover:bg-[#D82F73] text-white font-bold text-xs rounded-xl shadow-md shadow-[#EC4186]/20 transition active:scale-98 flex items-center gap-1.5"
        >
          <Calendar className="w-4 h-4" /> Book New Slot
        </button>
      </div>

      {/* Tabs and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'upcoming'
                ? 'bg-[#38124A] text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'past'
                ? 'bg-[#38124A] text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Past Visits
          </button>
          <button
            onClick={() => setActiveTab('cancelled')}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'cancelled'
                ? 'bg-[#38124A] text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Cancelled
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search service, ID, or date..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
          />
        </div>
      </div>

      {/* Appointment Cards Grid */}
      {isLoading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
          Loading your appointments...
        </div>
      ) : filteredAppointments.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center border border-slate-100 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-[#38124A] flex items-center justify-center mx-auto text-xl">
            📅
          </div>
          <h4 className="text-sm font-bold text-slate-700">No {activeTab} appointments found</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {activeTab === 'upcoming'
              ? 'You do not have any upcoming visits booked. Need a fitting or alteration?'
              : 'No appointments in this category.'}
          </p>
          {activeTab === 'upcoming' && (
            <button
              onClick={onOpenBooking}
              className="mt-2 text-xs font-bold text-[#EC4186] hover:underline"
            >
              Book an appointment slot now →
            </button>
          )}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredAppointments.map((apt) => {
            const isUpcoming = apt.status === 'confirmed' || apt.status === 'pending';

            return (
              <div
                key={apt._id}
                className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs hover:border-[#38124A]/20 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100">
                    <div>
                      <span className="font-mono font-bold text-xs text-slate-400">
                        {apt.appointmentId}
                      </span>
                      <h3 className="text-base font-bold text-[#1F2340] mt-0.5">{apt.service}</h3>
                    </div>
                    {getStatusBadge(apt.status)}
                  </div>

                  <div className="grid grid-cols-2 gap-3 py-3 text-xs">
                    <div className="flex items-center gap-2 text-slate-600">
                      <Calendar className="w-4 h-4 text-[#38124A]" />
                      <span>{apt.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-600">
                      <Clock className="w-4 h-4 text-[#EC4186]" />
                      <span className="font-semibold text-[#1F2340]">{apt.timeSlot}</span>
                    </div>
                  </div>

                  {apt.notes && (
                    <div className="bg-[#F8F5FA] p-2.5 rounded-xl text-[11px] text-slate-600 mb-3">
                      <span className="font-semibold text-slate-700">Notes: </span>
                      {apt.notes}
                    </div>
                  )}
                </div>

                {/* Actions for upcoming bookings */}
                {isUpcoming && (
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleOpenReschedule(apt)}
                      className="px-3.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-purple-600" /> Reschedule
                    </button>
                    <button
                      onClick={() => setCancelTarget(apt)}
                      className="px-3.5 py-1.5 rounded-xl border border-rose-100 text-rose-600 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1.5 transition"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Cancel
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Reschedule Modal */}
      {rescheduleTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-100 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-serif font-bold text-[#38124A]">
                  Reschedule Appointment
                </h3>
                <p className="text-xs text-slate-500">
                  {rescheduleTarget.appointmentId} • {rescheduleTarget.service}
                </p>
              </div>
              <button
                onClick={() => setRescheduleTarget(null)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {rescheduleError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{rescheduleError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Select New Date</label>
              <input
                type="date"
                min={todayStr}
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Choose Available Time Slot (Capacity: 10/hour max)
              </label>
              {isLoadingSlots ? (
                <div className="py-6 text-center text-xs text-slate-400">Loading slots...</div>
              ) : (
                <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1">
                  {availableSlots.map((slot) => {
                    const isSelected = newSlot === slot.timeSlot;
                    const isFull = slot.isFull;

                    return (
                      <button
                        key={slot.timeSlot}
                        type="button"
                        disabled={isFull}
                        onClick={() => setNewSlot(slot.timeSlot)}
                        className={`p-2 rounded-xl border text-xs font-medium transition text-center ${
                          isFull
                            ? 'opacity-40 bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                            : isSelected
                            ? 'border-[#EC4186] bg-pink-50 text-[#EC4186] font-bold'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {slot.timeSlot}
                        <span className="block text-[10px] text-slate-400">
                          {isFull ? 'Full' : `${slot.available} left`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setRescheduleTarget(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Keep Current
              </button>
              <button
                type="button"
                disabled={isRescheduling || !newSlot}
                onClick={handleConfirmReschedule}
                className="px-5 py-2 bg-[#38124A] hover:bg-[#270A34] text-white text-xs font-bold rounded-xl shadow-md transition disabled:opacity-50"
              >
                {isRescheduling ? 'Rescheduling...' : 'Confirm Reschedule'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Dialog */}
      {cancelTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-base font-bold text-slate-900">Cancel this appointment?</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to cancel your {cancelTarget.service} on {cancelTarget.date} at {cancelTarget.timeSlot}? Your slot will be freed for others.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setCancelTarget(null)}
                className="px-5 py-2 text-xs font-semibold text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-50"
              >
                No, Keep It
              </button>
              <button
                type="button"
                disabled={isCancelling}
                onClick={handleConfirmCancel}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition disabled:opacity-50"
              >
                {isCancelling ? 'Cancelling...' : 'Yes, Cancel Slot'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
