import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { api } from '../../services/api';
import {
  User,
  Ruler,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  Save,
  Scissors,
  Sparkles,
} from 'lucide-react';

export const CustomerProfile: React.FC = () => {
  const { user, updateUser } = useAuth();
  const { showToast } = useNotifications();

  // Contact details
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [address, setAddress] = useState(user?.address || '');

  // Body measurements
  const [chest, setChest] = useState('');
  const [waist, setWaist] = useState('');
  const [shoulder, setShoulder] = useState('');
  const [sleeve, setSleeve] = useState('');
  const [length, setLength] = useState('');
  const [hip, setHip] = useState('');
  const [inseam, setInseam] = useState('');
  const [neck, setNeck] = useState('');
  const [measurementNotes, setMeasurementNotes] = useState('');

  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    setName(user.name);
    setPhone(user.phone);
    setAddress(user.address || '');

    // Fetch saved measurements record
    api.getMeasurements(user._id).then((res) => {
      if (res.measurements) {
        setChest(res.measurements.chest || '');
        setWaist(res.measurements.waist || '');
        setShoulder(res.measurements.shoulder || '');
        setSleeve(res.measurements.sleeve || '');
        setLength(res.measurements.length || '');
        setHip(res.measurements.hip || '');
        setInseam(res.measurements.inseam || '');
        setNeck(res.measurements.neck || '');
        setMeasurementNotes(res.measurements.notes || '');
      } else if (user.preferredMeasurements) {
        setChest(user.preferredMeasurements.chest || '');
        setWaist(user.preferredMeasurements.waist || '');
        setShoulder(user.preferredMeasurements.shoulder || '');
        setSleeve(user.preferredMeasurements.sleeve || '');
        setLength(user.preferredMeasurements.length || '');
        setHip(user.preferredMeasurements.hip || '');
      }
    });
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    try {
      const preferredMeasurements = {
        chest,
        waist,
        shoulder,
        sleeve,
        length,
        hip,
        inseam,
        neck,
      };

      // Update user account details
      await updateUser({
        name,
        phone,
        address,
        preferredMeasurements,
      });

      // Save to measurements collection
      await api.saveMeasurements({
        customerId: user._id,
        customerName: name,
        phone,
        chest,
        waist,
        shoulder,
        sleeve,
        length,
        hip,
        inseam,
        neck,
        notes: measurementNotes,
      });

      showToast({
        type: 'success',
        title: 'Profile Updated! ✨',
        message: 'Your body measurements and contact details have been securely saved.',
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Save Failed',
        message: err.message || 'Could not update profile',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A]">
          My Measurements & Profile
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Save your standard tailoring measurements once. Every future outfit will be crafted to these exact proportions.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* Contact Information */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <User className="w-5 h-5 text-[#38124A]" />
            <h3 className="text-base font-bold text-[#1F2340]">Contact Information</h3>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Phone Number (For WhatsApp Notifications)
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 bg-slate-50 text-slate-500 rounded-xl cursor-not-allowed"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                Email cannot be changed as it is linked to your TailorTime login credentials.
              </span>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. Flat 304, Koramangala, Bengaluru"
                className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>
          </div>
        </div>

        {/* Tailoring Measurements Section */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Ruler className="w-5 h-5 text-[#EC4186]" />
              <h3 className="text-base font-bold text-[#1F2340]">Digital Body Measurement Sheet</h3>
            </div>
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
              Optional — Can be taken during in-store fitting
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Chest / Bust</label>
              <input
                type="text"
                value={chest}
                onChange={(e) => setChest(e.target.value)}
                placeholder="e.g. 34 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Waist</label>
              <input
                type="text"
                value={waist}
                onChange={(e) => setWaist(e.target.value)}
                placeholder="e.g. 28 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Shoulder</label>
              <input
                type="text"
                value={shoulder}
                onChange={(e) => setShoulder(e.target.value)}
                placeholder="e.g. 14.5 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sleeve</label>
              <input
                type="text"
                value={sleeve}
                onChange={(e) => setSleeve(e.target.value)}
                placeholder="e.g. 21 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Garment Length</label>
              <input
                type="text"
                value={length}
                onChange={(e) => setLength(e.target.value)}
                placeholder="e.g. 46 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Hip</label>
              <input
                type="text"
                value={hip}
                onChange={(e) => setHip(e.target.value)}
                placeholder="e.g. 38 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Inseam</label>
              <input
                type="text"
                value={inseam}
                onChange={(e) => setInseam(e.target.value)}
                placeholder="e.g. 30 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Neck / Collar</label>
              <input
                type="text"
                value={neck}
                onChange={(e) => setNeck(e.target.value)}
                placeholder="e.g. 15 in"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Custom Fit Notes & Tailor Preferences
            </label>
            <textarea
              rows={3}
              value={measurementNotes}
              onChange={(e) => setMeasurementNotes(e.target.value)}
              placeholder="e.g. Prefer relaxed armhole cut; slight taper at lower waist; leave 1.5 in inner fabric margin for future alterations."
              className="w-full px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
            />
          </div>
        </div>

        {/* Submit */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-8 py-3 bg-[#38124A] hover:bg-[#270A34] text-white font-bold text-sm rounded-2xl shadow-lg shadow-[#38124A]/25 transition active:scale-98 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Saving Changes...' : 'Save Profile & Measurements'}
          </button>
        </div>
      </form>
    </div>
  );
};
