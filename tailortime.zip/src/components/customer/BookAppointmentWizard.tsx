import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { api } from '../../services/api';
import { AppointmentService, SlotCapacity, Appointment } from '../../types';
import {
  X,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Scissors,
  Ruler,
  ShoppingBag,
  ArrowRight,
  ArrowLeft,
  Copy,
  Check,
} from 'lucide-react';

interface BookAppointmentWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onBookingComplete?: (appointment: Appointment) => void;
  onOpenAppointments?: () => void;
}

const SERVICES: {
  name: AppointmentService;
  icon: string;
  desc: string;
  duration: string;
  badge: string;
}[] = [
  {
    name: 'New Outfit',
    icon: '👗',
    desc: 'Consultation, design styling, fabric examination, and bespoke drafting.',
    duration: '45 mins',
    badge: 'Popular',
  },
  {
    name: 'Alteration',
    icon: '✂️',
    desc: 'Garment resizing, hem adjustments, shoulder fit, or waist tightening.',
    duration: '20 mins',
    badge: 'Quick',
  },
  {
    name: 'Measurement',
    icon: '📐',
    desc: 'Full 10-point body measurements recorded into your digital profile.',
    duration: '25 mins',
    badge: 'Essential',
  },
  {
    name: 'Fitting',
    icon: '🪞',
    desc: 'Trial fitting session for garments currently in production.',
    duration: '30 mins',
    badge: 'Precision',
  },
  {
    name: 'Pickup / Collection',
    icon: '🛍️',
    desc: 'Final inspection, trial, and collecting your ready-packed outfit.',
    duration: '15 mins',
    badge: 'Express',
  },
];

export const BookAppointmentWizard: React.FC<BookAppointmentWizardProps> = ({
  isOpen,
  onClose,
  onBookingComplete,
  onOpenAppointments,
}) => {
  const { user } = useAuth();
  const { showToast } = useNotifications();

  // Wizard state: 1: Service, 2: Date, 3: Slot, 4: Details, 5: Confirmation
  const [step, setStep] = useState<number>(1);
  const [selectedService, setSelectedService] = useState<AppointmentService>('New Outfit');

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [availableSlots, setAvailableSlots] = useState<SlotCapacity[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<string>('');
  const [isLoadingSlots, setIsLoadingSlots] = useState<boolean>(false);

  // Details
  const [customerName, setCustomerName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Confirmed booking
  const [confirmedBooking, setConfirmedBooking] = useState<Appointment | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    if (user) {
      setCustomerName(user.name);
      setPhone(user.phone);
    }
  }, [user]);

  // Load slot capacity whenever date changes
  useEffect(() => {
    if (!isOpen || !selectedDate) return;

    let isMounted = true;
    setIsLoadingSlots(true);
    setSelectedSlot('');
    setError(null);

    api
      .getCapacity(selectedDate)
      .then((res) => {
        if (isMounted) {
          setAvailableSlots(res.slots);
          // If preselected slot is full, clear it
          const found = res.slots.find((s) => s.timeSlot === selectedSlot);
          if (found && found.isFull) {
            setSelectedSlot('');
          }
        }
      })
      .catch((err) => {
        if (isMounted) setError(err.message || 'Failed to check slot capacity');
      })
      .finally(() => {
        if (isMounted) setIsLoadingSlots(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, selectedDate]);

  if (!isOpen) return null;

  // Next 14 days generator
  const dateOptions = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const yyyyMmDd = d.toISOString().split('T')[0];
    const isToday = i === 0;
    const isTomorrow = i === 1;
    const dayName = isToday
      ? 'Today'
      : isTomorrow
      ? 'Tomorrow'
      : d.toLocaleDateString([], { weekday: 'short' });
    const dayNum = d.toLocaleDateString([], { month: 'short', day: 'numeric' });
    return { date: yyyyMmDd, dayName, dayNum };
  });

  const handleBookSubmit = async () => {
    if (!customerName.trim() || !phone.trim()) {
      setError('Please provide your name and phone number');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await api.bookAppointment({
        service: selectedService,
        date: selectedDate,
        timeSlot: selectedSlot,
        notes: notes.trim(),
        customerName: customerName.trim(),
        phone: phone.trim(),
      });

      setConfirmedBooking(res.appointment);
      setStep(5);
      showToast({
        type: 'success',
        title: 'Appointment Confirmed! ✂️',
        message: `Booked for ${selectedDate} at ${selectedSlot} (${res.appointment.appointmentId})`,
      });
      onBookingComplete?.(res.appointment);
    } catch (err: any) {
      setError(err.message || 'Failed to book appointment. The slot may have just filled up.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleResetAndClose = () => {
    setStep(1);
    setSelectedSlot('');
    setConfirmedBooking(null);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#38124A] via-[#521E6B] to-[#EC4186] px-6 py-5 text-white flex items-center justify-between shrink-0">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-pink-200">
              {step < 5 ? `Step ${step} of 4` : 'Success'}
            </span>
            <h3 className="text-xl font-serif font-bold">
              {step === 1 && 'Select Tailoring Service'}
              {step === 2 && 'Select Appointment Date'}
              {step === 3 && 'Choose Available Time Slot'}
              {step === 4 && 'Customer Details & Garment Notes'}
              {step === 5 && 'Appointment Confirmed!'}
            </h3>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        {step < 5 && (
          <div className="w-full bg-slate-100 h-1.5 shrink-0">
            <div
              className="bg-[#EC4186] h-1.5 transition-all duration-300"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        )}

        {/* Wizard Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: SELECT SERVICE */}
          {step === 1 && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500 font-medium">
                Choose the primary service you require for this appointment:
              </p>
              <div className="grid gap-3 sm:grid-cols-1">
                {SERVICES.map((srv) => {
                  const isSelected = selectedService === srv.name;
                  return (
                    <div
                      key={srv.name}
                      onClick={() => setSelectedService(srv.name)}
                      className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-4 ${
                        isSelected
                          ? 'border-[#EC4186] bg-pink-50/30 shadow-xs'
                          : 'border-slate-100 bg-white hover:border-slate-200 hover:bg-slate-50/50'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-2xl bg-white border border-slate-100 shadow-2xs flex items-center justify-center text-2xl shrink-0">
                        {srv.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-sm font-bold text-[#1F2340]">{srv.name}</h4>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                            {srv.duration}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{srv.desc}</p>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-1 ${
                          isSelected ? 'border-[#EC4186] bg-[#EC4186] text-white' : 'border-slate-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: SELECT DATE */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-500 font-medium">Select your preferred date for the appointment:</p>
                <span className="text-xs font-semibold text-[#EC4186]">Showing next 14 days</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
                {dateOptions.map((opt) => {
                  const isSelected = selectedDate === opt.date;
                  return (
                    <button
                      key={opt.date}
                      type="button"
                      onClick={() => setSelectedDate(opt.date)}
                      className={`p-3 rounded-2xl border-2 text-center transition flex flex-col items-center justify-center ${
                        isSelected
                          ? 'border-[#EC4186] bg-[#38124A] text-white shadow-md'
                          : 'border-slate-100 bg-white hover:border-purple-200 text-[#1F2340]'
                      }`}
                    >
                      <span className={`text-[11px] font-bold uppercase tracking-wider ${isSelected ? 'text-pink-200' : 'text-slate-400'}`}>
                        {opt.dayName}
                      </span>
                      <span className="text-sm font-extrabold mt-1">{opt.dayNum}</span>
                    </button>
                  );
                })}
              </div>

              {/* Notice */}
              <div className="bg-purple-50/60 p-3.5 rounded-2xl border border-purple-100 text-xs text-[#38124A] flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#EC4186] shrink-0" />
                <span>
                  Our master tailor limits slots to <strong>10 appointments per hour</strong> to ensure zero wait times and personal fitting attention.
                </span>
              </div>
            </div>
          )}

          {/* STEP 3: SELECT TIME SLOT */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-700">
                    Available Slots for {new Date(selectedDate).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
                  </h4>
                  <p className="text-[11px] text-slate-500">Each hour is capped at 10 bookings max</p>
                </div>
                <div className="flex items-center gap-3 text-[11px]">
                  <span className="flex items-center gap-1 text-slate-600">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Available
                  </span>
                  <span className="flex items-center gap-1 text-slate-600">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-300" /> Full (10/10)
                  </span>
                </div>
              </div>

              {isLoadingSlots ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
                  Checking slot availability...
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {availableSlots.map((slot) => {
                    const isSelected = selectedSlot === slot.timeSlot;
                    const isFull = slot.isFull;

                    return (
                      <button
                        key={slot.timeSlot}
                        type="button"
                        disabled={isFull}
                        onClick={() => setSelectedSlot(slot.timeSlot)}
                        className={`p-3.5 rounded-2xl border-2 text-left transition flex flex-col justify-between relative ${
                          isFull
                            ? 'border-slate-100 bg-slate-50 opacity-50 cursor-not-allowed text-slate-400'
                            : isSelected
                            ? 'border-[#EC4186] bg-pink-50/30 text-[#1F2340] shadow-sm'
                            : 'border-slate-100 bg-white hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold">{slot.timeSlot}</span>
                          {isSelected && <Check className="w-4 h-4 text-[#EC4186]" />}
                        </div>
                        <div className="mt-2 flex items-center justify-between text-[11px]">
                          {isFull ? (
                            <span className="font-bold text-rose-500">Fully Booked</span>
                          ) : (
                            <span className="font-medium text-emerald-600">
                              {slot.available} of {slot.capacity} spots left
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* STEP 4: DETAILS & NOTES */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2">
                <div className="flex justify-between text-xs text-slate-600">
                  <span>Selected Service:</span>
                  <span className="font-bold text-[#1F2340]">{selectedService}</span>
                </div>
                <div className="flex justify-between text-xs text-slate-600">
                  <span>Date & Slot:</span>
                  <span className="font-bold text-[#EC4186]">
                    {selectedDate} at {selectedSlot}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Customer Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Riya Mehta"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Phone Number (For WhatsApp / SMS Confirmation) *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Garment Notes / Fabric Details (Optional)</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Bringing Raw Silk fabric for festive Anarkali suit. Need deep back neck design."
                  className="w-full px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186]"
                />
              </div>
            </div>
          )}

          {/* STEP 5: CONFIRMATION SCREEN */}
          {step === 5 && confirmedBooking && (
            <div className="text-center space-y-6 py-2">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl font-bold animate-in zoom-in-75">
                ✓
              </div>

              <div>
                <h4 className="text-xl font-serif font-bold text-[#38124A]">Booking Confirmed!</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Your fitting slot has been reserved. A confirmation WhatsApp notification has been prepared.
                </p>
              </div>

              {/* Booking Card */}
              <div className="bg-[#F8F5FA] border border-[#38124A]/10 rounded-3xl p-5 text-left space-y-3.5 max-w-md mx-auto">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Appointment ID</span>
                    <p className="text-base font-mono font-bold text-[#38124A]">{confirmedBooking.appointmentId}</p>
                  </div>
                  <button
                    onClick={() => handleCopyId(confirmedBooking.appointmentId)}
                    className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-[#EC4186] text-xs font-medium flex items-center gap-1"
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block">Service</span>
                    <span className="font-semibold text-slate-800">{confirmedBooking.service}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Status</span>
                    <span className="inline-block text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase">
                      {confirmedBooking.status}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Date</span>
                    <span className="font-semibold text-slate-800">{confirmedBooking.date}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Time Slot</span>
                    <span className="font-semibold text-[#EC4186]">{confirmedBooking.timeSlot}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 text-xs text-slate-500">
                  <p className="font-medium text-slate-700">TailorTime Indiranagar Boutique</p>
                  <p className="text-[11px]">Plot 42, 100ft Road, Indiranagar, Bengaluru</p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    handleResetAndClose();
                    onOpenAppointments?.();
                  }}
                  className="w-full sm:w-auto px-6 py-2.5 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold text-xs rounded-xl shadow-md transition"
                >
                  View in My Appointments
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep(1);
                    setSelectedSlot('');
                    setConfirmedBooking(null);
                  }}
                  className="w-full sm:w-auto px-6 py-2.5 bg-white text-slate-700 border border-slate-200 font-semibold text-xs rounded-xl hover:bg-slate-50 transition"
                >
                  Book Another Appointment
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        {step < 5 && (
          <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
            <button
              type="button"
              disabled={step === 1}
              onClick={() => setStep((s) => Math.max(1, s - 1))}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition flex items-center gap-1.5 ${
                step === 1 ? 'opacity-0 pointer-events-none' : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>

            {step < 4 ? (
              <button
                type="button"
                disabled={step === 3 && !selectedSlot}
                onClick={() => setStep((s) => s + 1)}
                className="px-6 py-2.5 bg-[#EC4186] hover:bg-[#D82F73] text-white font-semibold text-xs rounded-xl shadow-sm transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5 active:scale-98"
              >
                Continue <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleBookSubmit}
                className="px-6 py-2.5 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold text-xs rounded-xl shadow-md transition disabled:opacity-50 flex items-center gap-1.5 active:scale-98"
              >
                {isSubmitting ? 'Confirming...' : 'Confirm Appointment'}
                <Check className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
