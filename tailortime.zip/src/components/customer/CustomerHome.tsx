import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { api } from '../../services/api';
import { Appointment, Order } from '../../types';
import {
  Calendar,
  Package,
  CheckCircle2,
  Clock,
  ArrowRight,
  Scissors,
  Sparkles,
  ChevronRight,
  BellRing,
  Ruler,
  AlertCircle,
  MessageCircle,
} from 'lucide-react';

interface CustomerHomeProps {
  onOpenBooking: () => void;
  onNavigateTab: (tab: string) => void;
}

export const CustomerHome: React.FC<CustomerHomeProps> = ({
  onOpenBooking,
  onNavigateTab,
}) => {
  const { user } = useAuth();
  const { notifications, setActiveWhatsAppModal } = useNotifications();

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    Promise.all([api.getAppointments(), api.getOrders()])
      .then(([aptRes, ordRes]) => {
        if (isMounted) {
          setAppointments(aptRes.appointments);
          setOrders(ordRes.orders);
        }
      })
      .catch((err) => console.warn('Failed to load dashboard data:', err))
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const upcomingAppointment = appointments.find(
    (a) => a.status === 'confirmed' || a.status === 'pending'
  );

  const activeOrders = orders.filter((o) => o.currentStage !== 'collected');
  const readyOrders = orders.filter((o) => o.currentStage === 'ready');
  const primaryActiveOrder = activeOrders[0];

  const recentWhatsAppNotif = notifications.find(
    (n) => n.channel === 'whatsapp_simulated'
  );

  return (
    <div className="space-y-8 max-w-6xl mx-auto px-4 sm:px-6 py-6">
      {/* Personalized Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#38124A] via-[#521E6B] to-[#EC4186] p-6 sm:p-10 text-white shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-semibold text-pink-100">
            <Sparkles className="w-3.5 h-3.5 text-pink-200" />
            <span>Welcome back, {user?.name.split(' ')[0]}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight">
            Your tailoring, <br className="hidden sm:inline" />
            without the waiting.
          </h1>

          <p className="text-sm sm:text-base text-white/80 leading-relaxed max-w-xl">
            Book your fitting, track your order, and collect when it’s ready. Less queue, more certainty.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onOpenBooking}
              className="px-6 py-3 bg-[#EC4186] hover:bg-[#D82F73] text-white font-bold text-sm rounded-2xl shadow-lg shadow-[#EC4186]/30 transition hover:shadow-xl active:scale-98 flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" /> Book Appointment
            </button>
            <button
              onClick={() => onNavigateTab('track-order')}
              className="px-6 py-3 bg-white/15 hover:bg-white/25 text-white font-semibold text-sm rounded-2xl backdrop-blur-md transition flex items-center gap-2"
            >
              <Package className="w-4 h-4 text-pink-200" /> Track My Order
            </button>
          </div>
        </div>

        {/* Ambient watermark pattern */}
        <div className="absolute right-4 bottom-4 opacity-10 pointer-events-none -rotate-12">
          <Scissors className="w-64 h-64 text-white" />
        </div>
      </div>

      {/* Simulated WhatsApp Notification Bar (if present) */}
      {recentWhatsAppNotif && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider">
                  WhatsApp Alert: {recentWhatsAppNotif.title}
                </span>
                <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-1.5 rounded">
                  Live
                </span>
              </div>
              <p className="text-xs text-emerald-800 mt-0.5 line-clamp-1">
                {recentWhatsAppNotif.message}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveWhatsAppModal(recentWhatsAppNotif)}
            className="text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-xl transition shrink-0 self-start sm:self-auto"
          >
            Preview Phone Alert 📱
          </button>
        </div>
      )}

      {/* Quick Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Card 1: Upcoming Appointment */}
        <div
          onClick={() => onNavigateTab('my-appointments')}
          className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs hover:border-[#38124A]/20 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Upcoming Appointment
            </span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-[#38124A] flex items-center justify-center group-hover:scale-105 transition">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          {upcomingAppointment ? (
            <div>
              <p className="text-base font-bold text-[#1F2340]">{upcomingAppointment.service}</p>
              <p className="text-xs text-[#EC4186] font-semibold mt-1">
                {upcomingAppointment.date} • {upcomingAppointment.timeSlot}
              </p>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">{upcomingAppointment.appointmentId}</p>
            </div>
          ) : (
            <div>
              <p className="text-sm font-semibold text-slate-400">No appointments scheduled</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenBooking();
                }}
                className="mt-2 text-xs font-bold text-[#EC4186] hover:underline flex items-center gap-1"
              >
                + Book a Fitting Slot
              </button>
            </div>
          )}
        </div>

        {/* Card 2: Active Orders */}
        <div
          onClick={() => onNavigateTab('track-order')}
          className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs hover:border-[#38124A]/20 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Active Orders
            </span>
            <div className="w-9 h-9 rounded-xl bg-pink-50 text-[#EC4186] flex items-center justify-center group-hover:scale-105 transition">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-[#38124A]">{activeOrders.length}</p>
          <p className="text-xs text-slate-500 mt-1">
            {activeOrders.length === 1
              ? '1 garment in tailoring'
              : `${activeOrders.length} garments in tailoring pipeline`}
          </p>
        </div>

        {/* Card 3: Ready for Collection */}
        <div
          onClick={() => onNavigateTab('track-order')}
          className="bg-white p-5 rounded-3xl border border-slate-100 shadow-xs hover:border-[#38124A]/20 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Ready for Collection
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-extrabold text-emerald-600">{readyOrders.length}</p>
          <p className="text-xs text-slate-500 mt-1">
            {readyOrders.length > 0
              ? 'Ready at boutique for trial & pickup!'
              : 'All up to date'}
          </p>
        </div>
      </div>

      {/* Primary Active Order Spotlight */}
      {primaryActiveOrder && (
        <div className="bg-white rounded-3xl p-6 border border-[#38124A]/10 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-[#38124A]">
                  {primaryActiveOrder.jobId}
                </span>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-pink-100 text-[#EC4186]">
                  Stage: {primaryActiveOrder.currentStage.replace('_', ' ')}
                </span>
              </div>
              <h3 className="text-base font-bold text-[#1F2340] mt-1">
                {primaryActiveOrder.garmentType}
              </h3>
            </div>
            <div className="text-left sm:text-right">
              <span className="text-xs text-slate-400 block">Est. Completion</span>
              <span className="text-xs font-bold text-emerald-700">
                {new Date(primaryActiveOrder.estimatedCompletion).toLocaleDateString([], {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>
          </div>

          {/* Quick 5-stage mini timeline preview */}
          <div className="py-5">
            <div className="grid grid-cols-5 gap-2 text-center">
              {[
                { key: 'measurement', label: 'Measured' },
                { key: 'cutting', label: 'Cutting' },
                { key: 'stitching', label: 'Stitching' },
                { key: 'fitting', label: 'Fitting' },
                { key: 'ready', label: 'Ready' },
              ].map((step, idx) => {
                const stageOrder = ['appointment', 'measurement', 'cutting', 'stitching', 'fitting', 'alteration', 'quality_check', 'ready', 'collected'];
                const currentIdx = stageOrder.indexOf(primaryActiveOrder.currentStage);
                const stepIdx = stageOrder.indexOf(step.key);
                const isPassed = currentIdx >= stepIdx;
                const isCurrent = primaryActiveOrder.currentStage === step.key;

                return (
                  <div key={step.key} className="flex flex-col items-center">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1.5 transition ${
                        isCurrent
                          ? 'bg-[#EC4186] text-white ring-4 ring-[#EC4186]/20'
                          : isPassed
                          ? 'bg-emerald-500 text-white'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isPassed && !isCurrent ? '✓' : idx + 1}
                    </div>
                    <span
                      className={`text-[11px] font-semibold ${
                        isCurrent ? 'text-[#EC4186]' : isPassed ? 'text-slate-800' : 'text-slate-400'
                      }`}
                    >
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <span className="text-xs text-slate-500">
              Assigned: <strong>{primaryActiveOrder.assignedTailor}</strong>
            </span>
            <button
              onClick={() => onNavigateTab('track-order')}
              className="text-xs font-bold text-[#EC4186] hover:underline flex items-center gap-1"
            >
              Full Order Timeline & History <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 3-Step Explanation */}
      <div className="bg-[#F8F5FA] rounded-3xl p-6 sm:p-8 border border-slate-200/60">
        <h3 className="text-base font-bold text-[#38124A] mb-4">How TailorTime Works</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-[#38124A] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
              1
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#1F2340]">Book Slot</h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Choose a tailoring service and available time slot (max 10/hour).
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-pink-100 text-[#EC4186] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
              2
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#1F2340]">Track Order</h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Follow your tailoring job status through cutting, stitching, and trial fitting.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
              3
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#1F2340]">Collect Outfit</h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Get notified when your outfit is ready. Walk in and collect immediately.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
