import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Order, OrderStage } from '../../types';
import { useNotifications } from '../../context/NotificationContext';
import {
  Package,
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  Scissors,
  Ruler,
  Sparkles,
  Search,
  MessageCircle,
  AlertCircle,
  Check,
  ChevronRight,
  UserCheck,
} from 'lucide-react';

interface OrderTrackingViewProps {
  initialJobId?: string;
  onOpenBooking: () => void;
}

const STAGES: {
  key: OrderStage;
  label: string;
  icon: string;
  description: string;
}[] = [
  { key: 'appointment', label: 'Appointment', icon: '📅', description: 'Fitting slot booked & styling discussed' },
  { key: 'measurement', label: 'Measurement', icon: '📐', description: 'Body measurements logged into job card' },
  { key: 'cutting', label: 'Cutting', icon: '✂️', description: 'Precision fabric cutting & pattern drafting' },
  { key: 'stitching', label: 'Stitching', icon: '🧵', description: 'Master craftsman stitching & seam assembly' },
  { key: 'fitting', label: 'Trial Fitting', icon: '🪞', description: 'Trial fitting session for adjustment notes' },
  { key: 'alteration', label: 'Alteration', icon: '🪡', description: 'Refinement alterations based on trial' },
  { key: 'quality_check', label: 'Quality Check', icon: '🔍', description: 'Thread finish, steam pressing, & QC inspection' },
  { key: 'ready', label: 'Ready for Collection', icon: '🎉', description: 'Packaged in dust bag, ready for pickup' },
  { key: 'collected', label: 'Collected', icon: '🛍️', description: 'Collected by customer from boutique' },
];

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  initialJobId,
  onOpenBooking,
}) => {
  const { showToast, setActiveWhatsAppModal } = useNotifications();

  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchInput, setSearchInput] = useState(initialJobId || '');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    api
      .getOrders()
      .then((res) => {
        setOrders(res.orders);
        if (initialJobId) {
          const match = res.orders.find(
            (o) => o.jobId.toUpperCase() === initialJobId.toUpperCase()
          );
          if (match) setSelectedOrder(match);
        } else if (res.orders.length > 0) {
          // Select first active order or first order
          const active = res.orders.find((o) => o.currentStage !== 'collected') || res.orders[0];
          setSelectedOrder(active);
        }
      })
      .catch((err) => {
        console.warn('Failed to load orders:', err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [initialJobId]);

  const handleSearchOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;

    setError(null);
    try {
      const res = await api.trackOrderPublic(searchInput.trim());
      setSelectedOrder(res.order);
    } catch (err: any) {
      setError(err.message || 'No job card found with that ID');
    }
  };

  const handleSendWhatsAppSimulation = async () => {
    if (!selectedOrder) return;
    try {
      const title = selectedOrder.currentStage === 'ready'
        ? '🎉 Your Outfit is Ready!'
        : `TailorTime Status: ${selectedOrder.currentStage.toUpperCase()}`;

      const message = `Hello ${selectedOrder.customerName}, your ${selectedOrder.garmentType} (${selectedOrder.jobId}) is currently at the ${selectedOrder.currentStage.replace('_', ' ')} stage. Expected delivery: ${selectedOrder.estimatedCompletion}.`;

      const res = await api.simulateNotification(title, message, 'whatsapp_simulated');
      setActiveWhatsAppModal(res.notification);
      showToast({
        type: 'success',
        title: 'WhatsApp Alert Triggered',
        message: 'Previewing simulated WhatsApp message.',
      });
    } catch (err: any) {
      showToast({
        type: 'error',
        title: 'Simulation error',
        message: err.message,
      });
    }
  };

  const currentStageIndex = selectedOrder
    ? STAGES.findIndex((s) => s.key === selectedOrder.currentStage)
    : -1;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Title & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">Live Production Tracker</span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Tailoring Job Tracking
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Follow your handcrafted garment through our transparent 9-stage craft pipeline.
          </p>
        </div>

        {/* Search by Job ID */}
        <form onSubmit={handleSearchOrder} className="flex gap-2 w-full md:w-80">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search Job ID (e.g. TT-JOB-5018)"
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186] font-mono uppercase"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-[#38124A] text-white rounded-xl text-xs font-semibold hover:bg-[#270A34] transition shrink-0"
          >
            Track
          </button>
        </form>
      </div>

      {error && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Quick Orders Selector Chips (if customer has multiple orders) */}
      {orders.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-xs font-bold text-slate-400 shrink-0">Your Orders:</span>
          {orders.map((ord) => {
            const isSelected = selectedOrder?.jobId === ord.jobId;
            return (
              <button
                key={ord._id}
                onClick={() => setSelectedOrder(ord)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#38124A] text-white shadow-xs'
                    : 'bg-white text-slate-700 border border-slate-200 hover:border-slate-300'
                }`}
              >
                <span className="font-mono font-bold">{ord.jobId}</span>
                <span className="text-[10px] opacity-80">({ord.garmentType.slice(0, 18)}...)</span>
              </button>
            );
          })}
        </div>
      )}

      {isLoading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          <div className="animate-spin w-6 h-6 border-2 border-[#EC4186] border-t-transparent rounded-full mx-auto mb-2" />
          Loading order details...
        </div>
      ) : !selectedOrder ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-[#38124A] flex items-center justify-center mx-auto text-xl">
            🧵
          </div>
          <h4 className="text-base font-bold text-slate-800">No Orders Tracked Yet</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Book an appointment with Master Rameshwar to initialize your bespoke tailoring job card.
          </p>
          <button
            onClick={onOpenBooking}
            className="mt-2 text-xs font-bold text-[#EC4186] hover:underline"
          >
            Book your fitting slot now →
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Order Header Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <span className="text-xl sm:text-2xl font-mono font-extrabold text-[#38124A]">
                  {selectedOrder.jobId}
                </span>
                <span
                  className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
                    selectedOrder.currentStage === 'ready'
                      ? 'bg-emerald-100 text-emerald-800 ring-2 ring-emerald-400/40 animate-pulse'
                      : selectedOrder.currentStage === 'collected'
                      ? 'bg-slate-100 text-slate-700'
                      : 'bg-pink-100 text-[#EC4186]'
                  }`}
                >
                  ● {selectedOrder.currentStage.replace('_', ' ')}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-serif font-bold text-[#1F2340]">
                {selectedOrder.garmentType}
              </h2>
              <p className="text-xs text-slate-500">
                Customer: <strong>{selectedOrder.customerName}</strong> ({selectedOrder.phone})
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-[#F8F5FA] p-4 rounded-2xl border border-slate-100">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Expected Readiness
                </span>
                <span className="text-base font-bold text-emerald-700">
                  {new Date(selectedOrder.estimatedCompletion).toLocaleDateString([], {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Assigned Tailor: <strong>{selectedOrder.assignedTailor}</strong>
                </span>
              </div>

              <button
                onClick={handleSendWhatsAppSimulation}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-98"
                title="Simulate WhatsApp alert sent to customer phone"
              >
                <MessageCircle className="w-4 h-4" /> WhatsApp Alert
              </button>
            </div>
          </div>

          {/* THE 9-STAGE VISUAL TIMELINE */}
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-md space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-[#38124A]">9-Stage Craft Timeline</h3>
                <p className="text-xs text-slate-500">
                  Every step is inspected and timestamped by the master craftsman.
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs font-extrabold text-[#EC4186]">
                  {Math.round(((currentStageIndex + 1) / STAGES.length) * 100)}% Completed
                </span>
              </div>
            </div>

            {/* Visual Timeline List */}
            <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
              {STAGES.map((stage, idx) => {
                const isPassed = currentStageIndex > idx;
                const isCurrent = currentStageIndex === idx;
                const isUpcoming = currentStageIndex < idx;

                // Check if this stage has a history log recorded
                const historyEntry = selectedOrder.stagesHistory?.find(
                  (h) => h.stage === stage.key
                );

                return (
                  <div key={stage.key} className="relative group">
                    {/* Node Dot / Icon */}
                    <div
                      className={`absolute -left-6 sm:-left-8 w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all shadow-xs ${
                        isCurrent
                          ? 'bg-[#EC4186] text-white ring-4 ring-[#EC4186]/25 scale-110'
                          : isPassed
                          ? 'bg-emerald-500 text-white'
                          : 'bg-white border-2 border-slate-300 text-slate-300'
                      }`}
                    >
                      {isPassed ? (
                        <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[3]" />
                      ) : isCurrent ? (
                        <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                      ) : (
                        <Circle className="w-2.5 h-2.5" />
                      )}
                    </div>

                    {/* Stage Card */}
                    <div
                      className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                        isCurrent
                          ? 'bg-gradient-to-r from-pink-50/50 via-purple-50/30 to-white border-[#EC4186]/40 shadow-xs'
                          : isPassed
                          ? 'bg-slate-50/60 border-slate-100'
                          : 'bg-white border-slate-100 opacity-60'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{stage.icon}</span>
                          <h4
                            className={`text-sm font-bold ${
                              isCurrent ? 'text-[#EC4186]' : isPassed ? 'text-[#1F2340]' : 'text-slate-500'
                            }`}
                          >
                            {stage.label}
                          </h4>
                          {isCurrent && (
                            <span className="text-[10px] font-bold bg-[#EC4186] text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                              In Progress
                            </span>
                          )}
                        </div>

                        {historyEntry && (
                          <span className="text-[11px] text-slate-400 font-mono">
                            {new Date(historyEntry.timestamp).toLocaleString([], {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 mt-1">{stage.description}</p>

                      {/* Logged Note */}
                      {historyEntry?.note && (
                        <div className="mt-2.5 p-2.5 rounded-xl bg-white/80 border border-slate-200/80 text-xs text-slate-700 flex items-start gap-2">
                          <span className="text-[10px] font-bold uppercase text-slate-400 shrink-0 mt-0.5">
                            Tailor Note:
                          </span>
                          <span className="italic">{historyEntry.note}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Garment Details & Measurements Card */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Measurements breakdown */}
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <Ruler className="w-5 h-5 text-[#38124A]" />
                <h3 className="text-sm font-bold text-[#1F2340]">Body Measurements for this Job</h3>
              </div>

              {selectedOrder.measurements && Object.keys(selectedOrder.measurements).length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {Object.entries(selectedOrder.measurements).map(([key, val]) => (
                    <div key={key} className="p-2.5 bg-[#F8F5FA] rounded-xl text-center">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block capitalize">
                        {key}
                      </span>
                      <span className="text-xs font-bold text-[#1F2340] mt-0.5 block">{val}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500">Standard fit specifications applied.</p>
              )}

              {selectedOrder.notes && (
                <div className="pt-2 border-t border-slate-100 text-xs text-slate-600">
                  <span className="font-semibold text-slate-700">Special Instructions: </span>
                  {selectedOrder.notes}
                </div>
              )}
            </div>

            {/* Price & Billing */}
            <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#1F2340] mb-3">Billing & Payment Summary</h3>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Total Tailoring Charges:</span>
                    <span className="font-bold text-slate-900">₹{selectedOrder.price || 0}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Advance Deposit Paid:</span>
                    <span className="font-semibold text-emerald-600">₹{selectedOrder.advancePaid || 0}</span>
                  </div>
                  <div className="pt-2 border-t border-slate-100 flex justify-between text-sm font-bold text-[#38124A]">
                    <span>Balance Due on Collection:</span>
                    <span className="text-[#EC4186]">
                      ₹{Math.max(0, (selectedOrder.price || 0) - (selectedOrder.advancePaid || 0))}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-purple-50/70 p-3.5 rounded-2xl border border-purple-100 text-xs text-purple-900 space-y-1">
                <p className="font-semibold">Boutique Trial Promise</p>
                <p className="text-[11px] text-purple-800 leading-relaxed">
                  Complimentary fit adjustments are provided within 7 days of collection.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
