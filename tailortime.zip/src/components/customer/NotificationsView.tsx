import React, { useState } from 'react';
import { useNotifications } from '../../context/NotificationContext';
import {
  Bell,
  MessageCircle,
  Smartphone,
  CheckCircle2,
  Check,
  Calendar,
  Package,
  Sparkles,
} from 'lucide-react';

interface NotificationsViewProps {
  onNavigateTab: (tab: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({ onNavigateTab }) => {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    setActiveWhatsAppModal,
  } = useNotifications();

  const [filter, setFilter] = useState<'all' | 'unread' | 'whatsapp'>('all');

  const filteredNotifications = notifications.filter((n) => {
    if (filter === 'unread') return !n.isRead;
    if (filter === 'whatsapp') return n.channel === 'whatsapp_simulated';
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#EC4186] uppercase tracking-wider">Activity Center</span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A] mt-0.5">
            Notifications & Alerts
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Simulated WhatsApp, SMS, and in-app alerts on appointment reminders and outfit readiness.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="self-start sm:self-auto px-4 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold rounded-xl transition shadow-2xs flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5 text-emerald-600" /> Mark all read
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-1.5 text-xs font-bold rounded-xl transition ${
            filter === 'all' ? 'bg-[#38124A] text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          All ({notifications.length})
        </button>
        <button
          onClick={() => setFilter('unread')}
          className={`px-4 py-1.5 text-xs font-bold rounded-xl transition ${
            filter === 'unread' ? 'bg-[#38124A] text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Unread ({unreadCount})
        </button>
        <button
          onClick={() => setFilter('whatsapp')}
          className={`px-4 py-1.5 text-xs font-bold rounded-xl transition flex items-center gap-1 ${
            filter === 'whatsapp' ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Alerts
        </button>
      </div>

      {/* Notification List */}
      {filteredNotifications.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-[#38124A] flex items-center justify-center mx-auto text-xl">
            🔔
          </div>
          <h4 className="text-sm font-bold text-slate-800">No notifications here</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            You're all caught up! When an appointment is scheduled or your order advances a stage, notifications appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredNotifications.map((notif) => {
            const isWhatsApp = notif.channel === 'whatsapp_simulated';
            const isSms = notif.channel === 'sms_simulated';

            return (
              <div
                key={notif._id}
                className={`p-5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  notif.isRead
                    ? 'bg-white border-slate-100 opacity-80'
                    : 'bg-white border-[#EC4186]/30 shadow-xs ring-1 ring-[#EC4186]/10'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isWhatsApp
                        ? 'bg-emerald-100 text-emerald-700'
                        : isSms
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-purple-100 text-[#38124A]'
                    }`}
                  >
                    {isWhatsApp ? (
                      <MessageCircle className="w-5 h-5" />
                    ) : isSms ? (
                      <Smartphone className="w-5 h-5" />
                    ) : (
                      <Bell className="w-5 h-5" />
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-bold text-[#1F2340]">{notif.title}</h4>
                      {isWhatsApp && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          WhatsApp Alert
                        </span>
                      )}
                      {isSms && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                          SMS
                        </span>
                      )}
                      {!notif.isRead && (
                        <span className="w-2 h-2 rounded-full bg-[#EC4186]" />
                      )}
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">{notif.message}</p>

                    <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1">
                      <span>{new Date(notif.createdAt).toLocaleString()}</span>
                      {notif.orderId && (
                        <span className="font-mono text-slate-600">Ref: {notif.orderId}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right side actions */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                  {isWhatsApp && (
                    <button
                      onClick={() => {
                        setActiveWhatsAppModal(notif);
                        markAsRead(notif._id);
                      }}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-semibold transition flex items-center gap-1"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> Preview Phone Alert 📱
                    </button>
                  )}

                  {!notif.isRead && (
                    <button
                      onClick={() => markAsRead(notif._id)}
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
                      title="Mark as read"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
