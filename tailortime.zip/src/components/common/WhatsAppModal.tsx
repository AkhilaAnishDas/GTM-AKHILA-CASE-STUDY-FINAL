import React from 'react';
import { useNotifications } from '../../context/NotificationContext';
import { X, CheckCheck, MessageSquare, Phone, MoreVertical, ArrowLeft } from 'lucide-react';

export const WhatsAppModal: React.FC = () => {
  const { activeWhatsAppModal, setActiveWhatsAppModal } = useNotifications();

  if (!activeWhatsAppModal) return null;

  const timeStr = new Date(activeWhatsAppModal.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-sm bg-[#121b22] text-white rounded-3xl overflow-hidden shadow-2xl border border-white/10 animate-in fade-in zoom-in-95 duration-200">
        {/* Top close button */}
        <button
          onClick={() => setActiveWhatsAppModal(null)}
          className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-black/40 text-white/80 hover:text-white hover:bg-black/60 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* WhatsApp Header */}
        <div className="bg-[#1f2c34] px-4 py-3 flex items-center gap-3 border-b border-white/10">
          <button onClick={() => setActiveWhatsAppModal(null)} className="text-white/80 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Avatar with scissors/needle */}
          <div className="w-10 h-10 rounded-full bg-[#EC4186] flex items-center justify-center font-bold text-white text-lg shadow-sm">
            ✂️
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-sm truncate">TailorTime Updates</span>
              <span className="inline-flex items-center justify-center w-4 h-4 bg-emerald-500 rounded-full text-[10px] text-white font-black">
                ✓
              </span>
            </div>
            <p className="text-[11px] text-emerald-400 font-medium">Verified Business Account</p>
          </div>

          <div className="flex items-center gap-3 text-white/70">
            <Phone className="w-4 h-4" />
            <MoreVertical className="w-4 h-4" />
          </div>
        </div>

        {/* WhatsApp Chat Canvas */}
        <div className="p-4 bg-[#0b141a] min-h-[300px] flex flex-col justify-end space-y-3 bg-[radial-gradient(#1f2c34_1px,transparent_1px)] [background-size:16px_16px]">
          {/* Encryption notice */}
          <div className="bg-[#182229] text-[#ffd279] text-[10px] text-center px-3 py-1.5 rounded-lg border border-[#ffd279]/20 mx-auto max-w-[280px]">
            🔒 Messages and calls are end-to-end encrypted. TailorTime simulated alert.
          </div>

          {/* Today tag */}
          <div className="flex justify-center">
            <span className="bg-[#182229] text-white/60 text-[10px] px-3 py-0.5 rounded-md font-medium uppercase tracking-wider">
              Today
            </span>
          </div>

          {/* WhatsApp Message Bubble */}
          <div className="self-start max-w-[90%] bg-[#202c33] rounded-2xl rounded-tl-xs p-3.5 shadow-md border border-white/5 space-y-2">
            <div className="text-[11px] font-bold text-[#EC4186] flex items-center gap-1">
              <span>🧵 {activeWhatsAppModal.title}</span>
            </div>
            <p className="text-sm text-white/90 leading-relaxed font-sans">
              {activeWhatsAppModal.message}
            </p>

            {activeWhatsAppModal.orderId && (
              <div className="bg-[#111b21] p-2 rounded-lg text-xs flex justify-between items-center text-slate-300">
                <span>Job ID:</span>
                <span className="font-mono font-bold text-[#EC4186]">{activeWhatsAppModal.orderId}</span>
              </div>
            )}

            {activeWhatsAppModal.appointmentId && (
              <div className="bg-[#111b21] p-2 rounded-lg text-xs flex justify-between items-center text-slate-300">
                <span>Appointment Ref:</span>
                <span className="font-mono font-bold text-emerald-400">{activeWhatsAppModal.appointmentId}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-1 text-[10px] text-white/50 pt-1">
              <span>{timeStr}</span>
              <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" />
            </div>
          </div>
        </div>

        {/* Footer simulation */}
        <div className="bg-[#1f2c34] p-3 text-center border-t border-white/10 flex items-center justify-between">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
            Simulated WhatsApp Notification
          </span>
          <button
            onClick={() => setActiveWhatsAppModal(null)}
            className="text-xs font-semibold bg-[#00a884] hover:bg-[#008f6f] text-white px-3 py-1.5 rounded-lg transition"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
