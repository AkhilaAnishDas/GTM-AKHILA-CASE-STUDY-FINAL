import React from 'react';
import { Scissors, Phone, Mail, MapPin, Heart } from 'lucide-react';

interface FooterProps {
  onNavigateTab: (tab: string) => void;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateTab, onOpenBooking }) => {
  return (
    <footer className="bg-white border-t border-[#38124A]/10 mt-20 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#38124A] to-[#EC4186] flex items-center justify-center text-white">
                <Scissors className="w-5 h-5 transform -rotate-45" />
              </div>
              <span className="text-xl font-bold font-serif text-[#38124A]">TailorTime</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Book • Track • Collect. Modern appointment scheduling and live 9-stage job tracking platform for tailoring shops.
            </p>
            <p className="text-[11px] font-bold text-[#EC4186]">Less Queue. More Certainty.</p>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#38124A]">Customer Flow</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li>
                <button onClick={onOpenBooking} className="hover:text-[#EC4186] transition">
                  Book Fitting Slot (10/hr)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('track-public')} className="hover:text-[#EC4186] transition">
                  Live Order Tracker
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('customer-home')} className="hover:text-[#EC4186] transition">
                  Customer Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('measurements')} className="hover:text-[#EC4186] transition">
                  Body Measurements Guide
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Shop Admin */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#38124A]">Tailor / Shop Admin</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li>
                <button onClick={() => onNavigateTab('admin-dashboard')} className="hover:text-[#EC4186] transition">
                  Shop Dashboard & KPIs
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('admin-capacity')} className="hover:text-[#EC4186] transition">
                  Capacity Management (10/hr)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('admin-appointments')} className="hover:text-[#EC4186] transition">
                  Appointment Roster
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateTab('admin-orders')} className="hover:text-[#EC4186] transition">
                  Craftsmanship Pipeline
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Boutique Contact */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#38124A]">Boutique Visit</h4>
            <div className="space-y-2 text-xs text-slate-600">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#EC4186] shrink-0 mt-0.5" />
                <span>Plot 42, 100ft Road, Indiranagar, Bengaluru 560038</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#38124A] shrink-0" />
                <span>+91 98450 12345</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#38124A] shrink-0" />
                <span>care@tailortime.in</span>
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} TailorTime Inc. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Crafted with <Heart className="w-3 h-3 text-[#EC4186] fill-current" /> for modern bespoke tailoring
          </p>
        </div>
      </div>
    </footer>
  );
};
