import React, { useState } from 'react';
import {
  Scissors,
  Calendar,
  Clock,
  CheckCircle2,
  Package,
  Search,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  MessageCircle,
  HelpCircle,
  AlertCircle,
  UserCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { Order } from '../../types';

interface LandingPageProps {
  onOpenBooking: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onTrackOrder: (jobId: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onOpenBooking,
  onOpenAuth,
  onTrackOrder,
}) => {
  const [trackInput, setTrackInput] = useState('');
  const [quickTrackResult, setQuickTrackResult] = useState<Order | null>(null);
  const [quickTrackError, setQuickTrackError] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const handleQuickTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackInput.trim()) return;

    setIsSearching(true);
    setQuickTrackError(null);
    setQuickTrackResult(null);

    try {
      const res = await api.trackOrderPublic(trackInput.trim());
      setQuickTrackResult(res.order);
    } catch (err: any) {
      setQuickTrackError(err.message || 'No tailoring job found with this ID');
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28">
        {/* Soft background ambient glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none -z-10">
          <div className="absolute top-10 left-10 w-96 h-96 bg-purple-200/40 rounded-full blur-3xl" />
          <div className="absolute top-20 right-10 w-80 h-80 bg-pink-200/40 rounded-full blur-3xl" />
        </div>

        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-8">
          {/* Trust badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#38124A]/10 shadow-xs text-xs font-semibold text-[#38124A]">
            <span className="w-2 h-2 rounded-full bg-[#EC4186] animate-pulse" />
            <span>Modern Scheduling & Live Job Tracking for Tailoring Shops</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-extrabold text-[#38124A] tracking-tight leading-[1.12]">
            Your tailoring, <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-[#38124A] via-[#521E6B] to-[#EC4186] bg-clip-text text-transparent">
              without the waiting.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="max-w-2xl mx-auto text-base sm:text-xl text-[#64748B] leading-relaxed">
            Book your fitting slot, track every cut and stitch in real-time, and collect exactly when your outfit is ready.
            <strong className="block text-[#1F2340] font-semibold mt-1">Less Queue. More Certainty.</strong>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={onOpenBooking}
              className="w-full sm:w-auto px-8 py-3.5 bg-[#EC4186] hover:bg-[#D82F73] text-white text-base font-bold rounded-2xl shadow-lg shadow-[#EC4186]/30 hover:shadow-xl transition-all duration-200 active:scale-98 flex items-center justify-center gap-2"
            >
              <Calendar className="w-5 h-5" /> Book Appointment
            </button>
            <a
              href="#track-section"
              className="w-full sm:w-auto px-8 py-3.5 bg-white hover:bg-slate-50 text-[#38124A] border border-slate-200 text-base font-semibold rounded-2xl shadow-xs transition duration-200 flex items-center justify-center gap-2"
            >
              <Package className="w-5 h-5 text-[#EC4186]" /> Track My Order
            </a>
          </div>

          {/* Live quick statistics ribbon */}
          <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
              <p className="text-2xl font-extrabold text-[#38124A]">10</p>
              <p className="text-xs text-slate-500 font-medium">Slots/Hour Max Capacity</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
              <p className="text-2xl font-extrabold text-emerald-600">7 mins</p>
              <p className="text-xs text-slate-500 font-medium">Avg. In-Store Wait Time</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
              <p className="text-2xl font-extrabold text-[#EC4186]">9-Stage</p>
              <p className="text-xs text-slate-500 font-medium">Transparent Job Timeline</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
              <p className="text-2xl font-extrabold text-[#38124A]">98%</p>
              <p className="text-xs text-slate-500 font-medium">On-Time Outfit Readiness</p>
            </div>
          </div>
        </div>
      </section>

      {/* Direct Order Tracking Section */}
      <section id="track-section" className="max-w-4xl mx-auto px-4 sm:px-6 scroll-mt-24">
        <div className="bg-gradient-to-br from-white via-white to-purple-50/40 rounded-3xl p-6 sm:p-10 border border-[#38124A]/10 shadow-xl shadow-purple-900/5">
          <div className="max-w-xl mx-auto text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-pink-100 text-[#EC4186] flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#38124A]">
              Track Your Tailoring Order
            </h2>
            <p className="text-sm text-slate-600">
              Have an active order slip? Enter your Job ID (e.g.{' '}
              <button
                type="button"
                onClick={() => setTrackInput('TT-JOB-5018')}
                className="font-mono font-bold text-[#EC4186] underline hover:text-[#D82F73]"
              >
                TT-JOB-5018
              </button>{' '}
              or{' '}
              <button
                type="button"
                onClick={() => setTrackInput('TT-JOB-5019')}
                className="font-mono font-bold text-[#EC4186] underline hover:text-[#D82F73]"
              >
                TT-JOB-5019
              </button>
              ) to view real-time stage progress without logging in.
            </p>

            <form onSubmit={handleQuickTrack} className="pt-3 flex gap-2">
              <input
                type="text"
                value={trackInput}
                onChange={(e) => setTrackInput(e.target.value)}
                placeholder="Enter Job ID (e.g. TT-JOB-5018)"
                className="flex-1 px-4 py-3 text-sm bg-white border border-slate-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#EC4186]/30 focus:border-[#EC4186] shadow-xs uppercase tracking-wider font-mono"
              />
              <button
                type="submit"
                disabled={isSearching}
                className="px-6 py-3 bg-[#38124A] hover:bg-[#270A34] text-white font-semibold text-sm rounded-2xl transition shadow-md active:scale-98 flex items-center gap-1.5 shrink-0"
              >
                {isSearching ? 'Searching...' : 'Track'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {quickTrackError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2 text-left mt-3">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{quickTrackError}</span>
              </div>
            )}
          </div>

          {/* Quick Track Result Card */}
          {quickTrackResult && (
            <div className="mt-8 pt-8 border-t border-slate-100 space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#F8F5FA] p-5 rounded-2xl border border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-lg text-[#38124A]">{quickTrackResult.jobId}</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider bg-pink-100 text-[#EC4186]">
                      {quickTrackResult.currentStage.replace('_', ' ')}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-[#1F2340] mt-1">{quickTrackResult.garmentType}</h4>
                  <p className="text-xs text-slate-500">Customer: {quickTrackResult.customerName}</p>
                </div>
                <div className="text-left sm:text-right">
                  <span className="text-xs text-slate-500 block">Expected Readiness</span>
                  <span className="text-sm font-bold text-emerald-700">
                    {new Date(quickTrackResult.estimatedCompletion).toLocaleDateString([], {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </span>
                  <button
                    onClick={() => onTrackOrder(quickTrackResult.jobId)}
                    className="block sm:inline-block mt-2 text-xs font-bold text-[#EC4186] hover:underline"
                  >
                    View Complete 9-Stage Timeline →
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* The Problem vs Solution */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EC4186]">Why TailorTime?</span>
          <h2 className="text-3xl font-serif font-bold text-[#38124A] mt-2">
            The traditional tailoring headache is solved.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Old Way */}
          <div className="bg-white p-8 rounded-3xl border border-rose-100 shadow-sm relative overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold mb-4">
              ✕
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-3">The Old Walk-in Way</h3>
            <ul className="space-y-3 text-sm text-slate-600">
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">•</span>
                <span>Unpredictable waiting queues during festive & wedding seasons.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">•</span>
                <span>Having to call the tailor repeatedly: "Bhaiya, is my blouse stitched yet?"</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">•</span>
                <span>Arriving at the shop only to discover the garment isn't ready for fitting.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-rose-500 font-bold">•</span>
                <span>Lost paper measurement slips and incorrect fit alterations.</span>
              </li>
            </ul>
          </div>

          {/* TailorTime Way */}
          <div className="bg-gradient-to-br from-[#38124A] to-[#521E6B] text-white p-8 rounded-3xl shadow-lg relative overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-white/20 text-[#EC4186] flex items-center justify-center font-bold mb-4">
              ✓
            </div>
            <h3 className="text-lg font-bold text-white mb-3">The TailorTime Way</h3>
            <ul className="space-y-3 text-sm text-white/90">
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Reserved fitting slots with strict 10 appointments/hour capacity. Zero crowd.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Live order progress tracker from Cutting to Stitching to Quality Check.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Automated WhatsApp & SMS alerts when your outfit is pressed and ready.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Digital customer measurement cards securely saved for repeat styling.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* 3-Step Simple Flow */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EC4186]">Effortless Experience</span>
          <h2 className="text-3xl font-serif font-bold text-[#38124A] mt-2">
            How TailorTime Works
          </h2>
          <p className="text-sm text-slate-600 mt-2">Book • Track • Collect in 3 simple steps</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Step 1 */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm relative group hover:border-[#EC4186]/40 transition duration-300">
            <div className="w-14 h-14 rounded-2xl bg-purple-50 text-[#38124A] font-bold text-xl flex items-center justify-center mb-6 group-hover:scale-105 transition">
              1
            </div>
            <h3 className="text-lg font-bold text-[#1F2340] mb-2">Book Your Slot</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Choose your service (Bespoke outfit, alterations, trial fitting) and select an available time slot. We prevent overbooking.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm relative group hover:border-[#EC4186]/40 transition duration-300">
            <div className="w-14 h-14 rounded-2xl bg-pink-50 text-[#EC4186] font-bold text-xl flex items-center justify-center mb-6 group-hover:scale-105 transition">
              2
            </div>
            <h3 className="text-lg font-bold text-[#1F2340] mb-2">Track Tailoring</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Watch your garment move along the 9 production stages: Measurement, Cutting, Stitching, Fitting, and Quality Check.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm relative group hover:border-[#EC4186]/40 transition duration-300">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-700 font-bold text-xl flex items-center justify-center mb-6 group-hover:scale-105 transition">
              3
            </div>
            <h3 className="text-lg font-bold text-[#1F2340] mb-2">Collect When Ready</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Receive a WhatsApp notification as soon as your garment is packed. Walk in, try it on, and take it home without delay!
            </p>
          </div>
        </div>
      </section>

      {/* Services Showcase */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="bg-[#38124A] text-white rounded-3xl p-8 sm:p-12 shadow-xl">
          <div className="max-w-2xl mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-[#EC4186]">Our Craft</span>
            <h2 className="text-3xl font-serif font-bold mt-2">Services Crafted for Perfection</h2>
            <p className="text-sm text-white/80 mt-2">
              From bespoke bridal ensembles to rapid wardrobe adjustments, reserve dedicated master craftsman attention.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white/10 backdrop-blur-xs p-6 rounded-2xl border border-white/10 hover:bg-white/15 transition">
              <span className="text-2xl">👗</span>
              <h4 className="text-base font-bold text-white mt-3">New Outfit Creation</h4>
              <p className="text-xs text-white/70 mt-1">
                Custom Lehengas, Anarkalis, Gowns, Bespoke Suits, and Kurtas made from scratch.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-xs p-6 rounded-2xl border border-white/10 hover:bg-white/15 transition">
              <span className="text-2xl">✂️</span>
              <h4 className="text-base font-bold text-white mt-3">Precision Alteration</h4>
              <p className="text-xs text-white/70 mt-1">
                Waist resizing, trouser tapers, sleeve adjustments, zipper replacements, and relining.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-xs p-6 rounded-2xl border border-white/10 hover:bg-white/15 transition">
              <span className="text-2xl">📐</span>
              <h4 className="text-base font-bold text-white mt-3">Master Measurement</h4>
              <p className="text-xs text-white/70 mt-1">
                Comprehensive 10-point body measurements taken by Master Rameshwar.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-xs p-6 rounded-2xl border border-white/10 hover:bg-white/15 transition">
              <span className="text-2xl">✨</span>
              <h4 className="text-base font-bold text-white mt-3">Trial Fitting & Trial</h4>
              <p className="text-xs text-white/70 mt-1">
                Private dressing room fitting trial with pin marking for millimeter precision.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-[#EC4186]">Happy Customers</span>
          <h2 className="text-3xl font-serif font-bold text-[#38124A] mt-2">Loved by Indian Shoppers</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex text-amber-400 text-sm">★★★★★</div>
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "During Diwali rush, I used to wait 1 hour just to give measurements. With TailorTime, I booked the 11 AM slot, walked straight into the fitting room, and got my WhatsApp readiness ping 3 days later!"
            </p>
            <div className="flex items-center gap-3 pt-2">
              <div className="w-9 h-9 rounded-full bg-pink-100 text-[#EC4186] font-bold text-xs flex items-center justify-center">
                RM
              </div>
              <div>
                <p className="text-xs font-bold text-[#1F2340]">Riya Mehta</p>
                <p className="text-[10px] text-slate-400">Indiranagar, Bengaluru</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex text-amber-400 text-sm">★★★★★</div>
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "Tracking my tuxedo from cutting to stitching on the visual timeline gave me total peace of mind for my sister's wedding. Excellent craftsmanship and zero follow-up calls needed."
            </p>
            <div className="flex items-center gap-3 pt-2">
              <div className="w-9 h-9 rounded-full bg-purple-100 text-[#38124A] font-bold text-xs flex items-center justify-center">
                AS
              </div>
              <div>
                <p className="text-xs font-bold text-[#1F2340]">Aarav Sharma</p>
                <p className="text-[10px] text-slate-400">HSR Layout, Bengaluru</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="flex text-amber-400 text-sm">★★★★★</div>
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "As a shop owner, the 10/hour capacity limit has eliminated the chaotic crowds on weekends. Our tailors work with focus and our on-time delivery rate jumped to 98%."
            </p>
            <div className="flex items-center gap-3 pt-2">
              <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-800 font-bold text-xs flex items-center justify-center">
                MR
              </div>
              <div>
                <p className="text-xs font-bold text-[#1F2340]">Master Rameshwar</p>
                <p className="text-[10px] text-slate-400">Head Tailor & Shop Admin</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <div className="bg-gradient-to-r from-pink-50 via-purple-50 to-pink-50 p-8 sm:p-12 rounded-3xl border border-[#EC4186]/20 space-y-5">
          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#38124A]">
            Ready for a better fitting experience?
          </h2>
          <p className="text-sm text-slate-600 max-w-lg mx-auto">
            Book your guaranteed time slot today and experience hassle-free tailoring with real-time updates.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={onOpenBooking}
              className="w-full sm:w-auto px-8 py-3.5 bg-[#EC4186] hover:bg-[#D82F73] text-white font-bold text-sm rounded-2xl shadow-lg shadow-[#EC4186]/25 transition"
            >
              Book Your Appointment Now
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="w-full sm:w-auto px-6 py-3.5 bg-white text-[#38124A] border border-slate-200 font-semibold text-sm rounded-2xl hover:bg-slate-50 transition"
            >
              Customer Sign In
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
