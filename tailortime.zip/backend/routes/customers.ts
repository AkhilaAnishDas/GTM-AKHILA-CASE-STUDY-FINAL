import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// List customers (Admin only)
router.get('/', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { search } = req.query;
    let customers = db.users.find({ role: 'customer' });

    if (search) {
      const q = String(search).toLowerCase();
      customers = customers.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q) ||
          c.phone.includes(q)
      );
    }

    // Attach summary stats for each customer (total orders, active jobs, last visit)
    const result = customers.map((c) => {
      const orders = db.orders.find((o) => o.customerId === c._id);
      const appointments = db.appointments.find((a) => a.customerId === c._id);
      const activeJobs = orders.filter((o) => o.currentStage !== 'collected');
      const measurements = db.measurements.findByCustomerId(c._id);

      const { passwordHash: _, ...safeCustomer } = c;
      return {
        ...safeCustomer,
        totalOrders: orders.length,
        activeJobsCount: activeJobs.length,
        totalAppointments: appointments.length,
        hasMeasurements: !!measurements,
      };
    });

    res.json({ customers: result });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch customers' });
  }
});

// Get single customer details with full history
router.get('/:id', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const customer = db.users.findById(req.params.id);
    if (!customer) {
      res.status(404).json({ message: 'Customer not found' });
      return;
    }

    const appointments = db.appointments.find((a) => a.customerId === customer._id);
    const orders = db.orders.find((o) => o.customerId === customer._id);
    const measurements = db.measurements.findByCustomerId(customer._id);

    const { passwordHash: _, ...safeCustomer } = customer;
    res.json({
      customer: safeCustomer,
      appointments,
      orders,
      measurements,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch customer profile' });
  }
});

export default router;
