import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// Get customer measurements
router.get('/:customerId', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { customerId } = req.params;
    const user = req.user!;

    if (user.role === 'customer' && user._id !== customerId) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    const record = db.measurements.findByCustomerId(customerId);
    res.json({ measurements: record || null });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch measurements' });
  }
});

// Create or Upsert measurements
router.post('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const {
      customerId = user._id,
      customerName = user.name,
      phone = user.phone,
      chest,
      waist,
      shoulder,
      sleeve,
      length,
      hip,
      inseam,
      neck,
      notes,
    } = req.body;

    if (user.role === 'customer' && customerId !== user._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    const record = db.measurements.upsert({
      customerId,
      customerName,
      phone,
      chest,
      waist,
      shoulder,
      sleeve,
      length,
      hip,
      inseam,
      neck,
      notes,
    });

    res.json({ measurements: record, message: 'Measurements saved successfully!' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to save measurements' });
  }
});

// Update measurement by ID
router.put('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const record = db.measurements.find((m) => m._id === req.params.id)[0];
    if (!record) {
      res.status(404).json({ message: 'Measurement record not found' });
      return;
    }

    if (req.user!.role === 'customer' && record.customerId !== req.user!._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    const updated = db.measurements.upsert({
      ...record,
      ...req.body,
      customerId: record.customerId,
    });

    res.json({ measurements: updated, message: 'Measurements updated!' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to update measurements' });
  }
});

export default router;
