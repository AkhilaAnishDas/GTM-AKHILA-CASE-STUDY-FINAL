import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, AuthenticatedRequest } from '../middleware/auth.js';
import { AppointmentStatus, AppointmentService } from '../types.js';

const router = Router();

// List appointments
router.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { date, status, search } = req.query;

    let appointments = db.appointments.find((apt) => {
      // If customer, only see own appointments
      if (user.role === 'customer' && apt.customerId !== user._id) {
        return false;
      }

      // Filter by date
      if (date && apt.date !== date) {
        return false;
      }

      // Filter by status
      if (status && status !== 'all' && apt.status !== status) {
        return false;
      }

      // Filter by search (name, phone, appointmentId)
      if (search) {
        const q = String(search).toLowerCase();
        const matchName = apt.customerName.toLowerCase().includes(q);
        const matchPhone = apt.phone.includes(q);
        const matchId = apt.appointmentId.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchId) {
          return false;
        }
      }

      return true;
    });

    // Sort by date descending and time slot
    appointments.sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return a.timeSlot.localeCompare(b.timeSlot);
    });

    res.json({ appointments });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch appointments' });
  }
});

// Get single appointment
router.get('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const apt = db.appointments.findById(req.params.id);
    if (!apt) {
      res.status(404).json({ message: 'Appointment not found' });
      return;
    }

    // Role check
    if (req.user!.role === 'customer' && apt.customerId !== req.user!._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    res.json({ appointment: apt });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch appointment' });
  }
});

// Book / Create appointment
router.post('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const {
      service,
      date,
      timeSlot,
      notes,
      customerName: customName,
      phone: customPhone,
      customerId: customCustId,
    } = req.body;

    if (!service || !date || !timeSlot) {
      res.status(400).json({ message: 'Service, date, and time slot are required' });
      return;
    }

    // Capacity Check
    const shopSettings = db.shopSettings.get();
    const maxCapacity = shopSettings.maxCapacityPerSlot || 10;

    const existingInSlot = db.appointments.find(
      (a) => a.date === date && a.timeSlot === timeSlot && a.status !== 'cancelled'
    );

    if (existingInSlot.length >= maxCapacity) {
      res.status(400).json({
        message: `This slot is fully booked (${existingInSlot.length}/${maxCapacity} capacity). Please pick another time slot.`,
      });
      return;
    }

    const customerId = user.role === 'admin' && customCustId ? customCustId : user._id;
    const customerName = user.role === 'admin' && customName ? customName : user.name;
    const phone = user.role === 'admin' && customPhone ? customPhone : user.phone;

    // Check duplicate booking for the same customer at the same slot
    const duplicate = existingInSlot.find((a) => a.customerId === customerId);
    if (duplicate) {
      res.status(400).json({
        message: `You already have an appointment booked for ${date} at ${timeSlot} (${duplicate.appointmentId}).`,
      });
      return;
    }

    const appointment = db.appointments.create({
      customerId,
      customerName,
      phone,
      service: service as AppointmentService,
      date,
      timeSlot,
      notes: notes || '',
      status: 'confirmed', // Confirmed right away
    });

    // Send simulated in-app and WhatsApp notification to customer
    db.notifications.create({
      userId: customerId,
      title: 'Appointment Confirmed! ✂️',
      message: `Your ${service} appointment is confirmed for ${date} at ${timeSlot} (ID: ${appointment.appointmentId}). We look forward to seeing you at TailorTime!`,
      type: 'appointment',
      channel: 'whatsapp_simulated',
      isRead: false,
      appointmentId: appointment.appointmentId,
    });

    // Notify shop admin
    const adminUser = db.users.findOne({ role: 'admin' });
    if (adminUser) {
      db.notifications.create({
        userId: adminUser._id,
        title: `New Booking: ${customerName}`,
        message: `${customerName} booked ${service} for ${date} at ${timeSlot} (${appointment.appointmentId}).`,
        type: 'appointment',
        channel: 'in_app',
        isRead: false,
        appointmentId: appointment.appointmentId,
      });
    }

    res.status(201).json({
      appointment,
      message: 'Appointment booked successfully!',
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to book appointment' });
  }
});

// Update appointment (Status, Reschedule, Notes)
router.put('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const apt = db.appointments.findById(req.params.id);
    if (!apt) {
      res.status(404).json({ message: 'Appointment not found' });
      return;
    }

    // Role check
    if (user.role === 'customer' && apt.customerId !== user._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    const { status, date, timeSlot, notes } = req.body;
    const updates: Partial<typeof apt> = {};

    // If rescheduling date/time, verify capacity
    if (date || timeSlot) {
      const newDate = date || apt.date;
      const newTimeSlot = timeSlot || apt.timeSlot;

      if (newDate !== apt.date || newTimeSlot !== apt.timeSlot) {
        const shopSettings = db.shopSettings.get();
        const maxCapacity = shopSettings.maxCapacityPerSlot || 10;

        const slotBookings = db.appointments.find(
          (a) => a.date === newDate && a.timeSlot === newTimeSlot && a._id !== apt._id && a.status !== 'cancelled'
        );

        if (slotBookings.length >= maxCapacity) {
          res.status(400).json({
            message: `Selected slot on ${newDate} at ${newTimeSlot} is fully booked (${slotBookings.length}/${maxCapacity}).`,
          });
          return;
        }

        updates.date = newDate;
        updates.timeSlot = newTimeSlot;

        // Notify customer about reschedule
        db.notifications.create({
          userId: apt.customerId,
          title: 'Appointment Rescheduled 📅',
          message: `Your appointment ${apt.appointmentId} has been rescheduled to ${newDate} at ${newTimeSlot}.`,
          type: 'appointment',
          channel: 'whatsapp_simulated',
          isRead: false,
          appointmentId: apt.appointmentId,
        });
      }
    }

    if (status && status !== apt.status) {
      updates.status = status as AppointmentStatus;
      if (status === 'completed') {
        updates.attendedAt = new Date().toISOString();
      }

      // Notify customer if cancelled or completed
      if (status === 'cancelled') {
        db.notifications.create({
          userId: apt.customerId,
          title: 'Appointment Cancelled',
          message: `Your appointment ${apt.appointmentId} for ${apt.date} at ${apt.timeSlot} has been cancelled.`,
          type: 'appointment',
          channel: 'in_app',
          isRead: false,
          appointmentId: apt.appointmentId,
        });
      }
    }

    if (notes !== undefined) {
      updates.notes = notes;
    }

    const updated = db.appointments.findByIdAndUpdate(apt._id, updates);
    res.json({ appointment: updated, message: 'Appointment updated successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to update appointment' });
  }
});

// Delete / Cancel appointment
router.delete('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const apt = db.appointments.findById(req.params.id);
    if (!apt) {
      res.status(404).json({ message: 'Appointment not found' });
      return;
    }

    if (user.role === 'customer' && apt.customerId !== user._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    // Mark as cancelled rather than permanently purging so records remain intact
    const updated = db.appointments.findByIdAndUpdate(apt._id, { status: 'cancelled' });
    res.json({ appointment: updated, message: 'Appointment cancelled successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to cancel appointment' });
  }
});

export default router;
