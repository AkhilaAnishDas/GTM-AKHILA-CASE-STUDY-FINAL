import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, AuthenticatedRequest } from '../middleware/auth.js';
import { SlotCapacity } from '../types.js';

const router = Router();

const DEFAULT_SLOTS = [
  '09:00 AM',
  '10:00 AM',
  '11:00 AM',
  '12:00 PM',
  '02:00 PM',
  '03:00 PM',
  '04:00 PM',
  '05:00 PM',
  '06:00 PM',
];

// Get capacity matrix for a specific date
router.get('/', (req, res) => {
  try {
    const todayStr = new Date().toISOString().split('T')[0];
    const targetDate = (req.query.date as string) || todayStr;

    const shopSettings = db.shopSettings.get();
    const maxCapacity = shopSettings.maxCapacityPerSlot || 10;

    // Fetch non-cancelled appointments on that day
    const dayAppointments = db.appointments.find(
      (a) => a.date === targetDate && a.status !== 'cancelled'
    );

    const capacityMatrix: SlotCapacity[] = DEFAULT_SLOTS.map((slot) => {
      const slotApts = dayAppointments.filter((a) => a.timeSlot === slot);
      const booked = slotApts.length;
      const available = Math.max(0, maxCapacity - booked);
      const isFull = booked >= maxCapacity;

      return {
        timeSlot: slot,
        capacity: maxCapacity,
        booked,
        available,
        isFull,
        appointments: slotApts.map((a) => ({
          appointmentId: a.appointmentId,
          customerName: a.customerName,
          service: a.service,
          status: a.status,
        })),
      };
    });

    const totalCapacity = DEFAULT_SLOTS.length * maxCapacity;
    const totalBooked = dayAppointments.length;
    const totalAvailable = Math.max(0, totalCapacity - totalBooked);
    const occupancyPercentage = Math.round((totalBooked / totalCapacity) * 100);

    res.json({
      date: targetDate,
      maxCapacityPerSlot: maxCapacity,
      totalCapacity,
      totalBooked,
      totalAvailable,
      occupancyPercentage,
      slots: capacityMatrix,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch capacity matrix' });
  }
});

export default router;
