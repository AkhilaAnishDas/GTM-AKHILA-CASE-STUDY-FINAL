import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';
import { OrderStage, OrderStageHistory } from '../types.js';

const router = Router();

// Public tracking lookup by Job ID (no login required!)
router.get('/track/:jobId', (req, res) => {
  try {
    const rawJobId = req.params.jobId.trim().toUpperCase();
    const order = db.orders.find((o) => o.jobId.toUpperCase() === rawJobId || o._id === rawJobId)[0];

    if (!order) {
      res.status(404).json({ message: `No tailoring job found with ID "${rawJobId}". Please check your order slip.` });
      return;
    }

    // Mask phone number for privacy
    const maskedPhone = order.phone.replace(/(\+?\d{2,4})\d+(\d{3})/, '$1•••••$2');

    res.json({
      order: {
        ...order,
        phone: maskedPhone,
      },
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Error tracking order' });
  }
});

// List orders
router.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { stage, search, customerId } = req.query;

    let orders = db.orders.find((ord) => {
      // If customer, only see own orders
      if (user.role === 'customer' && ord.customerId !== user._id) {
        return false;
      }

      // If customerId filter provided (for admin inspecting a customer)
      if (customerId && ord.customerId !== customerId) {
        return false;
      }

      // Filter by stage
      if (stage && stage !== 'all' && ord.currentStage !== stage) {
        return false;
      }

      // Search by jobId, customerName, garmentType, phone
      if (search) {
        const q = String(search).toLowerCase();
        const matchId = ord.jobId.toLowerCase().includes(q);
        const matchName = ord.customerName.toLowerCase().includes(q);
        const matchGarment = ord.garmentType.toLowerCase().includes(q);
        const matchPhone = ord.phone.includes(q);
        if (!matchId && !matchName && !matchGarment && !matchPhone) {
          return false;
        }
      }

      return true;
    });

    // Sort: active jobs first, then by createdAt desc
    orders.sort((a, b) => {
      if (a.currentStage === 'collected' && b.currentStage !== 'collected') return 1;
      if (a.currentStage !== 'collected' && b.currentStage === 'collected') return -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    res.json({ orders });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch orders' });
  }
});

// Get single order
router.get('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const order = db.orders.findById(req.params.id);
    if (!order) {
      res.status(404).json({ message: 'Order not found' });
      return;
    }

    if (req.user!.role === 'customer' && order.customerId !== req.user!._id) {
      res.status(403).json({ message: 'Access denied' });
      return;
    }

    res.json({ order });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch order' });
  }
});

// Create new order (Admin only, or created from an appointment)
router.post('/', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      customerId,
      customerName,
      phone,
      service,
      garmentType,
      measurements = {},
      notes,
      assignedTailor = 'Master Tailor Rameshwar',
      estimatedCompletion,
      price = 0,
      advancePaid = 0,
      appointmentId,
    } = req.body;

    if (!customerName || !phone || !garmentType) {
      res.status(400).json({ message: 'Customer name, phone, and garment type are required' });
      return;
    }

    const defaultEstimated =
      estimatedCompletion ||
      new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0];

    const initialHistory: OrderStageHistory[] = [
      {
        stage: 'appointment',
        timestamp: new Date().toISOString(),
        note: appointmentId ? `Order initiated from appointment ${appointmentId}` : 'Walk-in / Direct order creation',
        completedBy: req.user!.name,
      },
    ];

    // If measurements are provided, also record stage
    if (Object.keys(measurements).length > 0) {
      initialHistory.push({
        stage: 'measurement',
        timestamp: new Date().toISOString(),
        note: 'Body measurements recorded in job card',
        completedBy: req.user!.name,
      });
    }

    const currentStage: OrderStage = Object.keys(measurements).length > 0 ? 'cutting' : 'measurement';

    const order = db.orders.create({
      customerId: customerId || `cust_${Date.now()}`,
      customerName: customerName.trim(),
      phone: phone.trim(),
      service: service || 'New Outfit',
      garmentType: garmentType.trim(),
      measurements,
      notes: notes || '',
      currentStage,
      stagesHistory: initialHistory,
      assignedTailor,
      estimatedCompletion: defaultEstimated,
      price: Number(price) || 0,
      advancePaid: Number(advancePaid) || 0,
      appointmentId: appointmentId || undefined,
    });

    // Notify customer
    db.notifications.create({
      userId: order.customerId,
      title: `Tailoring Job Created: ${order.jobId} 🧵`,
      message: `Your order for "${order.garmentType}" has been logged! Track live status anytime using Job ID: ${order.jobId}.`,
      type: 'job_status',
      channel: 'whatsapp_simulated',
      isRead: false,
      orderId: order.jobId,
    });

    // If created from appointment, update appointment status to completed
    if (appointmentId) {
      const apt = db.appointments.findById(appointmentId);
      if (apt) {
        db.appointments.findByIdAndUpdate(apt._id, {
          status: 'completed',
          attendedAt: new Date().toISOString(),
        });
      }
    }

    res.status(201).json({ order, message: 'Job card created successfully!' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to create order' });
  }
});

// Update order stage / details (Admin only)
router.put('/:id', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const order = db.orders.findById(req.params.id);
    if (!order) {
      res.status(404).json({ message: 'Order not found' });
      return;
    }

    const {
      currentStage,
      stageNote,
      estimatedCompletion,
      assignedTailor,
      measurements,
      notes,
      price,
      advancePaid,
    } = req.body;

    const updates: Partial<typeof order> = {};

    if (estimatedCompletion) updates.estimatedCompletion = estimatedCompletion;
    if (assignedTailor) updates.assignedTailor = assignedTailor;
    if (measurements) updates.measurements = measurements;
    if (notes !== undefined) updates.notes = notes;
    if (price !== undefined) updates.price = Number(price);
    if (advancePaid !== undefined) updates.advancePaid = Number(advancePaid);

    // If stage changed
    if (currentStage && currentStage !== order.currentStage) {
      updates.currentStage = currentStage as OrderStage;

      const newHistoryItem: OrderStageHistory = {
        stage: currentStage as OrderStage,
        timestamp: new Date().toISOString(),
        note: stageNote || `Status updated to ${currentStage}`,
        completedBy: req.user!.name,
      };

      updates.stagesHistory = [...order.stagesHistory, newHistoryItem];

      if (currentStage === 'ready') {
        updates.readyDate = new Date().toISOString();
        // Send high priority ready notification (WhatsApp + in-app)
        db.notifications.create({
          userId: order.customerId,
          title: '🎉 Your Outfit is Ready for Collection!',
          message: `Hurray! Your "${order.garmentType}" (${order.jobId}) is tailored to perfection and ready for trial/collection at TailorTime.`,
          type: 'ready',
          channel: 'whatsapp_simulated',
          isRead: false,
          orderId: order.jobId,
        });
      } else if (currentStage === 'collected') {
        updates.collectedDate = new Date().toISOString();
        db.notifications.create({
          userId: order.customerId,
          title: 'Thank You for Visiting! ✂️',
          message: `Your outfit (${order.jobId}) has been collected. We hope you love the fit! Rate us or book your next fitting anytime.`,
          type: 'collection_reminder',
          channel: 'in_app',
          isRead: false,
          orderId: order.jobId,
        });
      } else {
        // General stage update notification
        const readableStage = currentStage.replace('_', ' ').toUpperCase();
        db.notifications.create({
          userId: order.customerId,
          title: `Order Update: ${readableStage}`,
          message: `Your "${order.garmentType}" (${order.jobId}) is now in the ${readableStage} phase. ${stageNote ? `"${stageNote}"` : ''}`,
          type: 'job_status',
          channel: 'in_app',
          isRead: false,
          orderId: order.jobId,
        });
      }
    }

    const updated = db.orders.findByIdAndUpdate(order._id, updates);
    res.json({ order: updated, message: 'Order updated successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to update order' });
  }
});

export default router;
