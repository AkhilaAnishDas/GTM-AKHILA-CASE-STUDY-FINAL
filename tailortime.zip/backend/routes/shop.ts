import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, requireAdmin, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// Public: get shop details
router.get('/', (_req, res) => {
  try {
    const settings = db.shopSettings.get();
    res.json({ shop: settings });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch shop settings' });
  }
});

// Admin: update shop details
router.put('/', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      shopName,
      tagline,
      address,
      phone,
      email,
      openingHours,
      closingHours,
      slotDurationMinutes,
      maxCapacityPerSlot,
      workingDays,
      announcement,
    } = req.body;

    const updated = db.shopSettings.update({
      ...(shopName && { shopName: shopName.trim() }),
      ...(tagline && { tagline: tagline.trim() }),
      ...(address && { address: address.trim() }),
      ...(phone && { phone: phone.trim() }),
      ...(email && { email: email.trim() }),
      ...(openingHours && { openingHours }),
      ...(closingHours && { closingHours }),
      ...(slotDurationMinutes && { slotDurationMinutes: Number(slotDurationMinutes) }),
      ...(maxCapacityPerSlot && { maxCapacityPerSlot: Number(maxCapacityPerSlot) }),
      ...(workingDays && { workingDays }),
      ...(announcement !== undefined && { announcement }),
    });

    res.json({ shop: updated, message: 'Shop settings updated successfully' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to update shop settings' });
  }
});

export default router;
