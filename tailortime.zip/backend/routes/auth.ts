import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db/store.js';
import { authenticate, generateToken, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// Register new user
router.post('/register', (req, res) => {
  try {
    const { name, email, phone, password, role = 'customer', address } = req.body;

    if (!name || !email || !password || !phone) {
      res.status(400).json({ message: 'Name, email, phone, and password are required' });
      return;
    }

    // Check duplicate
    const existing = db.users.findOne({ email: email.toLowerCase().trim() });
    if (existing) {
      res.status(400).json({ message: 'An account with this email already exists' });
      return;
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);

    const newUser = db.users.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      phone: phone.trim(),
      passwordHash,
      role: role === 'admin' ? 'admin' : 'customer',
      address: address ? address.trim() : '',
    });

    const token = generateToken(newUser);

    // Create a welcome notification
    db.notifications.create({
      userId: newUser._id,
      title: 'Welcome to TailorTime!',
      message: 'Your account has been created. Book your first appointment to skip the waiting line!',
      type: 'appointment',
      channel: 'in_app',
      isRead: false,
    });

    const { passwordHash: _, ...safeUser } = newUser;
    res.status(201).json({
      user: safeUser,
      token,
      message: 'Registration successful',
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Registration failed' });
  }
});

// Login
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ message: 'Email and password are required' });
      return;
    }

    const user = db.users.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      res.status(401).json({ message: 'Invalid email or password' });
      return;
    }

    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      res.status(401).json({ message: 'Invalid email or password' });
      return;
    }

    const token = generateToken(user);
    const { passwordHash: _, ...safeUser } = user;

    res.json({
      user: safeUser,
      token,
      message: 'Login successful',
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Login failed' });
  }
});

// Get current user profile
router.get('/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    res.status(401).json({ message: 'Not authenticated' });
    return;
  }
  const { passwordHash: _, ...safeUser } = req.user;
  res.json({ user: safeUser });
});

// Update current user profile
router.put('/profile', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    res.status(401).json({ message: 'Not authenticated' });
    return;
  }

  const { name, phone, address, preferredMeasurements } = req.body;
  const updated = db.users.findByIdAndUpdate(req.user._id, {
    ...(name && { name: name.trim() }),
    ...(phone && { phone: phone.trim() }),
    ...(address !== undefined && { address: address.trim() }),
    ...(preferredMeasurements && { preferredMeasurements }),
  });

  if (!updated) {
    res.status(404).json({ message: 'User not found' });
    return;
  }

  // Also sync measurements record if provided
  if (preferredMeasurements) {
    db.measurements.upsert({
      customerId: updated._id,
      customerName: updated.name,
      phone: updated.phone,
      ...preferredMeasurements,
    });
  }

  const { passwordHash: _, ...safeUser } = updated;
  res.json({ user: safeUser, message: 'Profile updated successfully' });
});

// Quick 1-click Demo Login for fast evaluations & college demos
router.post('/demo-login', (req, res) => {
  try {
    const { role } = req.body;
    let targetUser;

    if (role === 'admin') {
      targetUser = db.users.findOne({ role: 'admin' });
    } else {
      targetUser = db.users.findOne({ email: 'riya@example.com' }) || db.users.findOne({ role: 'customer' });
    }

    if (!targetUser) {
      res.status(404).json({ message: 'Demo user not found' });
      return;
    }

    const token = generateToken(targetUser);
    const { passwordHash: _, ...safeUser } = targetUser;

    res.json({
      user: safeUser,
      token,
      message: `Logged in as ${targetUser.role === 'admin' ? 'Master Tailor' : 'Customer (${targetUser.name})'}`,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Demo login failed' });
  }
});

// Reset database to seed
router.post('/reset-demo', (_req, res) => {
  db.resetToDefaults();
  res.json({ message: 'Database reset to initial demo data.' });
});

export default router;
