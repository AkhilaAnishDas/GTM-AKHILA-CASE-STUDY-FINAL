import { Router, Response } from 'express';
import { db } from '../db/store.js';
import { authenticate, AuthenticatedRequest } from '../middleware/auth.js';

const router = Router();

// List notifications
router.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const notifs = db.notifications.find((n) => {
      if (user.role === 'admin') {
        // Admin sees admin notifications + system events
        return n.userId === user._id || n.userId === 'admin' || n.userId === 'all';
      }
      return n.userId === user._id;
    });

    // Sort newest first
    notifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const unreadCount = notifs.filter((n) => !n.isRead).length;

    res.json({
      notifications: notifs,
      unreadCount,
    });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to fetch notifications' });
  }
});

// Mark single notification as read
router.put('/:id/read', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const updated = db.notifications.findByIdAndUpdate(req.params.id, { isRead: true });
    if (!updated) {
      res.status(404).json({ message: 'Notification not found' });
      return;
    }
    res.json({ notification: updated });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to update notification' });
  }
});

// Mark all notifications as read
router.put('/mark-all-read', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const count = db.notifications.markAllAsReadForUser(user._id);
    res.json({ message: `${count} notifications marked as read` });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to mark all as read' });
  }
});

// Simulate sending SMS / WhatsApp notification (for demo testing)
router.post('/simulate', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { title, message, channel = 'whatsapp_simulated', type = 'job_status' } = req.body;
    const notif = db.notifications.create({
      userId: req.user!._id,
      title: title || 'TailorTime WhatsApp Alert',
      message: message || 'Your fitting appointment is confirmed for today.',
      type,
      channel,
      isRead: false,
    });
    res.status(201).json({ notification: notif, message: 'Simulated alert sent!' });
  } catch (error: any) {
    res.status(500).json({ message: error.message || 'Failed to send alert' });
  }
});

export default router;
