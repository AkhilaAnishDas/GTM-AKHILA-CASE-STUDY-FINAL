import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import {
  User,
  Appointment,
  Order,
  Notification,
  MeasurementRecord,
  ShopSettings,
} from '../types.js';

interface DatabaseData {
  users: User[];
  appointments: Appointment[];
  orders: Order[];
  notifications: Notification[];
  measurements: MeasurementRecord[];
  shopSettings: ShopSettings;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.resolve(DATA_DIR, 'db.json');

// Initial seed data with realistic Indian tailoring shop details
const defaultShopSettings: ShopSettings = {
  _id: 'shop_001',
  shopName: 'TailorTime Bespoke & Alterations',
  tagline: 'Book • Track • Collect — Less Queue, More Certainty',
  address: 'Plot 42, 100ft Road, Indiranagar, Bengaluru, Karnataka 560038',
  phone: '+91 98450 12345',
  email: 'care@tailortime.in',
  openingHours: '09:00 AM',
  closingHours: '07:00 PM',
  slotDurationMinutes: 60,
  maxCapacityPerSlot: 10,
  workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  announcement: 'Welcome to TailorTime! Please arrive 5 minutes before your booked fitting slot.',
};

function getSeedData(): DatabaseData {
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync('tailortime123', salt);

  const users: User[] = [
    {
      _id: 'usr_admin_01',
      name: 'Master Tailor Rameshwar',
      email: 'admin@tailortime.com',
      phone: '+91 98450 12345',
      passwordHash,
      role: 'admin',
      address: 'Shop 1, Indiranagar, Bengaluru',
      createdAt: '2026-09-01T08:00:00.000Z',
    },
    {
      _id: 'usr_cust_01',
      name: 'Riya Mehta',
      email: 'riya@example.com',
      phone: '+91 98765 43210',
      passwordHash,
      role: 'customer',
      address: 'Flat 304, Palm Grove Apts, Koramangala, Bengaluru',
      preferredMeasurements: {
        chest: '34 in',
        waist: '28 in',
        shoulder: '14.5 in',
        sleeve: '21 in',
        length: '46 in',
        hip: '38 in',
      },
      createdAt: '2026-09-10T10:00:00.000Z',
    },
    {
      _id: 'usr_cust_02',
      name: 'Aarav Sharma',
      email: 'aarav@example.com',
      phone: '+91 98111 22334',
      passwordHash,
      role: 'customer',
      address: 'House 12, 4th Cross, HSR Layout, Bengaluru',
      preferredMeasurements: {
        chest: '40 in',
        waist: '34 in',
        shoulder: '18 in',
        sleeve: '25 in',
        length: '30 in',
        hip: '40 in',
        neck: '16 in',
      },
      createdAt: '2026-09-15T11:30:00.000Z',
    },
    {
      _id: 'usr_cust_03',
      name: 'Ananya Patil',
      email: 'ananya@example.com',
      phone: '+91 97222 33445',
      passwordHash,
      role: 'customer',
      address: '22 Richmond Town, Bengaluru',
      createdAt: '2026-09-20T14:15:00.000Z',
    },
    {
      _id: 'usr_cust_04',
      name: 'Rahul Deshmukh',
      email: 'rahul@example.com',
      phone: '+91 96333 44556',
      passwordHash,
      role: 'customer',
      address: '88 MG Road, Bengaluru',
      createdAt: '2026-09-22T09:00:00.000Z',
    },
  ];

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const nextWeek = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];

  const appointments: Appointment[] = [
    {
      _id: 'apt_001',
      appointmentId: 'TT-APT-8921',
      customerId: 'usr_cust_01',
      customerName: 'Riya Mehta',
      phone: '+91 98765 43210',
      service: 'Fitting',
      date: today,
      timeSlot: '11:00 AM',
      notes: 'Final trial fitting for Festive Raw Silk Anarkali.',
      status: 'confirmed',
      createdAt: '2026-09-28T10:00:00.000Z',
    },
    {
      _id: 'apt_002',
      appointmentId: 'TT-APT-8922',
      customerId: 'usr_cust_02',
      customerName: 'Aarav Sharma',
      phone: '+91 98111 22334',
      service: 'Measurement',
      date: today,
      timeSlot: '02:00 PM',
      notes: 'Bespoke Tuxedo & Bandhgala measurement.',
      status: 'confirmed',
      createdAt: '2026-09-29T11:20:00.000Z',
    },
    {
      _id: 'apt_003',
      appointmentId: 'TT-APT-8923',
      customerId: 'usr_cust_03',
      customerName: 'Ananya Patil',
      phone: '+91 97222 33445',
      service: 'Alteration',
      date: today,
      timeSlot: '11:00 AM',
      notes: 'Designer lehenga waist adjustment and zipper fix.',
      status: 'confirmed',
      createdAt: '2026-09-29T15:40:00.000Z',
    },
    {
      _id: 'apt_004',
      appointmentId: 'TT-APT-8924',
      customerId: 'usr_cust_04',
      customerName: 'Rahul Deshmukh',
      phone: '+91 96333 44556',
      service: 'Pickup / Collection',
      date: today,
      timeSlot: '04:00 PM',
      notes: 'Pick up 2 Formal Trousers and Linen Kurta.',
      status: 'pending',
      createdAt: '2026-09-30T09:10:00.000Z',
    },
    {
      _id: 'apt_005',
      appointmentId: 'TT-APT-8919',
      customerId: 'usr_cust_01',
      customerName: 'Riya Mehta',
      phone: '+91 98765 43210',
      service: 'New Outfit',
      date: yesterday,
      timeSlot: '10:00 AM',
      notes: 'Initial styling discussion and fabric selection.',
      status: 'completed',
      createdAt: '2026-09-25T14:00:00.000Z',
      attendedAt: `${yesterday}T10:05:00.000Z`,
    },
    {
      _id: 'apt_006',
      appointmentId: 'TT-APT-8925',
      customerId: 'usr_cust_03',
      customerName: 'Ananya Patil',
      phone: '+91 97222 33445',
      service: 'New Outfit',
      date: tomorrow,
      timeSlot: '03:00 PM',
      notes: 'Bridal Blouse stitching consultation with embroidery motifs.',
      status: 'pending',
      createdAt: '2026-09-30T17:00:00.000Z',
    },
  ];

  const orders: Order[] = [
    {
      _id: 'ord_001',
      jobId: 'TT-JOB-5018',
      appointmentId: 'TT-APT-8921',
      customerId: 'usr_cust_01',
      customerName: 'Riya Mehta',
      phone: '+91 98765 43210',
      service: 'New Outfit',
      garmentType: 'Pure Raw Silk Anarkali Suit with Zari Border',
      measurements: {
        chest: '34 in',
        waist: '28 in',
        shoulder: '14.5 in',
        sleeve: '21 in',
        length: '48 in',
        hip: '38 in',
      },
      notes: 'Handcrafted neckline with antique gold zari piping. Extra margin of 1.5 inches left inside.',
      currentStage: 'fitting',
      stagesHistory: [
        {
          stage: 'appointment',
          timestamp: '2026-09-25T10:15:00.000Z',
          note: 'Consultation & design finalized.',
          completedBy: 'Rameshwar (Master Tailor)',
        },
        {
          stage: 'measurement',
          timestamp: '2026-09-25T10:45:00.000Z',
          note: 'Detailed 8-point measurement taken.',
          completedBy: 'Rameshwar (Master Tailor)',
        },
        {
          stage: 'cutting',
          timestamp: '2026-09-26T14:30:00.000Z',
          note: 'Precision fabric cutting complete, interlining prepared.',
          completedBy: 'Suresh (Cutter)',
        },
        {
          stage: 'stitching',
          timestamp: '2026-09-28T18:00:00.000Z',
          note: 'Main bodices stitched, side seams basted for trial fitting.',
          completedBy: 'Mohan (Senior Craftsman)',
        },
        {
          stage: 'fitting',
          timestamp: '2026-09-30T11:00:00.000Z',
          note: 'Trial fitting scheduled for today.',
          completedBy: 'Rameshwar (Master Tailor)',
        },
      ],
      assignedTailor: 'Mohan (Senior Craftsman)',
      estimatedCompletion: tomorrow,
      price: 3400,
      advancePaid: 1500,
      createdAt: '2026-09-25T10:15:00.000Z',
    },
    {
      _id: 'ord_002',
      jobId: 'TT-JOB-5019',
      appointmentId: 'TT-APT-8924',
      customerId: 'usr_cust_04',
      customerName: 'Rahul Deshmukh',
      phone: '+91 96333 44556',
      service: 'Alteration',
      garmentType: 'Italian Wool Blazer & 2 Linen Trousers',
      measurements: {
        chest: '42 in',
        waist: '36 in',
        length: '31 in',
        inseam: '32 in',
      },
      notes: 'Sleeve shortening by 1 inch, trouser taper to 7.25 inch bottom opening.',
      currentStage: 'ready',
      stagesHistory: [
        {
          stage: 'appointment',
          timestamp: '2026-09-24T16:00:00.000Z',
          note: 'Alteration marks pinned.',
          completedBy: 'Rameshwar',
        },
        {
          stage: 'measurement',
          timestamp: '2026-09-24T16:20:00.000Z',
          note: 'Hems marked with chalk.',
          completedBy: 'Rameshwar',
        },
        {
          stage: 'cutting',
          timestamp: '2026-09-25T11:00:00.000Z',
          note: 'Excess fabric trimmed with blind-stitch hem margin.',
          completedBy: 'Suresh',
        },
        {
          stage: 'stitching',
          timestamp: '2026-09-26T16:00:00.000Z',
          note: 'Re-stitched and pressed with steam iron.',
          completedBy: 'Mohan',
        },
        {
          stage: 'quality_check',
          timestamp: '2026-09-27T12:00:00.000Z',
          note: 'Passed inspection, clean thread finish.',
          completedBy: 'Rameshwar',
        },
        {
          stage: 'ready',
          timestamp: '2026-09-27T14:30:00.000Z',
          note: 'Packed in dust garment bag, ready for collection.',
          completedBy: 'Front Desk',
        },
      ],
      assignedTailor: 'Suresh (Alteration Specialist)',
      estimatedCompletion: yesterday,
      readyDate: '2026-09-27T14:30:00.000Z',
      price: 1200,
      advancePaid: 1200,
      createdAt: '2026-09-24T16:00:00.000Z',
    },
    {
      _id: 'ord_003',
      jobId: 'TT-JOB-5020',
      customerId: 'usr_cust_02',
      customerName: 'Aarav Sharma',
      phone: '+91 98111 22334',
      service: 'New Outfit',
      garmentType: 'Midnight Blue Bespoke 3-Piece Tuxedo',
      measurements: {
        chest: '40 in',
        waist: '34 in',
        shoulder: '18 in',
        sleeve: '25 in',
        length: '30 in',
        hip: '40 in',
      },
      notes: 'Peak satin lapel, hand-stitched pick stitching, contrast burgundy lining.',
      currentStage: 'cutting',
      stagesHistory: [
        {
          stage: 'appointment',
          timestamp: '2026-09-27T11:00:00.000Z',
          note: 'Fabric swatches approved by client.',
          completedBy: 'Rameshwar',
        },
        {
          stage: 'measurement',
          timestamp: '2026-09-27T11:45:00.000Z',
          note: 'Full master measurements taken.',
          completedBy: 'Rameshwar',
        },
        {
          stage: 'cutting',
          timestamp: '2026-09-29T17:00:00.000Z',
          note: 'Drafted paper pattern & wool cutting in progress.',
          completedBy: 'Rameshwar',
        },
      ],
      assignedTailor: 'Rameshwar (Master Tailor)',
      estimatedCompletion: nextWeek,
      price: 18500,
      advancePaid: 10000,
      createdAt: '2026-09-27T11:00:00.000Z',
    },
    {
      _id: 'ord_004',
      jobId: 'TT-JOB-5015',
      customerId: 'usr_cust_03',
      customerName: 'Ananya Patil',
      phone: '+91 97222 33445',
      service: 'Alteration',
      garmentType: 'Embroidered Festive Lehenga Choli',
      measurements: {
        waist: '29 in',
        length: '41 in',
      },
      notes: 'Can-can layer addition and waist belt resizing.',
      currentStage: 'collected',
      stagesHistory: [
        { stage: 'appointment', timestamp: '2026-09-15T10:00:00.000Z' },
        { stage: 'measurement', timestamp: '2026-09-15T10:30:00.000Z' },
        { stage: 'cutting', timestamp: '2026-09-16T11:00:00.000Z' },
        { stage: 'stitching', timestamp: '2026-09-17T15:00:00.000Z' },
        { stage: 'fitting', timestamp: '2026-09-18T16:00:00.000Z' },
        { stage: 'ready', timestamp: '2026-09-19T12:00:00.000Z' },
        { stage: 'collected', timestamp: '2026-09-20T18:00:00.000Z', note: 'Collected by client in person, very pleased with fit.' },
      ],
      assignedTailor: 'Mohan',
      estimatedCompletion: '2026-09-19',
      readyDate: '2026-09-19T12:00:00.000Z',
      collectedDate: '2026-09-20T18:00:00.000Z',
      price: 2200,
      advancePaid: 2200,
      createdAt: '2026-09-15T10:00:00.000Z',
    },
  ];

  const notifications: Notification[] = [
    {
      _id: 'notif_001',
      userId: 'usr_cust_01',
      title: 'Fitting Appointment Today',
      message: 'Your trial fitting appointment is scheduled for today at 11:00 AM at TailorTime Indiranagar.',
      type: 'appointment',
      channel: 'whatsapp_simulated',
      isRead: false,
      createdAt: '2026-09-30T08:00:00.000Z',
      appointmentId: 'TT-APT-8921',
      orderId: 'TT-JOB-5018',
    },
    {
      _id: 'notif_002',
      userId: 'usr_cust_01',
      title: 'Order Status Update',
      message: 'Your Raw Silk Anarkali Suit (TT-JOB-5018) has moved to the Fitting stage!',
      type: 'job_status',
      channel: 'in_app',
      isRead: false,
      createdAt: '2026-09-29T18:00:00.000Z',
      orderId: 'TT-JOB-5018',
    },
    {
      _id: 'notif_003',
      userId: 'usr_cust_04',
      title: 'Your Order is Ready for Collection! 🎉',
      message: 'Great news! Your Italian Wool Blazer & Trousers (TT-JOB-5019) are ready. Please collect at your convenience.',
      type: 'ready',
      channel: 'whatsapp_simulated',
      isRead: false,
      createdAt: '2026-09-27T14:30:00.000Z',
      orderId: 'TT-JOB-5019',
    },
    {
      _id: 'notif_004',
      userId: 'usr_cust_02',
      title: 'Fabric Cutting in Progress',
      message: 'Master Tailor Rameshwar has begun cutting the pattern for your Midnight Blue Tuxedo (TT-JOB-5020).',
      type: 'job_status',
      channel: 'sms_simulated',
      isRead: true,
      createdAt: '2026-09-29T17:05:00.000Z',
      orderId: 'TT-JOB-5020',
    },
  ];

  const measurements: MeasurementRecord[] = [
    {
      _id: 'meas_001',
      customerId: 'usr_cust_01',
      customerName: 'Riya Mehta',
      phone: '+91 98765 43210',
      chest: '34 in',
      waist: '28 in',
      shoulder: '14.5 in',
      sleeve: '21 in',
      length: '46 in',
      hip: '38 in',
      notes: 'Prefers deep round back neck and comfortable armhole ease.',
      updatedAt: '2026-09-25T10:45:00.000Z',
    },
    {
      _id: 'meas_002',
      customerId: 'usr_cust_02',
      customerName: 'Aarav Sharma',
      phone: '+91 98111 22334',
      chest: '40 in',
      waist: '34 in',
      shoulder: '18 in',
      sleeve: '25 in',
      length: '30 in',
      hip: '40 in',
      neck: '16 in',
      notes: 'Athletic build, slim cut waistline preferred.',
      updatedAt: '2026-09-27T11:45:00.000Z',
    },
  ];

  return {
    users,
    appointments,
    orders,
    notifications,
    measurements,
    shopSettings: defaultShopSettings,
  };
}

class Store {
  private data: DatabaseData;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseData {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('Could not read existing db.json, initializing fresh seed data.', err);
    }
    const seed = getSeedData();
    this.saveData(seed);
    return seed;
  }

  private saveData(dataToSave?: DatabaseData): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(dataToSave || this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save to db.json:', err);
    }
  }

  // Users
  get users() {
    return {
      find: (filter?: Partial<User>) => {
        if (!filter) return [...this.data.users];
        return this.data.users.filter((u) => {
          return Object.entries(filter).every(([key, val]) => (u as any)[key] === val);
        });
      },
      findById: (id: string) => this.data.users.find((u) => u._id === id),
      findOne: (filter: Partial<User>) => {
        return this.data.users.find((u) => {
          return Object.entries(filter).every(([key, val]) => (u as any)[key] === val);
        });
      },
      create: (user: Omit<User, '_id' | 'createdAt'> & { _id?: string; createdAt?: string }): User => {
        const newUser: User = {
          ...user,
          _id: user._id || `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          createdAt: user.createdAt || new Date().toISOString(),
        };
        this.data.users.push(newUser);
        this.saveData();
        return newUser;
      },
      findByIdAndUpdate: (id: string, updates: Partial<User>): User | null => {
        const idx = this.data.users.findIndex((u) => u._id === id);
        if (idx === -1) return null;
        this.data.users[idx] = { ...this.data.users[idx], ...updates };
        this.saveData();
        return this.data.users[idx];
      },
    };
  }

  // Appointments
  get appointments() {
    return {
      find: (filter?: (apt: Appointment) => boolean) => {
        if (!filter) return [...this.data.appointments];
        return this.data.appointments.filter(filter);
      },
      findById: (id: string) => this.data.appointments.find((a) => a._id === id || a.appointmentId === id),
      create: (apt: Omit<Appointment, '_id' | 'appointmentId' | 'createdAt'> & { _id?: string; appointmentId?: string; createdAt?: string }): Appointment => {
        const randNum = Math.floor(1000 + Math.random() * 9000);
        const newApt: Appointment = {
          ...apt,
          _id: apt._id || `apt_${Date.now()}`,
          appointmentId: apt.appointmentId || `TT-APT-${randNum}`,
          createdAt: apt.createdAt || new Date().toISOString(),
        };
        this.data.appointments.push(newApt);
        this.saveData();
        return newApt;
      },
      findByIdAndUpdate: (id: string, updates: Partial<Appointment>): Appointment | null => {
        const idx = this.data.appointments.findIndex((a) => a._id === id || a.appointmentId === id);
        if (idx === -1) return null;
        this.data.appointments[idx] = { ...this.data.appointments[idx], ...updates };
        this.saveData();
        return this.data.appointments[idx];
      },
      deleteOne: (id: string): boolean => {
        const initialLen = this.data.appointments.length;
        this.data.appointments = this.data.appointments.filter((a) => a._id !== id && a.appointmentId !== id);
        const changed = this.data.appointments.length !== initialLen;
        if (changed) this.saveData();
        return changed;
      },
    };
  }

  // Orders
  get orders() {
    return {
      find: (filter?: (ord: Order) => boolean) => {
        if (!filter) return [...this.data.orders];
        return this.data.orders.filter(filter);
      },
      findById: (id: string) => this.data.orders.find((o) => o._id === id || o.jobId === id),
      create: (ord: Omit<Order, '_id' | 'jobId' | 'createdAt'> & { _id?: string; jobId?: string; createdAt?: string }): Order => {
        const randNum = Math.floor(5000 + Math.random() * 4999);
        const newOrd: Order = {
          ...ord,
          _id: ord._id || `ord_${Date.now()}`,
          jobId: ord.jobId || `TT-JOB-${randNum}`,
          createdAt: ord.createdAt || new Date().toISOString(),
        };
        this.data.orders.push(newOrd);
        this.saveData();
        return newOrd;
      },
      findByIdAndUpdate: (id: string, updates: Partial<Order>): Order | null => {
        const idx = this.data.orders.findIndex((o) => o._id === id || o.jobId === id);
        if (idx === -1) return null;
        this.data.orders[idx] = { ...this.data.orders[idx], ...updates };
        this.saveData();
        return this.data.orders[idx];
      },
      deleteOne: (id: string): boolean => {
        const initialLen = this.data.orders.length;
        this.data.orders = this.data.orders.filter((o) => o._id !== id && o.jobId !== id);
        const changed = this.data.orders.length !== initialLen;
        if (changed) this.saveData();
        return changed;
      },
    };
  }

  // Notifications
  get notifications() {
    return {
      find: (filter?: (n: Notification) => boolean) => {
        if (!filter) return [...this.data.notifications];
        return this.data.notifications.filter(filter);
      },
      findById: (id: string) => this.data.notifications.find((n) => n._id === id),
      create: (n: Omit<Notification, '_id' | 'createdAt'> & { _id?: string; createdAt?: string }): Notification => {
        const newNotif: Notification = {
          ...n,
          _id: n._id || `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          createdAt: n.createdAt || new Date().toISOString(),
        };
        this.data.notifications.unshift(newNotif);
        this.saveData();
        return newNotif;
      },
      findByIdAndUpdate: (id: string, updates: Partial<Notification>): Notification | null => {
        const idx = this.data.notifications.findIndex((n) => n._id === id);
        if (idx === -1) return null;
        this.data.notifications[idx] = { ...this.data.notifications[idx], ...updates };
        this.saveData();
        return this.data.notifications[idx];
      },
      markAllAsReadForUser: (userId: string): number => {
        let count = 0;
        this.data.notifications.forEach((n) => {
          if ((n.userId === userId || userId === 'all') && !n.isRead) {
            n.isRead = true;
            count++;
          }
        });
        if (count > 0) this.saveData();
        return count;
      },
    };
  }

  // Measurements
  get measurements() {
    return {
      find: (filter?: (m: MeasurementRecord) => boolean) => {
        if (!filter) return [...this.data.measurements];
        return this.data.measurements.filter(filter);
      },
      findByCustomerId: (customerId: string) => {
        return this.data.measurements.find((m) => m.customerId === customerId);
      },
      upsert: (record: Omit<MeasurementRecord, '_id' | 'updatedAt'> & { _id?: string; updatedAt?: string }): MeasurementRecord => {
        const idx = this.data.measurements.findIndex((m) => m.customerId === record.customerId);
        const timestamp = new Date().toISOString();
        if (idx !== -1) {
          this.data.measurements[idx] = {
            ...this.data.measurements[idx],
            ...record,
            updatedAt: timestamp,
          };
          this.saveData();
          return this.data.measurements[idx];
        } else {
          const newMeas: MeasurementRecord = {
            ...record,
            _id: record._id || `meas_${Date.now()}`,
            updatedAt: timestamp,
          };
          this.data.measurements.push(newMeas);
          this.saveData();
          return newMeas;
        }
      },
    };
  }

  // Shop Settings
  get shopSettings() {
    return {
      get: () => ({ ...this.data.shopSettings }),
      update: (updates: Partial<ShopSettings>) => {
        this.data.shopSettings = { ...this.data.shopSettings, ...updates };
        this.saveData();
        return this.data.shopSettings;
      },
    };
  }

  // Helper for quick reset
  resetToDefaults() {
    this.data = getSeedData();
    this.saveData();
    return this.data;
  }
}

export const db = new Store();
