/**
 * TailorTime MongoDB / Mongoose Schema Definitions
 * Provides production-ready schemas for deployment with MongoDB clusters.
 */

export interface IUserSchema {
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  role: 'customer' | 'admin';
  address?: string;
  preferredMeasurements?: Record<string, string>;
  createdAt: Date;
  updatedAt: Date;
}

export interface IAppointmentSchema {
  appointmentId: string;
  customerId: string; // Ref: User
  customerName: string;
  phone: string;
  service: 'New Outfit' | 'Alteration' | 'Measurement' | 'Fitting' | 'Pickup / Collection';
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "10:00 AM"
  notes?: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no-show';
  attendedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface IOrderStageHistorySchema {
  stage: 'appointment' | 'measurement' | 'cutting' | 'stitching' | 'fitting' | 'alteration' | 'quality_check' | 'ready' | 'collected';
  timestamp: Date;
  note?: string;
  completedBy?: string;
}

export interface IOrderSchema {
  jobId: string; // e.g. TT-JOB-5018
  appointmentId?: string; // Ref: Appointment
  customerId: string; // Ref: User
  customerName: string;
  phone: string;
  service: string;
  garmentType: string;
  measurements: Map<string, string>;
  notes?: string;
  currentStage: string;
  stagesHistory: IOrderStageHistorySchema[];
  assignedTailor: string;
  estimatedCompletion: string;
  readyDate?: Date;
  collectedDate?: Date;
  price: number;
  advancePaid: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface INotificationSchema {
  userId: string; // Ref: User
  title: string;
  message: string;
  type: 'appointment' | 'job_status' | 'ready' | 'collection_reminder';
  channel: 'in_app' | 'whatsapp_simulated' | 'sms_simulated';
  isRead: boolean;
  orderId?: string;
  appointmentId?: string;
  createdAt: Date;
}

export interface IMeasurementSchema {
  customerId: string; // Ref: User
  customerName: string;
  phone: string;
  chest?: string;
  waist?: string;
  shoulder?: string;
  sleeve?: string;
  length?: string;
  hip?: string;
  inseam?: string;
  neck?: string;
  notes?: string;
  updatedAt: Date;
}

export interface IShopSettingsSchema {
  shopName: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  openingHours: string;
  closingHours: string;
  slotDurationMinutes: number;
  maxCapacityPerSlot: number;
  workingDays: string[];
  announcement?: string;
}
