export type UserRole = 'customer' | 'admin';

export interface User {
  _id: string;
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  role: UserRole;
  address?: string;
  preferredMeasurements?: Record<string, string>;
  createdAt: string;
}

export type AppointmentService = 
  | 'New Outfit'
  | 'Alteration'
  | 'Measurement'
  | 'Fitting'
  | 'Pickup / Collection';

export type AppointmentStatus =
  | 'pending'
  | 'confirmed'
  | 'completed'
  | 'cancelled'
  | 'no-show';

export interface Appointment {
  _id: string;
  appointmentId: string; // e.g. TT-APT-1082
  customerId: string;
  customerName: string;
  phone: string;
  service: AppointmentService;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "10:00 AM"
  notes?: string;
  status: AppointmentStatus;
  createdAt: string;
  attendedAt?: string;
}

export type OrderStage =
  | 'appointment'
  | 'measurement'
  | 'cutting'
  | 'stitching'
  | 'fitting'
  | 'alteration'
  | 'quality_check'
  | 'ready'
  | 'collected';

export interface OrderStageHistory {
  stage: OrderStage;
  timestamp: string;
  note?: string;
  completedBy?: string;
}

export interface Order {
  _id: string;
  jobId: string; // e.g. TT-JOB-5018
  appointmentId?: string;
  customerId: string;
  customerName: string;
  phone: string;
  service: AppointmentService;
  garmentType: string; // e.g. "Silk Anarkali Suit", "3-Piece Italian Wool Suit"
  measurements: Record<string, string>; // chest, waist, length, etc.
  notes?: string;
  currentStage: OrderStage;
  stagesHistory: OrderStageHistory[];
  assignedTailor: string;
  estimatedCompletion: string; // YYYY-MM-DD
  readyDate?: string;
  collectedDate?: string;
  price: number;
  advancePaid: number;
  createdAt: string;
}

export type NotificationType =
  | 'appointment'
  | 'job_status'
  | 'ready'
  | 'collection_reminder';

export interface Notification {
  _id: string;
  userId: string; // user _id or phone/email
  title: string;
  message: string;
  type: NotificationType;
  channel: 'in_app' | 'whatsapp_simulated' | 'sms_simulated';
  isRead: boolean;
  createdAt: string;
  orderId?: string;
  appointmentId?: string;
}

export interface MeasurementRecord {
  _id: string;
  customerId: string;
  customerName: string;
  phone: string;
  chest?: string;
  waist?: string;
  shoulder?: string;
  sleeve?: string;
  length?: string;
  hip?: string;
  inseam?: string;
  neck?: string;
  notes?: string;
  updatedAt: string;
}

export interface ShopSettings {
  _id: string;
  shopName: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  openingHours: string; // e.g. "09:00 AM"
  closingHours: string; // e.g. "07:00 PM"
  slotDurationMinutes: number; // e.g. 60
  maxCapacityPerSlot: number; // default 10
  workingDays: string[];
  announcement?: string;
}

export interface SlotCapacity {
  timeSlot: string;
  capacity: number;
  booked: number;
  available: number;
  isFull: boolean;
  appointments: {
    appointmentId: string;
    customerName: string;
    service: string;
    status: AppointmentStatus;
  }[];
}
