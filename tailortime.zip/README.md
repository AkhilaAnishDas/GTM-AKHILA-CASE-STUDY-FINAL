# TailorTime 🧵
> **Book • Track • Collect — Less Queue. More Certainty.**

TailorTime is a modern appointment scheduling and real-time job-tracking platform engineered specifically for local tailoring shops and bespoke fashion boutiques. It eliminates unpredictable walk-in fitting queues, provides full production transparency across 9 craftsmanship stages, and keeps customers updated via simulated WhatsApp/SMS alerts when their outfits are ready.

---

## 1. Problem Statement
Traditional tailoring businesses in India and worldwide struggle with:
- **Chaotic walk-in rushes:** Customers wait 45+ minutes just for a 5-minute measurement or fitting trial during wedding and festive seasons.
- **Unclear progress & constant follow-up calls:** Customers are left wondering whether their blouse, suit, or sherwani has even been cut or stitched.
- **Repeated unnecessary trips:** Arriving at the shop only to find the garment is not ready or still requires minor adjustments.
- **Lost paper slips:** Manual paper measurement slips and receipts get misplaced or damaged.

---

## 2. Solution
TailorTime streamlines the entire tailoring lifecycle:
1. **Guaranteed Fitting Slots:** Strict slot capacity enforcement (**10 fitting appointments per hour**) prevents shop overcrowding.
2. **Transparent 9-Stage Timeline:** Visual tracking from Consultation & Measurement to Cutting, Stitching, Trial Fitting, and Quality Check.
3. **Instant Notification:** Customers receive timely alerts (including simulated WhatsApp notifications) when their outfit reaches the "Ready for Collection" stage.
4. **Digital Measurement Cards:** Customer body measurements are saved in their digital profile for instant re-ordering.

---

## 3. Key Features

### Customer Experience
- **1-Click Demo & Authentication:** Sign up, log in, or use 1-click test accounts.
- **Interactive 5-Step Booking Wizard:**
  - Step 1: Select Service (*New Outfit, Alteration, Measurement, Fitting, Pickup*)
  - Step 2: Select Date (*Interactive next-14-days picker*)
  - Step 3: Select Available Time Slot (*Live occupancy indicator, automatically disables when capacity reaches 10/10*)
  - Step 4: Customer Details & Garment Notes
  - Step 5: Booking Confirmation (*Unique ID e.g., `TT-APT-8921`, calendar summary, copy ID*)
- **Appointment Management:** View upcoming, past, and cancelled visits. Reschedule with live slot availability or cancel.
- **Public & In-App Order Tracking:** Track by Job ID (*e.g., `TT-JOB-5018`*) on the landing page without logging in, or view the complete interactive 9-stage visual timeline.
- **Simulated WhatsApp Notifications:** High-fidelity simulated WhatsApp message preview popup showing official verified business messages with timestamps.
- **Digital Measurement Sheet:** Optional 10-point body measurements (*Chest, Waist, Shoulder, Sleeve, Length, Hip, Inseam, Neck*) and tailored fit notes.

### Tailor / Shop Admin Experience
- **Executive KPI Dashboard:** Today's appointments schedule, pending jobs, in-production count, ready-for-collection count, on-time delivery rate (%), and average waiting time reduction.
- **Actionable Alerts:** Immediate banners for ready-for-pickup garments and delayed jobs.
- **Appointment Management:** Filter by date, status, or search; approve bookings, reschedule, mark attended, mark no-show, or convert an appointment directly into an active job card.
- **Job Card & Production Pipeline:**
  - Create new job cards with garment descriptions, customer measurements, prices, and advances.
  - Advance orders through stages: *Measurement → Cutting → Stitching → Fitting → Alteration → Quality Check → Ready → Collected*.
  - Add craftsman notes for each milestone (automatically notifies customer).
  - 1-click "Mark Ready" and "Mark Collected".
- **Fitting Capacity Matrix:**
  - Slot-by-slot capacity grid: `Time Slot | Max Capacity (10) | Booked | Available | Occupancy Bar | Status`.
  - Date switcher to inspect future day loads.
  - Expandable roster showing which customers booked which slots.
- **Customer Directory:** View customer history, past orders, active jobs, and edit body measurement sheets directly.
- **Shop Settings:** Adjust boutique name, contact info, working hours, working days, and default capacity per hour.

---

## 4. User Roles

| Role | Default Email | Password | Access & Capabilities |
| :--- | :--- | :--- | :--- |
| **Master Tailor (Admin)** | `admin@tailortime.com` | `tailortime123` | Full shop admin, capacity matrix, job card creation, stage advancement, customer records. |
| **Customer (Riya Mehta)** | `riya@example.com` | `tailortime123` | Book fitting slots, track orders in real time, view appointments, save measurements. |

*(Note: The navbar features a **1-Click Role Switcher** dropdown for effortless testing during college presentations and demonstrations!)*

---

## 5. Technology Stack

- **Frontend:**
  - React 19 + TypeScript
  - Vite 8
  - Tailwind CSS v4
  - Lucide React (Icons)
  - Motion
- **Backend:**
  - Node.js
  - Express.js
  - JSON Web Tokens (JWT) for authentication
  - `bcryptjs` for secure password hashing
- **Database & Storage:**
  - In-memory + persistent file storage engine (`/data/db.json`) pre-populated with realistic Indian tailoring seed data (zero-config, works immediately).
  - MongoDB/Mongoose schema definitions included in `/backend/models/index.ts` for cluster deployment.

---

## 6. Folder Structure

```
├── .env.example              # Environment variables template
├── backend/
│   ├── db/
│   │   └── store.ts          # Persistence layer & seed data
│   ├── middleware/
│   │   └── auth.ts           # JWT authentication & admin role guard
│   ├── models/
│   │   └── index.ts          # Mongoose schema definitions
│   ├── routes/
│   │   ├── analytics.ts      # Dashboard KPI analytics
│   │   ├── appointments.ts   # Booking, reschedule, cancel, capacity check
│   │   ├── auth.ts           # Login, register, demo-login, profile
│   │   ├── capacity.ts       # Hourly fitting slot capacity matrix
│   │   ├── customers.ts      # Customer directory & history
│   │   ├── measurements.ts   # Body measurement records
│   │   ├── notifications.ts  # In-app and simulated WhatsApp alerts
│   │   ├── orders.ts         # 9-stage order tracking & job cards
│   │   └── shop.ts           # Boutique settings & configuration
│   └── types.ts              # TypeScript interfaces
├── src/
│   ├── components/
│   │   ├── admin/            # Dashboard, Appointments, Orders, Capacity, Settings
│   │   ├── auth/             # Login/Register modal
│   │   ├── common/           # Navbar, Footer, ToastContainer, WhatsAppModal
│   │   ├── customer/         # CustomerHome, BookWizard, MyAppointments, OrderTracker
│   │   └── landing/          # Hero, Quick Tracker, Features, Testimonials
│   ├── context/              # AuthContext & NotificationContext
│   ├── services/
│   │   └── api.ts            # Frontend REST API client
│   ├── App.tsx               # Main application routing & modal management
│   ├── main.tsx              # React DOM entrypoint
│   └── index.css             # Tailwind CSS & theme tokens
├── server.ts                 # Full-stack Express server + Vite dev middleware
├── package.json              # Scripts & dependencies
└── tsconfig.json             # TypeScript configuration
```

---

## 7. Installation & Setup

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or yarn

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Environment Configuration
Copy the sample environment file:
```bash
cp .env.example .env
```
Default `.env` settings:
```env
PORT=3000
JWT_SECRET=tailortime_super_secure_jwt_secret_2026
NODE_ENV=development
```

---

## 8. How to Run

### Development Mode (Full-Stack with Vite middlewares)
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser. Both the React frontend and Express REST API run seamlessly on port 3000.

### Production Build & Run
```bash
npm run build
npm start
```

---

## 9. Demo Accounts & Sample Data

The application comes pre-seeded with realistic Indian tailoring shop data:
- **Shop:** *TailorTime Bespoke & Alterations (Indiranagar, Bengaluru)*
- **Master Tailor:** Rameshwar (`admin@tailortime.com` / `tailortime123`)
- **Customer 1:** Riya Mehta (`riya@example.com` / `tailortime123`) — Has an active Festive Raw Silk Anarkali Suit (`TT-JOB-5018`) at the **Fitting** stage!
- **Customer 2:** Rahul Deshmukh (`rahul@example.com`) — Has an order (`TT-JOB-5019`) that is **Ready for Collection**!
- **Customer 3:** Aarav Sharma (`aarav@example.com`) — Bespoke Tuxedo (`TT-JOB-5020`) in **Cutting** stage.

---

## 10. REST API Overview

### Authentication
- `POST /api/auth/register` — Create a new customer or admin account.
- `POST /api/auth/login` — Sign in and receive a JWT token.
- `POST /api/auth/demo-login` — 1-click login as Customer or Master Tailor.
- `GET  /api/auth/me` — Retrieve authenticated user profile.
- `PUT  /api/auth/profile` — Update contact information & body measurements.

### Appointments & Capacity
- `GET  /api/appointments` — Fetch appointments (filtered by date, status, search).
- `POST /api/appointments` — Book appointment with automatic capacity check (max 10/hr).
- `PUT  /api/appointments/:id` — Reschedule, confirm, mark attended, or mark no-show.
- `DELETE /api/appointments/:id` — Cancel an appointment.
- `GET  /api/shop/capacity?date=YYYY-MM-DD` — Slot capacity matrix (Capacity, Booked, Available).

### Orders & Tracking
- `GET  /api/orders/track/:jobId` — **Public tracking endpoint** (no login required).
- `GET  /api/orders` — List production orders.
- `POST /api/orders` — Create new job card (admin).
- `PUT  /api/orders/:id` — Update production stage, craft notes, and completion date.

### Notifications & Measurements
- `GET  /api/notifications` — List notifications.
- `PUT  /api/notifications/:id/read` — Mark notification read.
- `POST /api/notifications/simulate` — Trigger simulated WhatsApp/SMS alert.
- `GET  /api/measurements/:customerId` — Get customer body measurements.
- `POST /api/measurements` — Save/upsert body measurements.

### Analytics & Settings
- `GET  /api/analytics` — Shop KPIs, alerts, and stage distributions.
- `GET  /api/shop` — Retrieve boutique details and operating hours.
- `PUT  /api/shop` — Update boutique settings and max capacity per hour.

---

## 11. Future Roadmap
- Direct WhatsApp Cloud API & Twilio SMS integration for automated live messaging.
- Barcode / QR-code scanning on physical job slip tags.
- Fabric photo uploads and design sketchbook attachments.
- Multi-branch support for tailoring chains across multiple city outlets.

---

*TailorTime — Less Queue. More Certainty.*
